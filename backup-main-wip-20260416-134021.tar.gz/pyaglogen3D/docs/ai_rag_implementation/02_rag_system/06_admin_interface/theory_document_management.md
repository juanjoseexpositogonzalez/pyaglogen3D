# Theory: Document Management

Admin interface for managing the RAG knowledge base.

---

## Admin Capabilities

```
┌─────────────────────────────────────────────────────────────────────┐
│                    Document Management Features                      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  📄 Document Operations                                             │
│  ├── Upload PDFs manually                                           │
│  ├── Import from arXiv/Semantic Scholar                             │
│  ├── View document status                                           │
│  ├── Re-index documents                                             │
│  └── Delete documents                                               │
│                                                                     │
│  🔍 Search & Discovery                                              │
│  ├── Search existing documents                                      │
│  ├── Preview chunks                                                 │
│  ├── Test search queries                                            │
│  └── View search analytics                                          │
│                                                                     │
│  📊 Knowledge Base Statistics                                       │
│  ├── Total documents                                                │
│  ├── Total chunks                                                   │
│  ├── Storage usage                                                  │
│  └── Most cited documents                                           │
│                                                                     │
│  ⚙️ Configuration                                                   │
│  ├── Chunking settings                                              │
│  ├── Embedding model                                                │
│  └── Auto-discovery topics                                          │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## UI Components

### Document List View

```
┌─────────────────────────────────────────────────────────────────────┐
│  📚 Knowledge Base                                   [+ Upload PDF] │
├─────────────────────────────────────────────────────────────────────┤
│  Search: [________________] [🔍]    Filter: [All ▼] [Ready ▼]      │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │ ● Witten & Sander (1981)                              Ready   │ │
│  │   Diffusion-Limited Aggregation                               │ │
│  │   📄 12 chunks  |  📊 45 citations  |  arXiv                  │ │
│  │                                        [View] [Reindex] [🗑️] │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │ ○ Meakin (1984)                                   Processing  │ │
│  │   Formation of Fractal Clusters...                            │ │
│  │   ⏳ Processing: 45%                                          │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │ ✖ Smith (2023)                                        Failed  │ │
│  │   New Aggregation Study                                       │ │
│  │   Error: PDF extraction failed                    [Retry] [🗑️]│ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
├─────────────────────────────────────────────────────────────────────┤
│  Showing 1-10 of 156 documents              [< Prev] [1] [2] [>]   │
└─────────────────────────────────────────────────────────────────────┘
```

### Document Detail View

```
┌─────────────────────────────────────────────────────────────────────┐
│  ← Back                                      [Reindex] [Delete]    │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  📄 Diffusion-Limited Aggregation, a Kinetic Critical Phenomenon   │
│                                                                     │
│  Authors: T.A. Witten, L.M. Sander                                 │
│  Year: 1981                                                        │
│  Source: arXiv (arXiv:cond-mat/9812345)                            │
│  Status: ● Ready                                                   │
│  Added: Jan 15, 2025                                               │
│                                                                     │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                     │
│  📝 Abstract                                                        │
│  We describe a model for random aggregation which produces          │
│  fractal clusters with dimension d ≈ 1.71...                       │
│                                                                     │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                     │
│  📦 Chunks (12)                                         [Expand All]│
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │ Chunk 1 (Abstract)                                            │ │
│  │ "We describe a model for random aggregation which..."         │ │
│  └───────────────────────────────────────────────────────────────┘ │
│  ┌───────────────────────────────────────────────────────────────┐ │
│  │ Chunk 2 (Introduction)                                        │ │
│  │ "The study of fractal structures has become..."              │ │
│  └───────────────────────────────────────────────────────────────┘ │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Search Test Panel

```
┌─────────────────────────────────────────────────────────────────────┐
│  🔍 Test Search                                                     │
├─────────────────────────────────────────────────────────────────────┤
│                                                                     │
│  Query: [fractal dimension DLA____________] [Search]               │
│                                                                     │
│  Options:                                                          │
│  [✓] Use reranking    [ ] Show scores    Results: [10 ▼]          │
│                                                                     │
│  ─────────────────────────────────────────────────────────────────  │
│                                                                     │
│  Results (5 in 0.12s):                                             │
│                                                                     │
│  1. Score: 0.94                                                    │
│     📄 Witten & Sander (1981) - Chunk 3                            │
│     "...fractal dimension d ≈ 1.71 in two dimensions..."          │
│                                                                     │
│  2. Score: 0.89                                                    │
│     📄 Meakin (1984) - Chunk 7                                     │
│     "For three-dimensional DLA, we find Df = 1.78..."             │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

---

## Backend API Additions

### Admin Endpoints

```
GET    /api/v1/rag/admin/stats/           # Knowledge base statistics
GET    /api/v1/rag/admin/documents/       # List with admin details
POST   /api/v1/rag/admin/documents/{id}/reindex/  # Re-process document
GET    /api/v1/rag/admin/documents/{id}/chunks/   # View chunks
POST   /api/v1/rag/admin/search/test/     # Test search query
```

### Statistics Response

```json
{
    "total_documents": 156,
    "documents_by_status": {
        "ready": 140,
        "processing": 5,
        "failed": 11
    },
    "total_chunks": 4523,
    "storage_size_mb": 245,
    "most_cited": [
        {"document_id": "...", "title": "...", "citation_count": 45}
    ],
    "recent_additions": [...]
}
```

---

## Workflow: Import Papers

```
Admin: Search arXiv for "fractal aggregation"
         │
         ▼
System: Display results with [Import] buttons
         │
         ▼
Admin: Click [Import] on selected papers
         │
         ▼
System: Create Document records
         Queue background ingestion
         Show progress in UI
         │
         ▼
Admin: Monitor progress
         Handle any failures
```

---

## Error Handling UI

### Failed Document Card

```tsx
function FailedDocumentCard({ document }) {
    return (
        <Card className="border-red-500/20">
            <CardHeader>
                <CardTitle className="text-red-600">
                    ✖ {document.title}
                </CardTitle>
            </CardHeader>
            <CardContent>
                <p className="text-sm text-muted-foreground">
                    Error: {document.metadata.error}
                </p>
                <div className="mt-4 flex gap-2">
                    <Button onClick={() => retryIngestion(document.id)}>
                        Retry
                    </Button>
                    <Button
                        variant="destructive"
                        onClick={() => deleteDocument(document.id)}
                    >
                        Delete
                    </Button>
                </div>
            </CardContent>
        </Card>
    );
}
```

---

## Permissions

RAG admin features should be restricted:

```python
class IsRAGAdmin(BasePermission):
    def has_permission(self, request, view):
        return (
            request.user.is_authenticated and
            (request.user.is_staff or request.user.has_ai_access)
        )
```

---

## Key Takeaways

1. **Clear status indicators**: Show document processing state
2. **Chunk preview**: Let admins see how documents are split
3. **Search testing**: Validate retrieval quality
4. **Error recovery**: Easy retry for failed documents
5. **Statistics**: Overview of knowledge base health
6. **Access control**: Restrict to admin users

---

## Further Reading

- [Django Admin Customization](https://docs.djangoproject.com/en/4.2/ref/contrib/admin/)
- [Shadcn Data Table](https://ui.shadcn.com/docs/components/data-table)
