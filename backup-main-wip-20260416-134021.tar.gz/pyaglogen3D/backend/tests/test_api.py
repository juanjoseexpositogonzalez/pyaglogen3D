"""Tests for REST API endpoints."""

import io

import numpy as np
import pytest
from rest_framework import status

from apps.fractal_analysis.models import FraktalAnalysis, SourceType
from apps.simulations.contracts import GEOMETRY_NPY_CONTRACT_VERSION
from apps.simulations.services.projection_contract import (
    PROJECTION_CONTRACT_VERSION,
    ProjectionContract,
)


class TestProjectsAPI:
    """Tests for Projects API."""

    def test_list_projects(self, api_client, db):
        """Test listing projects."""
        response = api_client.get("/api/v1/projects/")
        assert response.status_code == status.HTTP_200_OK
        assert "results" in response.data

    def test_create_project(self, api_client, db):
        """Test creating a project."""
        response = api_client.post(
            "/api/v1/projects/",
            {"name": "New Project", "description": "Test description"},
            format="json",
        )
        assert response.status_code == status.HTTP_201_CREATED
        assert response.data["name"] == "New Project"
        assert response.data["simulation_count"] == 0

    def test_get_project(self, api_client, project):
        """Test retrieving a project."""
        response = api_client.get(f"/api/v1/projects/{project.id}/")
        assert response.status_code == status.HTTP_200_OK
        assert response.data["id"] == str(project.id)

    def test_delete_project(self, api_client, project):
        """Test deleting a project."""
        response = api_client.delete(f"/api/v1/projects/{project.id}/")
        assert response.status_code == status.HTTP_204_NO_CONTENT


class TestSimulationsAPI:
    """Tests for Simulations API."""

    def test_list_simulations(self, api_client, project):
        """Test listing simulations for a project."""
        response = api_client.get(f"/api/v1/projects/{project.id}/simulations/")
        assert response.status_code == status.HTTP_200_OK

    def test_create_simulation(self, api_client, project, mocker):
        """Test creating a simulation."""
        # Mock the Celery task to avoid actual execution
        mocker.patch("apps.simulations.views.run_simulation_task.delay")

        response = api_client.post(
            f"/api/v1/projects/{project.id}/simulations/",
            {
                "project": str(project.id),
                "algorithm": "dla",
                "parameters": {"n_particles": 100},
                "seed": 42,
            },
            format="json",
        )
        assert response.status_code == status.HTTP_201_CREATED, response.data
        assert response.data["algorithm"] == "dla"
        assert response.data["status"] == "queued"

    def test_create_simulation_validates_parameters(self, api_client, project, mocker):
        """Test that simulation creation validates parameters."""
        mocker.patch("apps.simulations.views.run_simulation_task.delay")

        # Missing n_particles
        response = api_client.post(
            f"/api/v1/projects/{project.id}/simulations/",
            {
                "algorithm": "dla",
                "parameters": {},
                "seed": 42,
            },
            format="json",
        )
        assert response.status_code == status.HTTP_400_BAD_REQUEST

    def test_get_simulation(self, api_client, project, simulation):
        """Test retrieving a simulation."""
        response = api_client.get(
            f"/api/v1/projects/{project.id}/simulations/{simulation.id}/"
        )
        assert response.status_code == status.HTTP_200_OK
        assert response.data["id"] == str(simulation.id)

    def test_geometry_download_not_available(self, api_client, simulation):
        """Test geometry download when not available."""
        response = api_client.get(f"/api/v1/simulations/{simulation.id}/geometry/")
        assert response.status_code == status.HTTP_404_NOT_FOUND

    def test_geometry_download_exposes_contract_headers(self, api_client, simulation):
        geometry = np.array([[0.0, 1.0, 2.0, 0.5]], dtype=np.float64)
        buffer = io.BytesIO()
        np.save(buffer, geometry, allow_pickle=False)
        simulation.geometry = buffer.getvalue()
        simulation.save(update_fields=["geometry"])

        response = api_client.get(f"/api/v1/simulations/{simulation.id}/geometry/")

        assert response.status_code == status.HTTP_200_OK
        assert response["X-Geometry-Contract"] == GEOMETRY_NPY_CONTRACT_VERSION
        assert response["X-Geometry-Shape"] == "(N,4)"
        assert response["X-Geometry-Columns"] == "x,y,z,radius"

    def test_projection_endpoint_passes_canonical_resolution_to_renderer(
        self, api_client, simulation, mocker
    ):
        geometry = np.array([[0.0, 1.0, 2.0, 0.5]], dtype=np.float64)
        buffer = io.BytesIO()
        np.save(buffer, geometry, allow_pickle=False)
        simulation.geometry = buffer.getvalue()
        simulation.save(update_fields=["geometry"])

        projection = ProjectionContract(
            contract_version=PROJECTION_CONTRACT_VERSION,
            azimuth=45.0,
            elevation=10.0,
            x=[0.0],
            y=[0.0],
            radii=[0.5],
            bounds=(-0.5, 0.5, -0.5, 0.5),
        )
        mocker.patch(
            "apps.simulations.views.project_geometry_to_contract",
            return_value=projection,
        )
        renderer = mocker.patch(
            "apps.simulations.views.render_projection_contract",
            return_value=b"png-bytes",
        )

        response = api_client.post(
            f"/api/v1/simulations/{simulation.id}/projection/",
            {"azimuth": 45, "elevation": 10, "resolution": 768, "format": "png"},
            format="json",
        )

        assert response.status_code == status.HTTP_200_OK
        renderer.assert_called_once_with(
            projection,
            image_format="png",
            resolution=768,
        )
        assert response["X-Projection-Contract"] == PROJECTION_CONTRACT_VERSION
        assert response["X-Projection-Resolution"] == "768"
        assert response["X-Projection-Bounds"] == "-0.5,0.5,-0.5,0.5"

    def test_projection_endpoint_rejects_fractional_resolution(
        self, api_client, simulation
    ):
        geometry = np.array([[0.0, 1.0, 2.0, 0.5]], dtype=np.float64)
        buffer = io.BytesIO()
        np.save(buffer, geometry, allow_pickle=False)
        simulation.geometry = buffer.getvalue()
        simulation.save(update_fields=["geometry"])

        response = api_client.post(
            f"/api/v1/simulations/{simulation.id}/projection/",
            {"azimuth": 45, "elevation": 10, "resolution": 768.5, "format": "png"},
            format="json",
        )

        assert response.status_code == status.HTTP_400_BAD_REQUEST
        assert "Projection resolution must be an integer" in response.data["error"]


class TestImageAnalysisAPI:
    """Tests for Image Analysis API."""

    def test_list_analyses(self, api_client, project):
        """Test listing analyses for a project."""
        response = api_client.get(f"/api/v1/projects/{project.id}/analyses/")
        assert response.status_code == status.HTTP_200_OK

    def test_get_analysis(self, api_client, project, image_analysis):
        """Test retrieving an analysis."""
        response = api_client.get(
            f"/api/v1/projects/{project.id}/analyses/{image_analysis.id}/"
        )
        assert response.status_code == status.HTTP_200_OK
        assert response.data["id"] == str(image_analysis.id)

    def test_get_analysis_exposes_unsupported_execution_contract(
        self, api_client, project, image_analysis
    ):
        """ImageAnalysis responses should expose explicit unsupported semantics."""
        response = api_client.get(
            f"/api/v1/projects/{project.id}/analyses/{image_analysis.id}/"
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.data["analysis_type"] == "image_analysis"
        assert response.data["capability_status"] == "unsupported"
        assert response.data["execution_semantics"] == "unsupported"
        assert response.data["supports_scientific_execution"] is False


class TestFraktalAnalysisAPI:
    """Tests for FRAKTAL Analysis API."""

    def test_get_fraktal_analysis_exposes_supported_execution_contract(
        self, api_client, project
    ):
        """FRAKTAL responses should advertise real supported execution."""
        analysis = FraktalAnalysis.objects.create(
            project=project,
            source_type=SourceType.UPLOADED_IMAGE,
            original_image=b"fraktal-image",
            original_filename="fraktal.png",
            original_content_type="image/png",
            model="granulated_2012",
            npix=12.5,
            dpo=40.0,
        )

        response = api_client.get(
            f"/api/v1/projects/{project.id}/fraktal/{analysis.id}/"
        )

        assert response.status_code == status.HTTP_200_OK
        assert response.data["analysis_type"] == "fraktal"
        assert response.data["capability_status"] == "supported"
        assert response.data["execution_semantics"] == "real"
        assert response.data["supports_scientific_execution"] is True
