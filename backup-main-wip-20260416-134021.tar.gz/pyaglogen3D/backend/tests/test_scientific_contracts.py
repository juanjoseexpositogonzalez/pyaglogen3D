"""Focused tests for scientific integration contracts."""

import io
from types import SimpleNamespace

import numpy as np
import pytest
from PIL import Image

from apps.simulations.contracts import GeometryContractError, split_geometry_columns
from apps.simulations.services.projection_contract import (
    ProjectionContract,
    PROJECTION_CONTRACT_VERSION,
    ProjectionContractError,
    normalize_projection_result,
    normalize_projection_resolution,
    render_projection_contract,
    render_projection_grayscale_array,
)


def test_split_geometry_columns_validates_npy_contract() -> None:
    invalid_payload = b"not-a-npy-payload"

    with pytest.raises(GeometryContractError):
        split_geometry_columns(invalid_payload, source="test geometry")


def test_normalize_projection_result_rejects_non_finite_geometry() -> None:
    raw_result = SimpleNamespace(
        contract_version=PROJECTION_CONTRACT_VERSION,
        azimuth=45.0,
        elevation=10.0,
        x=[0.0, np.nan],
        y=[0.0, 1.0],
        radii=[1.0, 1.0],
        bounds=[-1.0, 1.0, -1.0, 1.0],
    )

    with pytest.raises(ProjectionContractError):
        normalize_projection_result(raw_result)


def test_normalize_projection_result_accepts_canonical_payload() -> None:
    raw_result = SimpleNamespace(
        contract_version=PROJECTION_CONTRACT_VERSION,
        azimuth=45.0,
        elevation=10.0,
        x=[0.0, 1.0],
        y=[0.0, 1.0],
        radii=[0.5, 0.5],
        bounds=[-0.5, 1.5, -0.5, 1.5],
    )

    contract = normalize_projection_result(raw_result)

    assert contract.contract_version == PROJECTION_CONTRACT_VERSION
    assert contract.particle_count == 2
    assert contract.payload()["metadata"]["particle_count"] == 2


def test_normalize_projection_resolution_rejects_fractional_values() -> None:
    with pytest.raises(ProjectionContractError):
        normalize_projection_resolution(512.5)


def test_projection_raster_helpers_share_resolution_semantics() -> None:
    contract = ProjectionContract(
        contract_version=PROJECTION_CONTRACT_VERSION,
        azimuth=45.0,
        elevation=10.0,
        x=[0.0, 1.0],
        y=[0.0, 1.0],
        radii=[0.25, 0.25],
        bounds=(-0.5, 1.5, -0.5, 1.5),
    )

    png_bytes = render_projection_contract(contract, image_format="png", resolution=256)
    grayscale = render_projection_grayscale_array(contract, resolution=256)

    rendered = Image.open(io.BytesIO(png_bytes))

    assert max(rendered.size) == 256
    assert max(grayscale.shape) == 256
