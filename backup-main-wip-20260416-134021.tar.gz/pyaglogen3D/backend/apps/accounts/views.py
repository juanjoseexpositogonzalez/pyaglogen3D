"""
Authentication views for PyAglogen3D.
"""

import logging
import secrets
from datetime import timedelta
from urllib.parse import urlencode

from django.conf import settings
from django.contrib.auth import authenticate, get_user_model
from django.core.mail import send_mail
from django.shortcuts import redirect
from django.utils import timezone
from rest_framework import generics, status
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.request import Request
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.tokens import RefreshToken

from .models import EmailVerificationToken
from .serializers import (
    AdminUserSerializer,
    ChangePasswordSerializer,
    EmailVerificationSerializer,
    LoginSerializer,
    RegisterSerializer,
    ResendVerificationSerializer,
    UserSerializer,
)

User = get_user_model()
logger = logging.getLogger(__name__)


class VerificationEmailDeliveryError(Exception):
    """Raised when a verification email could not be delivered."""


def get_tokens_for_user(user) -> dict:
    """Generate JWT tokens for a user."""
    refresh = RefreshToken.for_user(user)
    return {
        "refresh": str(refresh),
        "access": str(refresh.access_token),
    }


class RegisterView(generics.CreateAPIView):
    """
    Register a new user account.

    Sends verification email after registration.
    """

    serializer_class = RegisterSerializer
    permission_classes = [AllowAny]

    def create(self, request: Request, *args, **kwargs) -> Response:
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        verification_email_sent = True
        message = (
            "Registration successful. Please check your email to verify your account."
        )

        try:
            self._send_verification_email(user)
        except VerificationEmailDeliveryError:
            verification_email_sent = False
            message = (
                "Registration successful, but we could not send the verification email. "
                "Please try resending it shortly."
            )

        tokens = get_tokens_for_user(user)
        return Response(
            {
                "user": UserSerializer(user).data,
                "tokens": tokens,
                "message": message,
                "verification_email_status": "sent"
                if verification_email_sent
                else "failed",
            },
            status=status.HTTP_201_CREATED,
        )

    def _send_verification_email(self, user) -> None:
        """Send email verification link to user."""
        # Create verification token
        token = secrets.token_urlsafe(32)
        EmailVerificationToken.objects.create(
            user=user,
            token=token,
            expires_at=timezone.now() + timedelta(hours=24),
        )

        # Build verification URL
        frontend_url = getattr(settings, "FRONTEND_URL", "http://localhost:3000")
        verify_url = f"{frontend_url}/auth/verify-email?token={token}"

        # Send email
        try:
            send_mail(
                subject="Verify your PyAglogen3D account",
                message=f"Click this link to verify your email: {verify_url}",
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[user.email],
                fail_silently=False,
            )
        except Exception as exc:
            logger.exception(
                "Failed to send verification email during registration",
                extra={"user_id": str(user.id), "email": user.email},
            )
            raise VerificationEmailDeliveryError from exc


class LoginView(APIView):
    """
    Authenticate user and return JWT tokens.
    """

    permission_classes = [AllowAny]
    serializer_class = LoginSerializer

    def post(self, request: Request) -> Response:
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        user = authenticate(
            email=serializer.validated_data["email"],
            password=serializer.validated_data["password"],
        )

        if not user:
            return Response(
                {"error": "Invalid email or password."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        if not user.is_active:
            return Response(
                {"error": "This account has been deactivated."},
                status=status.HTTP_401_UNAUTHORIZED,
            )

        tokens = get_tokens_for_user(user)
        return Response(
            {
                "user": UserSerializer(user).data,
                "tokens": tokens,
            }
        )


class LogoutView(APIView):
    """
    Blacklist the refresh token to log out.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request: Request) -> Response:
        try:
            refresh_token = request.data.get("refresh")
            if refresh_token:
                token = RefreshToken(refresh_token)
                token.blacklist()
        except Exception:
            pass  # Token might already be blacklisted or invalid

        return Response({"message": "Successfully logged out."})


class MeView(generics.RetrieveUpdateAPIView):
    """
    Get or update the current user's profile.
    """

    serializer_class = UserSerializer
    permission_classes = [IsAuthenticated]

    def get_object(self):
        return self.request.user


class ChangePasswordView(APIView):
    """
    Change the current user's password.
    """

    permission_classes = [IsAuthenticated]

    def post(self, request: Request) -> Response:
        serializer = ChangePasswordSerializer(
            data=request.data, context={"request": request}
        )
        serializer.is_valid(raise_exception=True)

        request.user.set_password(serializer.validated_data["new_password"])
        request.user.save()

        return Response({"message": "Password changed successfully."})


class VerifyEmailView(APIView):
    """
    Verify user's email address using token.
    """

    permission_classes = [AllowAny]

    def post(self, request: Request) -> Response:
        serializer = EmailVerificationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        token = serializer.validated_data["token"]

        try:
            verification = EmailVerificationToken.objects.get(token=token, used=False)
        except EmailVerificationToken.DoesNotExist:
            return Response(
                {"error": "Invalid or expired verification token."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if timezone.now() > verification.expires_at:
            return Response(
                {"error": "Verification token has expired."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Mark user as verified
        user = verification.user
        user.email_verified = True
        user.save()

        # Mark token as used
        verification.used = True
        verification.save()

        return Response({"message": "Email verified successfully."})


class ResendVerificationView(APIView):
    """
    Resend verification email to user.
    """

    permission_classes = [AllowAny]

    def post(self, request: Request) -> Response:
        serializer = ResendVerificationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        email = serializer.validated_data["email"]

        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            # Don't reveal if email exists
            return Response(
                {
                    "message": "If this email exists, a verification link will be sent.",
                    "verification_email_status": "unknown",
                }
            )

        if user.email_verified:
            return Response(
                {
                    "message": "Email is already verified.",
                    "verification_email_status": "not_required",
                }
            )

        # Invalidate old tokens
        EmailVerificationToken.objects.filter(user=user, used=False).update(used=True)

        # Create new token and send email
        token = secrets.token_urlsafe(32)
        EmailVerificationToken.objects.create(
            user=user,
            token=token,
            expires_at=timezone.now() + timedelta(hours=24),
        )

        frontend_url = getattr(settings, "FRONTEND_URL", "http://localhost:3000")
        verify_url = f"{frontend_url}/auth/verify-email?token={token}"

        try:
            send_mail(
                subject="Verify your PyAglogen3D account",
                message=f"Click this link to verify your email: {verify_url}",
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[user.email],
                fail_silently=False,
            )
        except Exception:
            logger.exception(
                "Failed to send verification email during resend",
                extra={"user_id": str(user.id), "email": user.email},
            )
            return Response(
                {
                    "message": "We could not send the verification email. Please try again shortly.",
                    "verification_email_status": "failed",
                },
                status=status.HTTP_503_SERVICE_UNAVAILABLE,
            )

        return Response(
            {
                "message": "If this email exists, a verification link will be sent.",
                "verification_email_status": "sent",
            }
        )


class OAuthCallbackView(APIView):
    """
    Handle OAuth callback and return JWT tokens.

    After successful OAuth login, this endpoint generates JWT tokens
    and redirects to the frontend with tokens in URL parameters.
    """

    # Allow session auth so we can read the session created by allauth
    from rest_framework.authentication import SessionAuthentication

    authentication_classes = [SessionAuthentication]
    permission_classes = [AllowAny]

    def get(self, request: Request) -> Response:
        """
        Called by frontend to get JWT tokens after OAuth redirect.
        The user should be authenticated via session from allauth.
        """
        user = request.user
        frontend_url = getattr(settings, "FRONTEND_URL", "http://localhost:3000")

        if not user.is_authenticated:
            # Redirect to login with error
            return redirect(f"{frontend_url}/auth/login?error=oauth_failed")

        # Generate JWT tokens
        tokens = get_tokens_for_user(user)

        # Redirect to frontend with tokens
        params = urlencode(
            {
                "access": tokens["access"],
                "refresh": tokens["refresh"],
            }
        )
        return redirect(f"{frontend_url}/auth/oauth-callback?{params}")


class AdminDashboardView(APIView):
    """
    Admin dashboard: list all users with their projects.

    Only accessible by staff/superuser.
    """

    permission_classes = [IsAuthenticated]

    def get(self, request: Request) -> Response:
        """Get all users with project counts and details."""
        from django.db.models import Count

        # Check admin permission
        if not request.user.is_staff and not request.user.is_superuser:
            return Response(
                {"error": "Admin access required."},
                status=status.HTTP_403_FORBIDDEN,
            )

        # Get all users with project and simulation counts
        users = User.objects.annotate(
            project_count=Count("owned_projects", distinct=True),
            simulation_count=Count("owned_projects__simulations", distinct=True),
        ).order_by("-created_at")

        serializer = AdminUserSerializer(users, many=True)

        # Also include summary stats
        total_users = users.count()
        total_projects = sum(u.project_count for u in users)
        total_simulations = sum(u.simulation_count for u in users)

        return Response(
            {
                "summary": {
                    "total_users": total_users,
                    "total_projects": total_projects,
                    "total_simulations": total_simulations,
                },
                "users": serializer.data,
            }
        )


class AdminUserDetailView(APIView):
    """
    Admin user management: get, update, delete individual users.

    Only accessible by staff/superuser.
    """

    permission_classes = [IsAuthenticated]

    def _check_admin(self, request: Request) -> Response | None:
        """Check if user is admin. Returns error response if not."""
        if not request.user.is_staff and not request.user.is_superuser:
            return Response(
                {"error": "Admin access required."},
                status=status.HTTP_403_FORBIDDEN,
            )
        return None

    def _get_user(self, user_id: str) -> User | None:
        """Get user by ID."""
        try:
            return User.objects.get(id=user_id)
        except User.DoesNotExist:
            return None

    def get(self, request: Request, user_id: str) -> Response:
        """Get user details."""
        if error := self._check_admin(request):
            return error

        user = self._get_user(user_id)
        if not user:
            return Response(
                {"error": "User not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        serializer = AdminUserSerializer(user)
        return Response(serializer.data)

    def patch(self, request: Request, user_id: str) -> Response:
        """Update user details (first_name, last_name, is_staff, is_active, has_ai_access)."""
        if error := self._check_admin(request):
            return error

        user = self._get_user(user_id)
        if not user:
            return Response(
                {"error": "User not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Prevent self-demotion from admin
        if (
            user.id == request.user.id
            and "is_staff" in request.data
            and not request.data["is_staff"]
        ):
            return Response(
                {"error": "Cannot remove your own admin privileges."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Update allowed fields on User model
        allowed_fields = ["first_name", "last_name", "is_staff", "is_active"]
        for field in allowed_fields:
            if field in request.data:
                setattr(user, field, request.data[field])

        user.save()

        # Handle AI access separately via AIUserProfile
        if "has_ai_access" in request.data:
            from apps.ai_assistant.models import AIUserProfile

            has_ai_access = request.data["has_ai_access"]
            ai_profile, created = AIUserProfile.objects.get_or_create(user=user)

            if has_ai_access and not ai_profile.has_ai_access:
                # Granting access
                ai_profile.has_ai_access = True
                ai_profile.access_granted_by = request.user
                ai_profile.access_granted_at = timezone.now()
                ai_profile.save()
            elif not has_ai_access and ai_profile.has_ai_access:
                # Revoking access
                ai_profile.has_ai_access = False
                ai_profile.access_granted_by = None
                ai_profile.access_granted_at = None
                ai_profile.save()

        serializer = AdminUserSerializer(user)
        return Response(serializer.data)

    def delete(self, request: Request, user_id: str) -> Response:
        """Delete a user and all their data."""
        if error := self._check_admin(request):
            return error

        user = self._get_user(user_id)
        if not user:
            return Response(
                {"error": "User not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Prevent self-deletion
        if user.id == request.user.id:
            return Response(
                {"error": "Cannot delete your own account."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Delete user (cascades to projects, simulations, etc.)
        email = user.email
        user.delete()

        return Response(
            {
                "message": f"User {email} and all associated data deleted.",
            }
        )
