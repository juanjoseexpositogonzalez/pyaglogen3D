"""Canonical backend adapter for Rust projection geometry."""

from __future__ import annotations

import io
import math
from dataclasses import dataclass

import numpy as np
from PIL import Image

from .projection import render_projection_png, render_projection_svg

PROJECTION_CONTRACT_VERSION = "projection-geometry/v1"
PROJECTION_MIN_RESOLUTION = 128
PROJECTION_MAX_RESOLUTION = 2048
PROJECTION_DEFAULT_RESOLUTION = 512


class ProjectionContractError(ValueError):
    """Raised when the Rust projection payload is incomplete or ambiguous."""


@dataclass(frozen=True)
class ProjectionContract:
    """Canonical projection payload exchanged between Rust and backend services."""

    contract_version: str
    azimuth: float
    elevation: float
    x: list[float]
    y: list[float]
    radii: list[float]
    bounds: tuple[float, float, float, float]

    @property
    def particle_count(self) -> int:
        return len(self.x)

    def payload(self) -> dict[str, object]:
        """Return a structured, observable representation of the contract."""
        return {
            "contract_version": self.contract_version,
            "metadata": {
                "azimuth": self.azimuth,
                "elevation": self.elevation,
                "particle_count": self.particle_count,
            },
            "bounds": list(self.bounds),
            "points": [
                {"x": x, "y": y, "radius": radius}
                for x, y, radius in zip(self.x, self.y, self.radii, strict=True)
            ],
        }


def get_projection_contract_version() -> str:
    """Return the canonical contract version, preferring the Rust export when available."""
    try:
        import aglogen_core

        version_fn = getattr(aglogen_core, "projection_contract_version", None)
        if callable(version_fn):
            version = version_fn()
            if isinstance(version, str) and version:
                return version
    except Exception:
        pass

    return PROJECTION_CONTRACT_VERSION


def normalize_projection_result(result: object) -> ProjectionContract:
    """Validate the raw Rust projection result and map it into the canonical DTO."""
    x = list(getattr(result, "x", []))
    y = list(getattr(result, "y", []))
    radii = list(getattr(result, "radii", []))
    bounds_raw = getattr(result, "bounds", None)

    if not x or not y or not radii:
        raise ProjectionContractError(
            "Rust projection result is missing projected particle data"
        )

    if not (len(x) == len(y) == len(radii)):
        raise ProjectionContractError(
            "Rust projection result has mismatched x/y/radii lengths"
        )

    if bounds_raw is None or len(bounds_raw) != 4:
        raise ProjectionContractError(
            "Rust projection result must expose bounds as [min_x, max_x, min_y, max_y]"
        )

    contract_version = (
        getattr(result, "contract_version", None) or get_projection_contract_version()
    )
    if contract_version != PROJECTION_CONTRACT_VERSION:
        raise ProjectionContractError(
            f"Unsupported Rust projection contract '{contract_version}'. Expected '{PROJECTION_CONTRACT_VERSION}'"
        )

    try:
        azimuth = float(getattr(result, "azimuth", 0.0))
        elevation = float(getattr(result, "elevation", 0.0))
        x_values = [float(value) for value in x]
        y_values = [float(value) for value in y]
        radii_values = [float(value) for value in radii]
        bounds = tuple(float(value) for value in bounds_raw)
    except (TypeError, ValueError) as exc:
        raise ProjectionContractError(
            f"Rust projection result contains non-numeric values: {exc}"
        ) from exc

    if not math.isfinite(azimuth) or not math.isfinite(elevation):
        raise ProjectionContractError(
            "Rust projection result exposes non-finite view angles"
        )

    if any(
        not math.isfinite(value)
        for value in (*bounds, *x_values, *y_values, *radii_values)
    ):
        raise ProjectionContractError(
            "Rust projection result contains non-finite geometry values"
        )

    if any(radius <= 0 for radius in radii_values):
        raise ProjectionContractError(
            "Rust projection result contains non-positive particle radii"
        )

    min_x, max_x, min_y, max_y = bounds
    if min_x > max_x or min_y > max_y:
        raise ProjectionContractError(
            "Rust projection result exposes invalid bounds ordering"
        )

    return ProjectionContract(
        contract_version=contract_version,
        azimuth=azimuth,
        elevation=elevation,
        x=x_values,
        y=y_values,
        radii=radii_values,
        bounds=bounds,
    )


def project_geometry_to_contract(
    coordinates: np.ndarray,
    radii: np.ndarray,
    *,
    azimuth: float,
    elevation: float,
) -> ProjectionContract:
    """Project 3D geometry in Rust and return the canonical backend contract."""
    import aglogen_core

    result = aglogen_core.project_to_2d(
        coordinates=coordinates,
        radii=radii,
        azimuth=azimuth,
        elevation=elevation,
    )
    return normalize_projection_result(result)


def normalize_projection_resolution(
    resolution: object,
    *,
    default: int = PROJECTION_DEFAULT_RESOLUTION,
) -> int:
    """Normalize observable raster resolution across endpoint and task consumers."""
    value = default if resolution in (None, "") else resolution

    if isinstance(value, bool):
        raise ProjectionContractError("Projection resolution must be an integer")

    try:
        normalized = int(value)
    except (TypeError, ValueError) as exc:
        raise ProjectionContractError(
            f"Projection resolution must be an integer: {exc}"
        ) from exc

    try:
        numeric_value = float(value)
    except (TypeError, ValueError) as exc:
        raise ProjectionContractError(
            f"Projection resolution must be numeric: {exc}"
        ) from exc

    if float(normalized) != numeric_value:
        raise ProjectionContractError("Projection resolution must be an integer")

    if not (PROJECTION_MIN_RESOLUTION <= normalized <= PROJECTION_MAX_RESOLUTION):
        raise ProjectionContractError(
            "Projection resolution must be between "
            f"{PROJECTION_MIN_RESOLUTION} and {PROJECTION_MAX_RESOLUTION} pixels"
        )

    return normalized


def _render_projection_raster_image(
    contract: ProjectionContract,
    *,
    resolution: int,
) -> Image.Image:
    """Render canonical projection geometry into a normalized raster image."""
    png_bytes = render_projection_png(
        contract.x,
        contract.y,
        contract.radii,
        contract.bounds,
    )
    image = Image.open(io.BytesIO(png_bytes)).convert("RGBA")

    width, height = image.size
    longest_side = max(width, height)
    if longest_side <= 0:
        raise ProjectionContractError("Rendered projection image has invalid size")

    scale = resolution / longest_side
    target_size = (max(1, round(width * scale)), max(1, round(height * scale)))
    return image.resize(target_size, Image.Resampling.LANCZOS)


def render_projection_contract(
    contract: ProjectionContract,
    *,
    image_format: str = "png",
    resolution: int | None = None,
) -> bytes | str:
    """Render the canonical projection contract to PNG or SVG."""
    if image_format == "png":
        normalized_resolution = normalize_projection_resolution(resolution)
        image = _render_projection_raster_image(
            contract,
            resolution=normalized_resolution,
        )
        buffer = io.BytesIO()
        image.save(buffer, format="PNG")
        return buffer.getvalue()
    if image_format == "svg":
        return render_projection_svg(
            contract.x, contract.y, contract.radii, contract.bounds
        )

    raise ProjectionContractError(
        f"Unsupported projection render format '{image_format}'"
    )


def render_projection_grayscale_array(
    contract: ProjectionContract,
    *,
    resolution: int | None = None,
) -> np.ndarray:
    """Render canonical projection geometry into a grayscale numpy image for FRAKTAL."""
    normalized_resolution = normalize_projection_resolution(resolution)
    image = _render_projection_raster_image(
        contract,
        resolution=normalized_resolution,
    ).convert("L")
    return np.array(image, dtype=np.uint8)
