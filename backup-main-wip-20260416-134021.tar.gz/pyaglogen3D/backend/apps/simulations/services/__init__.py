"""Services for simulations app."""

from .projection import render_projection_png, render_projection_svg
from .projection_contract import (
    PROJECTION_CONTRACT_VERSION,
    ProjectionContract,
    ProjectionContractError,
    get_projection_contract_version,
    normalize_projection_result,
    project_geometry_to_contract,
    render_projection_contract,
    render_projection_grayscale_array,
)

__all__ = [
    "PROJECTION_CONTRACT_VERSION",
    "ProjectionContract",
    "ProjectionContractError",
    "get_projection_contract_version",
    "normalize_projection_result",
    "project_geometry_to_contract",
    "render_projection_contract",
    "render_projection_grayscale_array",
    "render_projection_png",
    "render_projection_svg",
]
