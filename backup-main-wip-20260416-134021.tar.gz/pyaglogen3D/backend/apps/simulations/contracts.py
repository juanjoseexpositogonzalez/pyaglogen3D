"""Canonical scientific contracts for simulation geometry and projections."""

from __future__ import annotations

import io
from dataclasses import dataclass
from typing import Any

import numpy as np

GEOMETRY_NPY_CONTRACT_VERSION = "geometry-npy/v1"
GEOMETRY_NPY_EXPECTED_COLUMNS = ("x", "y", "z", "radius")
GEOMETRY_NPY_EXPECTED_DTYPE = np.dtype(np.float64)
GEOMETRY_NPY_EXPECTED_SHAPE = "(N,4)"


class GeometryContractError(ValueError):
    """Raised when stored geometry does not match the canonical `.npy` contract."""


@dataclass(frozen=True)
class GeometryContractMetadata:
    """Serializable metadata for the canonical geometry contract."""

    version: str = GEOMETRY_NPY_CONTRACT_VERSION
    shape: str = GEOMETRY_NPY_EXPECTED_SHAPE
    dtype: str = "<f8"
    columns: tuple[str, ...] = GEOMETRY_NPY_EXPECTED_COLUMNS


def geometry_contract_metadata() -> GeometryContractMetadata:
    """Return canonical geometry contract metadata."""
    return GeometryContractMetadata()


def validate_geometry_array(array: Any, *, source: str = "geometry") -> np.ndarray:
    """Validate and normalize a geometry array to the canonical `(N,4)` layout."""
    geometry_array = np.asarray(array)

    if geometry_array.ndim != 2:
        raise GeometryContractError(
            f"{source} must be a 2D array with shape {GEOMETRY_NPY_EXPECTED_SHAPE}; "
            f"got {geometry_array.ndim} dimensions"
        )

    if geometry_array.shape[1] != len(GEOMETRY_NPY_EXPECTED_COLUMNS):
        raise GeometryContractError(
            f"{source} must have shape {GEOMETRY_NPY_EXPECTED_SHAPE}; "
            f"got {tuple(geometry_array.shape)}"
        )

    if geometry_array.shape[0] == 0:
        raise GeometryContractError(f"{source} must contain at least one particle")

    if not np.issubdtype(geometry_array.dtype, np.number):
        raise GeometryContractError(
            f"{source} must contain numeric values; got dtype {geometry_array.dtype}"
        )

    normalized = np.asarray(geometry_array, dtype=GEOMETRY_NPY_EXPECTED_DTYPE)

    if not np.isfinite(normalized).all():
        raise GeometryContractError(f"{source} contains non-finite values")

    if np.any(normalized[:, 3] <= 0):
        raise GeometryContractError(f"{source} contains non-positive particle radii")

    return np.ascontiguousarray(normalized)


def dump_geometry_npy(array: Any) -> bytes:
    """Serialize geometry to the canonical `.npy` binary payload."""
    normalized = validate_geometry_array(array)
    buffer = io.BytesIO()
    np.save(buffer, normalized, allow_pickle=False)
    return buffer.getvalue()


def load_geometry_npy(
    payload: bytes | bytearray | memoryview, *, source: str = "geometry"
) -> np.ndarray:
    """Load and validate geometry from a `.npy` binary payload."""
    if not payload:
        raise GeometryContractError(f"{source} payload is empty")

    try:
        geometry_array = np.load(io.BytesIO(bytes(payload)), allow_pickle=False)
    except Exception as exc:  # pragma: no cover - numpy error surface varies
        raise GeometryContractError(
            f"{source} is not a valid NumPy `.npy` payload: {exc}"
        ) from exc

    return validate_geometry_array(geometry_array, source=source)


def split_geometry_columns(
    geometry: bytes | bytearray | memoryview | np.ndarray,
    *,
    source: str = "geometry",
) -> tuple[np.ndarray, np.ndarray]:
    """Return contiguous coordinate and radius arrays from stored geometry."""
    if isinstance(geometry, np.ndarray):
        geometry_array = validate_geometry_array(geometry, source=source)
    else:
        geometry_array = load_geometry_npy(geometry, source=source)

    coordinates = np.ascontiguousarray(geometry_array[:, :3])
    radii = np.ascontiguousarray(geometry_array[:, 3])
    return coordinates, radii
