# Chapter 11: AI Assistant Integration

This chapter documents the AI Assistant feature, which provides conversational AI capabilities with automatic tool calling to help users with simulation and analysis tasks.

## 11.1 Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                    Frontend Chat Interface                       │
│  React + TypeScript                                              │
│  - Message history                                               │
│  - Tool call visualization                                       │
│  - Project context selection                                     │
└─────────────────────────────────────────────────────────────────┘
                              │ REST API
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      ChatView Endpoint                           │
│  /api/v1/ai/chat/                                                │
│  - Receives user messages                                        │
│  - Orchestrates AI + tool calling loop                           │
│  - Returns final response with tool history                      │
└─────────────────────────────────────────────────────────────────┘
                              │
         ┌────────────────────┼────────────────────┐
         ▼                    ▼                    ▼
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│ AI Service  │      │Tool Registry│      │Tool Executor│
│ (Providers) │      │ (Definitions)│      │  (Context)  │
└─────────────┘      └─────────────┘      └─────────────┘
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    AI Provider Adapters                          │
│  - Anthropic (Claude)                                            │
│  - OpenAI (GPT)                                                  │
│  - Groq (Llama)                                                  │
│  - xAI (Grok)                                                    │
└─────────────────────────────────────────────────────────────────┘
```

---

## 11.2 Backend Components

### AI Service

```
Location: backend/apps/ai_assistant/services/ai_service.py

AIService:
├── __init__(user) - Initialize for specific user
├── get_provider() - Get configured provider instance
├── complete(messages, ...) - Simple completion without tools
├── complete_with_tools(messages, tools, ...) - Completion with tool definitions
└── test_connection() - Verify provider connectivity

Responsibilities:
- Load user's provider configuration
- Decrypt API keys using Fernet encryption
- Create appropriate provider instance
- Handle provider-agnostic conversation interface
```

### Provider Abstraction

```
Location: backend/apps/ai_assistant/services/providers/

BaseProvider (Abstract):
├── provider_name (property) - "anthropic", "openai", etc.
├── complete(messages, ...) -> AIResponse
└── complete_with_tools(messages, tools, ...) -> AIResponse

Implementations:
├── AnthropicProvider - Claude models
├── OpenAIProvider - GPT models (also works with compatible APIs)
├── GroqProvider - Llama models via Groq
└── XAIProvider - Grok models

Response Format (AIResponse):
├── content: str | None - Text response
├── tool_calls: list[ToolCall] - Requested tool invocations
├── stop_reason: StopReason - END_TURN, TOOL_USE, MAX_TOKENS, ERROR
├── usage: TokenUsage - Input/output token counts
├── model: str - Model identifier
└── provider: str - Provider name
```

### Tool System

```
Location: backend/apps/ai_assistant/tools/

Components:
├── base.py - ToolDefinition, ToolResult, ToolError dataclasses
├── registry.py - Singleton registry for tool management
├── decorators.py - @tool decorator for easy registration
├── executor.py - Tool execution with context injection
├── context.py - ContextManager for user/project context
└── validation.py - JSON Schema validation

ToolDefinition:
├── name: str - Unique identifier
├── description: str - Human-readable description
├── parameters: dict - JSON Schema for arguments
├── handler: Callable - Function to execute
├── category: str - Grouping (simulation, analysis, utility)
├── requires_project: bool - Needs project context
└── is_async: bool - Runs as Celery task
```

### Tool Registration Pattern

```
Location: backend/apps/ai_assistant/tools/utility_tools.py

@tool(
    name="list_algorithms",
    description="List all available agglomeration algorithms with their parameters",
    category="utility",
    requires_project=False,
)
def list_algorithms() -> dict:
    """Return information about available algorithms."""
    return {
        "algorithms": [
            {
                "name": "dla",
                "full_name": "Diffusion-Limited Aggregation",
                "parameters": ["n_particles", "sticking_probability", "lattice_size"],
                "description": "Classic DLA algorithm..."
            },
            # ...
        ]
    }
```

### Chat Endpoint

```
Location: backend/apps/ai_assistant/views.py

ChatView:
├── POST /api/v1/ai/chat/
├── Permission: IsAuthenticated + IsAIUser
└── Max iterations: 10 (prevents infinite loops)

Request:
{
  "messages": [
    {"role": "user", "content": "What algorithms are available?"}
  ],
  "project_id": "uuid" (optional)
}

Response:
{
  "message": "Here are the available algorithms...",
  "tool_calls": [
    {
      "id": "tool_call_123",
      "name": "list_algorithms",
      "arguments": {},
      "success": true,
      "result": {...}
    }
  ],
  "usage": {
    "input_tokens": 1523,
    "output_tokens": 456
  }
}

Conversation Loop:
1. Send messages + tools to AI
2. If AI requests tool_calls:
   a. Execute each tool
   b. Add results to conversation
   c. Loop back to step 1
3. If AI returns text: return final response
4. Safety: max 10 iterations
```

---

## 11.3 Provider Configuration

### Database Model

```
Location: backend/apps/ai_assistant/models.py

AIProviderConfig:
├── id: UUID (primary key)
├── user: ForeignKey(User)
├── provider: CharField (anthropic, openai, groq, xai)
├── api_key_encrypted: TextField (Fernet encrypted)
├── model_name: CharField (e.g., "claude-sonnet-4-20250514")
├── is_default: BooleanField
├── is_active: BooleanField
├── created_at: DateTimeField
└── updated_at: DateTimeField

Constraints:
- unique_together: (user, provider)
- Only one default per user
```

### Encryption Service

```
Location: backend/apps/ai_assistant/services/encryption.py

EncryptionService:
├── encrypt(plaintext) -> ciphertext
└── decrypt(ciphertext) -> plaintext

Configuration:
- AI_ENCRYPTION_KEY environment variable
- Fernet symmetric encryption
- Key should be 32 bytes URL-safe base64

Generate Key:
from cryptography.fernet import Fernet
key = Fernet.generate_key()
```

### Access Control

```
Location: backend/apps/ai_assistant/models.py

AIUserProfile:
├── user: OneToOneField(User)
├── has_ai_access: BooleanField (default=False)
├── access_granted_at: DateTimeField
├── access_granted_by: ForeignKey(User) - Admin who granted
└── notes: TextField

Access Rules:
1. Staff users always have access
2. Users with has_ai_access=True have access
3. In DEBUG mode, all authenticated users have access
4. Others see "Access Required" message
```

---

## 11.4 Frontend Components

### API Client

```
Location: frontend/src/lib/ai-api.ts

aiApi:
├── checkAccess() -> AIAccessResponse
├── listProviders() -> { results: AIProvider[] }
├── createProvider(data) -> AIProvider
├── updateProvider(id, data) -> AIProvider
├── deleteProvider(id) -> void
├── testProvider(id) -> { success, message }
├── setDefaultProvider(id) -> { message }
├── listTools(category?) -> ToolsResponse
├── executeTool(name, args, projectId?) -> ToolExecutionResult
└── chat(messages, projectId?) -> ChatResponse

Types:
├── ChatMessage { role, content, tool_call_id? }
├── ChatResponse { message, tool_calls, usage }
├── ToolCallInfo { id, name, arguments, success, result?, error? }
└── AIAccessResponse { has_access, reason }
```

### Chat Page

```
Location: frontend/src/app/ai/page.tsx

State:
├── messages: DisplayMessage[] - Conversation history
├── inputValue: string - Current input
├── isSending: boolean - Loading state
├── selectedProject: string - Project context
├── expandedToolCalls: Set<string> - Expanded tool details
└── hasAccess: boolean - Access check result

Features:
├── Message history with user/assistant avatars
├── Inline tool call display (expandable)
├── Project selector for context
├── Quick suggestion buttons
├── Auto-scroll to latest message
└── Error handling with retry
```

### Settings Page

```
Location: frontend/src/app/ai/settings/page.tsx

Features:
├── Add new provider configuration
├── Test provider connection
├── Set default provider
├── Delete provider
└── Model selection per provider

Supported Providers:
├── Anthropic: claude-sonnet-4, claude-opus-4, claude-3-5-haiku
├── OpenAI: gpt-4.1, gpt-4o, o1, o3-mini
├── Groq: llama-3.3-70b, llama-3.1-8b, gemma2-9b
└── xAI: grok-3, grok-2, grok-2-vision
```

---

## 11.5 Available Tools

### Utility Tools

```
list_algorithms:
  Description: List all available agglomeration algorithms
  Parameters: None
  Returns: Algorithm details with parameters

get_algorithm_info:
  Description: Get detailed information about a specific algorithm
  Parameters: algorithm_name (string)
  Returns: Full algorithm documentation
```

### Simulation Tools

```
run_simulation:
  Description: Run a new simulation
  Parameters: algorithm, parameters, project_id
  Returns: Simulation ID and initial status
  Requires: Project context

get_simulation_status:
  Description: Check simulation status
  Parameters: simulation_id
  Returns: Status, metrics if completed
```

### Analysis Tools

```
analyze_fractal_dimension:
  Description: Analyze fractal dimension of a simulation
  Parameters: simulation_id, method (box_counting_3d, fraktal)
  Returns: Df, kf, Rg values

compare_simulations:
  Description: Compare metrics across simulations
  Parameters: simulation_ids[]
  Returns: Comparative statistics
```

### Study Tools

```
get_study_results:
  Description: Get parametric study results
  Parameters: study_id
  Returns: Progress, aggregated metrics

create_parameter_sweep:
  Description: Create a new parametric study
  Parameters: base_algorithm, parameter_grid, seeds_per_combination
  Returns: Study ID, total simulations
```

---

## 11.6 System Prompt

```
Location: backend/apps/ai_assistant/views.py

ASSISTANT_SYSTEM_PROMPT = """
You are an AI assistant specialized in agglomeration studies and
fractal analysis for the PyAglogen3D application.

You help users with:
- Running and analyzing particle agglomeration simulations
- Performing fractal analysis on simulation results
- Understanding different agglomeration algorithms (DLA, DLCA, BA, BPCA, RLCA, RCLA)
- Managing projects and studies
- Interpreting results and statistics

You have access to tools that can:
- List available algorithms and their parameters
- Run simulations with specific configurations
- Analyze existing simulation results
- Perform fractal dimension calculations
- Get project and study information

IMPORTANT LIMITATIONS - Be honest about these:
- You have NO persistent memory between conversations
- You CANNOT proactively monitor simulations or notify users later
- You CANNOT "wait" for something to complete and then respond
- Each conversation is independent - you start fresh every time
- If a simulation is queued/running, tell the user they need to come back
  and ask you to check the status

When a user asks a question:
1. Use the appropriate tool(s) to gather information
2. Explain the results in a clear, helpful way
3. Offer follow-up suggestions when relevant

When queuing simulations or long-running tasks:
- Clearly state the simulation ID so users can reference it later
- Tell users they need to return and ask you to check the status
- NEVER promise to "let them know" or "notify them" when something completes

Be concise but thorough. Format numbers appropriately and use
markdown for clarity when helpful.
"""
```

---

## 11.7 Adding New Tools

### Step 1: Define the Tool

```python
# backend/apps/ai_assistant/tools/my_tools.py

from .decorators import tool

@tool(
    name="my_new_tool",
    description="Description shown to the AI",
    category="analysis",
    requires_project=True,
)
def my_new_tool(
    required_param: str,
    optional_param: int = 10,
    user: User = None,  # Injected automatically
    project_id: str = None,  # Injected automatically
) -> dict:
    """
    Implementation details.

    The user and project_id parameters are injected by the executor
    based on the request context. Don't include them in parameters schema.
    """
    # Your implementation
    return {
        "result": "value",
        "status": "success"
    }
```

### Step 2: Register the Tool

```python
# backend/apps/ai_assistant/tools/registration.py

from .my_tools import my_new_tool  # Decorators auto-register

# Or manual registration:
from .registry import get_registry
from .base import ToolDefinition

registry = get_registry()
registry.register(ToolDefinition(
    name="manual_tool",
    description="...",
    parameters={...},
    handler=my_handler_function,
    category="utility",
))
```

### Step 3: Restart the Application

```bash
# Tools are registered at application startup
python manage.py runserver

# Verify registration
from apps.ai_assistant.tools.registry import get_registry
registry = get_registry()
print(registry.get_all_tools())
```

---

## 11.8 API Reference

### Provider Configuration Endpoints

```
GET /api/v1/ai/providers/
  List user's provider configurations
  Response: { results: AIProvider[] }

POST /api/v1/ai/providers/
  Create new provider configuration
  Body: { provider, api_key, model_name, is_default? }
  Response: AIProvider

PATCH /api/v1/ai/providers/{id}/
  Update provider configuration
  Body: { model_name?, is_default? }
  Response: AIProvider

DELETE /api/v1/ai/providers/{id}/
  Delete provider configuration
  Response: 204 No Content

POST /api/v1/ai/providers/{id}/test_connection/
  Test provider API key
  Response: { success, message, response? }

POST /api/v1/ai/providers/{id}/set_default/
  Set as default provider
  Response: { message }
```

### Chat Endpoint

```
POST /api/v1/ai/chat/
  Send message and get AI response
  Body: {
    messages: [{ role: "user"|"assistant", content: string }],
    project_id?: string
  }
  Response: {
    message: string,
    tool_calls: ToolCallInfo[],
    usage: { input_tokens, output_tokens }
  }
```

### Access Check

```
GET /api/v1/ai/access/
  Check if user has AI access
  Response: {
    has_access: boolean,
    reason: "staff" | "granted" | "debug_mode" | "not_granted"
  }
```

### Tool Endpoints

```
GET /api/v1/ai/tools/
  List all available tools
  Query: category? (filter by category)
  Response: { tools: Tool[], count, categories }

POST /api/v1/ai/tools/{name}/execute/
  Execute tool directly (for testing)
  Body: { arguments: object, project_id?: string }
  Response: ToolExecutionResult
```

---

## 11.9 Security Considerations

### API Key Storage

```
- API keys are encrypted using Fernet symmetric encryption
- AI_ENCRYPTION_KEY must be set in environment
- Keys are never logged or returned in API responses
- Failed decryption returns generic error message
```

### Access Control

```
- AIUserProfile.has_ai_access controls per-user access
- Staff bypass access check automatically
- Access grants are audited (who, when)
- Admin panel allows granting/revoking access
```

### Rate Limiting

```
Consider implementing:
- Per-user message rate limits
- Token usage quotas per user
- Provider-level rate limit handling
- Cost tracking per user
```

### Input Validation

```
- Tool arguments validated against JSON Schema
- SQL injection prevented by Django ORM
- XSS prevented by DRF serialization
- Project access verified before tool execution
```

---

## 11.10 Deployment Configuration

### Environment Variables

```
# Required for AI features
AI_ENCRYPTION_KEY=your-fernet-key-here

# Set on Fly.io
fly secrets set AI_ENCRYPTION_KEY="..."

# Generate key
python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

### Provider API Keys

```
Users configure their own API keys through the Settings page.
Keys are stored encrypted per-user in the database.

Supported key formats:
- Anthropic: sk-ant-...
- OpenAI: sk-...
- Groq: gsk_...
- xAI: xai-...
```

---

## 11.11 Implementation Checklist

### Backend Setup
- [ ] AI_ENCRYPTION_KEY set in environment
- [ ] Database migrations applied (ai_assistant app)
- [ ] Tool registration verified
- [ ] Provider adapters tested

### Frontend Setup
- [ ] AI pages accessible (/ai, /ai/settings)
- [ ] Provider configuration working
- [ ] Chat interface functional
- [ ] Access control working (non-admin users blocked)

### Admin Setup
- [ ] AIUserProfile manageable in Django Admin
- [ ] Frontend Admin Panel shows AI access toggle
- [ ] Access grants working

### Testing
- [ ] Provider connection tests passing
- [ ] Tool execution tests passing
- [ ] Chat conversation tests passing
- [ ] Access control tests passing
