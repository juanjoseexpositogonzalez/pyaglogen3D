# Chapter 8: Batch Simulations and Parametric Studies

This chapter documents the parametric study system for running batch simulations with systematic parameter exploration, including grid generation, Celery orchestration, results aggregation, and integration with box-counting analysis.

## 8.1 Parametric Study Architecture

### Purpose and Motivation

Parametric studies enable researchers to explore how agglomerate morphology changes across parameter ranges. Rather than running simulations one at a time, researchers can define parameter grids and automatically generate all combinations.

**Common use cases:**

| Study Type | Varied Parameters | Research Goal |
|------------|-------------------|---------------|
| Df Sensitivity | target_df: [1.5, 1.8, 2.1, 2.5] | Morphology vs. fractal dimension |
| Size Effects | n_particles: [100, 500, 1000, 5000] | Finite-size scaling |
| Sintering Impact | sintering_coeff: [0.5, 0.75, 0.9, 1.0] | Contact overlap effects |
| Multi-dimensional | target_df + n_particles grid | Combined parameter interactions |

### Data Model

The ParametricStudy model orchestrates batch simulations:

```
ParametricStudy
├── id: UUID (primary key)
├── project: FK -> Project
├── name: str (user-facing label)
├── description: str (optional notes)
├── base_algorithm: enum (dla, cca, tunable, etc.)
├── base_parameters: JSON (fixed params for all simulations)
├── parameter_grid: JSON (params to vary: {name: [values]})
├── seeds_per_combination: int (replications per point)
├── include_limiting_cases: bool (add boundary/extreme cases)
├── limiting_cases_config: JSON (optional config)
├── sintering_config: JSON (sintering distribution params)
├── include_box_counting: bool (run 3D box-counting)
├── box_counting_params: JSON (precision, points_per_sphere)
├── simulations: M2M -> Simulation (all generated sims)
├── status: enum (queued, running, completed, failed)
├── created_at: datetime
└── completed_at: datetime
```

**Relationships:**

```
ParametricStudy 1 ──────── * Simulation
      │                          │
      └──────── FK ──────────────┤
                                 │
Project 1 ─────────────────── * ParametricStudy
```

### Study Lifecycle

```
┌─────────────────────────────────────────────────────────────┐
│                     Study Creation                          │
│                                                             │
│  1. User submits study parameters                           │
│  2. ViewSet.perform_create() validates input                │
│  3. Generate all parameter combinations                     │
│  4. Create Simulation objects for each combination          │
│  5. Queue all simulations to Celery                         │
│  6. Return study ID and total count                         │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     Execution                               │
│                                                             │
│  - Celery workers process simulations independently         │
│  - Each simulation runs aglogen_core algorithm              │
│  - Optional: box-counting runs after each completion        │
│  - Status tracked per-simulation                            │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     Results Aggregation                     │
│                                                             │
│  - results/ endpoint aggregates all simulation metrics      │
│  - export/ endpoint generates CSV with all data             │
│  - Progress tracked as completed/total ratio                │
└─────────────────────────────────────────────────────────────┘
```

---

## 8.2 Parameter Grid Generation

### Grid Combination Algorithm

The grid generation uses Cartesian product of all parameter arrays:

```
ALGORITHM Generate_Parameter_Combinations
INPUT:
    base_parameters: dict (fixed params like algorithm settings)
    parameter_grid: dict[str, list] (params to vary)
    seeds_per_combination: int (replications)

OUTPUT:
    combinations: list of (params, seed) tuples

PROCEDURE:
    param_names = list(parameter_grid.keys())
    param_values = [parameter_grid[name] for name in param_names]

    # Cartesian product
    grid_points = cartesian_product(*param_values)
    # e.g., for {df: [1.8, 2.1], N: [100, 500]}
    # grid_points = [(1.8, 100), (1.8, 500), (2.1, 100), (2.1, 500)]

    combinations = []

    FOR combo in grid_points:
        params = dict(base_parameters)

        FOR i, name in enumerate(param_names):
            params[name] = combo[i]

        # Multiple seeds per combination
        FOR seed_idx in 0..seeds_per_combination:
            seed = random_int(0, 2^31 - 1)
            combinations.append((params, seed))

    RETURN combinations
```

### Limiting Cases Generation

When `include_limiting_cases=True`, the system adds boundary and theoretical extreme cases:

```
ALGORITHM Generate_Limiting_Cases
INPUT:
    base_parameters: dict
    parameter_grid: dict
    algorithm: str
    limiting_config: dict | None

OUTPUT:
    limiting_cases: list of (case_type, description, params)

PROCEDURE:
    cases = []
    seen = set()  # Avoid duplicates

    # 1. Range Boundaries
    IF limiting_config.include_boundaries (default True):
        FOR param_name, values in parameter_grid:
            sorted_values = sort(values)
            min_val = sorted_values[0]
            max_val = sorted_values[-1]

            # Add min boundary
            params = dict(base_parameters)
            params[param_name] = min_val
            IF (param_name, min_val) not in seen:
                cases.append(("boundary_min", f"{param_name}={min_val}", params))
                seen.add((param_name, min_val))

            # Add max boundary
            params = dict(base_parameters)
            params[param_name] = max_val
            IF (param_name, max_val) not in seen:
                cases.append(("boundary_max", f"{param_name}={max_val}", params))
                seen.add((param_name, max_val))

    # 2. Theoretical Extremes (algorithm-specific)
    IF limiting_config.include_theoretical (default True):
        extremes = THEORETICAL_EXTREMES[algorithm]
        # e.g., for tunable: target_df = [1.0, 1.8, 2.5, 3.0]

        FOR param_name, extreme_values in extremes:
            FOR val in extreme_values:
                IF (param_name, val) not in seen:
                    params = dict(base_parameters)
                    params[param_name] = val
                    cases.append(("theoretical", f"{param_name}={val}", params))
                    seen.add((param_name, val))

    RETURN cases
```

### Theoretical Extreme Values

The system includes predefined theoretical extremes for each algorithm:

| Algorithm | Parameter | Extreme Values | Rationale |
|-----------|-----------|----------------|-----------|
| tunable | target_df | [1.0, 1.8, 2.5, 3.0] | Chain to compact |
| tunable | target_kf | [1.0, 1.3, 2.0] | Prefactor range |
| dla, cca | sticking_probability | [0.1, 1.0] | Diffuse to sticky |
| limiting | configuration_type | [lineal, plano, cuboctaedro, ...] | Df=1,2,3 references |
| limiting | sintering_coeff | [0.5, 0.75, 0.9, 1.0] | Overlap extremes |

---

## 8.3 Sintering Configuration

### Distribution Types

The sintering coefficient can follow three distribution types:

```
SINTERING DISTRIBUTION TYPES

Fixed:
    sintering_coeff = constant
    Usage: All particles use same overlap
    Config: {"distribution_type": "fixed", "coefficient": 0.9}

Uniform:
    sintering_coeff ~ Uniform(min, max)
    Usage: Random overlap within range
    Config: {"distribution_type": "uniform", "min": 0.85, "max": 0.95}

Normal:
    sintering_coeff ~ Normal(mean, std), clamped to [0.5, 1.0]
    Usage: Natural variation around mean
    Config: {"distribution_type": "normal", "mean": 0.9, "std": 0.05}
```

### Application Algorithm

```
ALGORITHM Apply_Sintering_Config
INPUT:
    parameters: dict (simulation params)
    sintering_config: dict (distribution config)

OUTPUT:
    updated_parameters: dict

PROCEDURE:
    params = dict(parameters)
    dist_type = sintering_config.get("distribution_type", "fixed")
    params["sintering_type"] = dist_type

    SWITCH dist_type:
        CASE "fixed":
            params["sintering_coeff"] = sintering_config.get("coefficient", 1.0)

        CASE "uniform":
            params["sintering_min"] = sintering_config.get("min", 0.85)
            params["sintering_max"] = sintering_config.get("max", 0.95)

        CASE "normal":
            params["sintering_mean"] = sintering_config.get("mean", 0.9)
            params["sintering_std"] = sintering_config.get("std", 0.05)

    RETURN params
```

### Sintering Extreme Cases

When both `include_limiting_cases` and `sintering_config` are enabled, the system adds extreme sintering cases:

```
Sintering Extremes:
├── coeff=0.5:  Maximum sintering (50% overlap, very compact)
├── coeff=0.75: High sintering (25% overlap)
├── coeff=0.9:  Moderate sintering (10% overlap, typical)
└── coeff=1.0:  No sintering (particles just touch)
```

These are created as separate simulations to show the full range of sintering effects.

---

## 8.4 Celery Task Orchestration

### Task Queuing Strategy

When a study is created, all simulations are queued immediately:

```
ALGORITHM Queue_Study_Simulations
INPUT:
    study: ParametricStudy
    simulations: list of Simulation

PROCEDURE:
    FOR sim in simulations:
        # Submit to Celery
        TRY:
            result = run_simulation_task.delay(str(sim.id))
            sim.task_id = result.id
            sim.save(update_fields=["task_id"])
        CATCH Exception:
            # Log warning but continue with other simulations
            logger.warning(f"Failed to queue {sim.id}")

    # Study status is "running" until all complete
    study.status = "running"
    study.save()
```

### Worker Concurrency

Each Celery worker processes simulations independently:

```
┌─────────────────────────────────────────────────────────────┐
│                     Redis Queue                             │
│  [sim_1, sim_2, sim_3, sim_4, sim_5, sim_6, ...]           │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│  Worker 1   │      │  Worker 2   │      │  Worker 3   │
│  sim_1      │      │  sim_2      │      │  sim_3      │
│  sim_4      │      │  sim_5      │      │  sim_6      │
│  ...        │      │  ...        │      │  ...        │
└─────────────┘      └─────────────┘      └─────────────┘
```

**Optimal concurrency settings:**

| Deployment | Workers | Concurrency | Notes |
|------------|---------|-------------|-------|
| Development | 1 | 2 | Single worker, 2 threads |
| Small Server | 2 | 4 | 2 workers, 2 threads each |
| Production | 4+ | 2 per worker | Scale workers not threads |

### Box-Counting Integration

When `include_box_counting=True`, box-counting runs automatically after each simulation completes:

```
ALGORITHM Run_Box_Counting_If_Configured
INPUT:
    simulation_id: str

PROCEDURE:
    simulation = Simulation.objects.get(id=simulation_id)

    # Check if simulation belongs to a study with box-counting
    studies = simulation.studies.filter(include_box_counting=True)
    IF studies.empty():
        RETURN None

    IF simulation.geometry is None:
        RETURN None

    # Get box-counting params from study
    study = studies.first()
    bc_params = study.box_counting_params or {}
    points_per_sphere = bc_params.get("points_per_sphere", 100)
    precision = bc_params.get("precision", 18)

    # Load geometry
    coords, radii = load_geometry(simulation.geometry)

    # Run box-counting
    result = aglogen_core.box_counting_agglomerate(
        coords, radii,
        points_per_sphere=points_per_sphere,
        precision=precision
    )

    # Store results in simulation metrics
    metrics = simulation.metrics or {}
    metrics["box_counting"] = {
        "dimension": result.dimension,
        "r_squared": result.r_squared,
        "std_error": result.std_error,
        "confidence_interval": list(result.confidence_interval),
        "log_scales": result.log_scales.tolist(),
        "log_values": result.log_values.tolist(),
        "execution_time_ms": result.execution_time_ms,
        "parameters": {
            "points_per_sphere": points_per_sphere,
            "precision": precision,
        },
    }
    simulation.metrics = metrics
    simulation.save(update_fields=["metrics"])

    RETURN metrics["box_counting"]
```

---

## 8.5 Results Aggregation

### Progress Tracking

The `/studies/{id}/results/` endpoint aggregates all simulation results:

```
ALGORITHM Aggregate_Study_Results
INPUT:
    study: ParametricStudy

OUTPUT:
    results_response: dict

PROCEDURE:
    simulations = study.simulations.order_by("created_at")

    # Calculate progress
    total = simulations.count()
    completed = simulations.filter(status="completed").count()
    failed = simulations.filter(status="failed").count()
    running = simulations.filter(status__in=["queued", "running"]).count()

    results = []
    FOR sim in simulations:
        result_data = {
            "simulation_id": str(sim.id),
            "status": sim.status,
            "parameters": sim.parameters,
            "seed": sim.seed,
            "execution_time_ms": sim.execution_time_ms,
        }

        IF sim.metrics:
            result_data.update({
                "fractal_dimension": sim.metrics.get("fractal_dimension"),
                "fractal_dimension_std": sim.metrics.get("fractal_dimension_std"),
                "prefactor": sim.metrics.get("prefactor"),
                "radius_of_gyration": sim.metrics.get("radius_of_gyration"),
                "porosity": sim.metrics.get("porosity"),
                "coordination_mean": sim.metrics.get("coordination", {}).get("mean"),
                "anisotropy": sim.metrics.get("anisotropy"),
                "box_counting": sim.metrics.get("box_counting"),
            })

        results.append(result_data)

    RETURN {
        "study_id": str(study.id),
        "status": "completed" if running == 0 else "running",
        "progress": {
            "total": total,
            "completed": completed,
            "failed": failed,
            "running": running,
        },
        "results": results,
    }
```

### Statistics Computation

For completed studies, compute aggregate statistics across replications:

```
STATISTICS COMPUTED PER PARAMETER POINT

Given multiple seeds for same parameter combination:
├── fractal_dimension:
│   ├── mean: average Df across seeds
│   ├── std: standard deviation
│   └── range: [min, max]
├── radius_of_gyration:
│   ├── mean
│   └── std
├── porosity:
│   ├── mean
│   └── std
└── box_counting.dimension:
    ├── mean
    └── std
```

---

## 8.6 CSV Export

### Export Format

The `/studies/{id}/export/` endpoint generates a comprehensive CSV:

```
CSV STRUCTURE

Header Row:
Simulation ID, Name, Seed, [grid params], Df, Df_std, kf, Rg, Porosity,
Coord_Mean, Coord_Std, Anisotropy, Asphericity, Acylindricity, Execution_ms,
[Sintering_Type, Sintering_Coeff],  # If sintering configured
[BC_Df, BC_R2, BC_StdError, BC_Time_ms]  # If box-counting enabled

Example Row:
uuid-123, "Tunable Simulation - 2024-02-20 (grid: target_df=1.8)", 42,
1.8, 500, 1.82, 0.05, 1.32, 15.4, 0.78,
2.4, 1.1, 1.15, 0.08, 0.03, 523,
fixed, 0.900,
1.85, 0.998, 0.02, 45
```

### Export Algorithm

```
ALGORITHM Export_Study_CSV
INPUT:
    study: ParametricStudy

OUTPUT:
    csv_content: str

PROCEDURE:
    simulations = study.simulations.filter(status="completed").order_by("created_at")
    param_keys = list(study.parameter_grid.keys())

    # Build header
    header = ["Simulation ID", "Name", "Seed"] + param_keys
    header += ["Df", "Df_std", "kf", "Rg", "Porosity",
               "Coord_Mean", "Coord_Std",
               "Anisotropy", "Asphericity", "Acylindricity",
               "Execution_ms"]

    IF study.sintering_config:
        header += ["Sintering_Type", "Sintering_Coeff"]

    IF study.include_box_counting:
        header += ["BC_Df", "BC_R2", "BC_StdError", "BC_Time_ms"]

    # Build rows
    rows = []
    FOR sim in simulations:
        IF sim.metrics:
            row = [
                str(sim.id),
                sim.name or "",
                sim.seed,
            ] + [sim.parameters.get(key, "") for key in param_keys]

            row += [
                format_float(sim.metrics.get("fractal_dimension"), 4),
                format_float(sim.metrics.get("fractal_dimension_std"), 4),
                format_float(sim.metrics.get("prefactor"), 4),
                # ... more metrics
            ]

            IF study.sintering_config:
                row += [
                    sim.parameters.get("sintering_type", "fixed"),
                    format_float(sim.parameters.get("sintering_coeff", 1.0), 3),
                ]

            IF study.include_box_counting:
                bc = sim.metrics.get("box_counting", {})
                row += [
                    format_float(bc.get("dimension"), 4),
                    format_float(bc.get("r_squared"), 4),
                    format_float(bc.get("std_error"), 6),
                    bc.get("execution_time_ms", 0),
                ]

            rows.append(row)

    RETURN csv_from_rows(header, rows)
```

---

## 8.7 API Contract

### Create Parametric Study

```
POST /api/v1/projects/{project_id}/studies/

Request Body:
{
    "name": "Df vs N Study",
    "description": "Exploring fractal dimension sensitivity to particle count",
    "base_algorithm": "tunable",
    "base_parameters": {
        "target_kf": 1.3,
        "sticking_probability": 1.0
    },
    "parameter_grid": {
        "n_particles": [500, 1000, 2000],
        "target_df": [1.8, 2.1, 2.5]
    },
    "seeds_per_combination": 3,
    "include_limiting_cases": true,
    "limiting_cases_config": {
        "include_boundaries": true,
        "include_theoretical": true
    },
    "sintering_config": {
        "distribution_type": "normal",
        "mean": 0.9,
        "std": 0.05
    },
    "include_box_counting": true,
    "box_counting_params": {
        "points_per_sphere": 100,
        "precision": 18
    }
}

Response 201:
{
    "id": "uuid-study",
    "total_simulations": 45,
    "status": "running"
}
```

### Get Study Results

```
GET /api/v1/projects/{project_id}/studies/{id}/results/

Response 200:
{
    "study_id": "uuid",
    "name": "Df vs N Study",
    "status": "running",
    "progress": {
        "total": 45,
        "completed": 30,
        "failed": 0,
        "running": 15
    },
    "results": [
        {
            "simulation_id": "uuid-sim-1",
            "status": "completed",
            "parameters": {"n_particles": 500, "target_df": 1.8},
            "seed": 12345,
            "fractal_dimension": 1.82,
            "radius_of_gyration": 12.5,
            "box_counting": {
                "dimension": 1.85,
                "r_squared": 0.998
            }
        },
        ...
    ]
}
```

### Export CSV

```
GET /api/v1/projects/{project_id}/studies/{id}/export/

Response 200:
Content-Type: text/csv
Content-Disposition: attachment; filename="uuid_results.csv"
```

### Run Box-Counting Post-Hoc

```
POST /api/v1/projects/{project_id}/studies/{id}/run-box-counting/

Request Body:
{
    "points_per_sphere": 100,
    "precision": 18
}

Response 200:
{
    "status": "completed",
    "message": "Box-counting completed: 40 processed, 5 skipped, 0 failed",
    "results": {
        "total": 45,
        "processed": 40,
        "skipped": 5,
        "failed": 0,
        "errors": []
    }
}
```

---

## 8.8 Frontend Integration

### Study Progress Component

The frontend polls study results to show real-time progress:

```
COMPONENT StudyProgress
STATE:
    study: ParametricStudy
    polling: bool = true

ON_MOUNT:
    # Poll every 2 seconds while running
    useQuery(['study-results', studyId], {
        refetchInterval: (data) => {
            if (data.status === "completed") return false
            return 2000
        }
    })

RENDER:
    <ProgressBar
        completed={study.progress.completed}
        total={study.progress.total}
        failed={study.progress.failed}
    />
    <StatusBadge status={study.status} />

    IF study.status === "completed":
        <ResultsTable results={study.results} />
        <ExportButton studyId={study.id} />
```

### Results Visualization

```
COMPONENT StudyResultsViewer

VISUALIZATIONS:
    1. Parameter Heatmap
       - X axis: first grid parameter
       - Y axis: second grid parameter
       - Color: metric value (Df, Rg, etc.)

    2. Box Plot by Parameter
       - Group by parameter value
       - Show distribution across seeds

    3. Df Comparison Chart
       - Rg-based Df vs Box-counting Df
       - 1:1 correlation line

    4. Error Distribution
       - Histogram of Df std errors
       - Confidence interval coverage
```

---

## 8.9 Implementation Checklist

### Backend Implementation

- [ ] ParametricStudy model with all fields
- [ ] ParametricStudySerializer with validation
- [ ] ParametricStudyViewSet with all actions
- [ ] Grid generation in perform_create()
- [ ] Limiting cases generation
- [ ] Sintering configuration application
- [ ] Box-counting integration in task
- [ ] Results aggregation endpoint
- [ ] CSV export endpoint
- [ ] Post-hoc box-counting endpoint

### Task System

- [ ] Celery task queuing for all simulations
- [ ] Task cancellation support
- [ ] Box-counting hook after simulation
- [ ] Error handling and logging
- [ ] Progress tracking

### Frontend Implementation

- [ ] Create Study form with grid builder
- [ ] Study progress polling
- [ ] Results table component
- [ ] CSV download button
- [ ] Parameter visualization charts

### Testing

- [ ] Model tests for ParametricStudy
- [ ] Serializer validation tests
- [ ] API endpoint tests
- [ ] Grid generation unit tests
- [ ] Limiting cases generation tests
- [ ] Box-counting integration tests

---

## 8.10 Performance Considerations

### Large Studies

For studies with many combinations:

| Combinations | Seeds | Total Sims | Estimated Time (4 workers) |
|--------------|-------|------------|---------------------------|
| 9 (3x3) | 3 | 27 | ~5 minutes |
| 25 (5x5) | 3 | 75 | ~15 minutes |
| 100 (10x10) | 5 | 500 | ~2 hours |

### Optimization Strategies

1. **Worker Scaling**: Add more Celery workers for parallel execution
2. **Redis Queuing**: Ensure Redis can handle queue depth
3. **Database Indexing**: Index on `(project_id, status)` for progress queries
4. **Lazy Loading**: Don't load geometry in results endpoint
5. **Caching**: Cache completed study results

### Memory Management

```
MEMORY CONSIDERATIONS

Per Simulation:
├── Geometry: ~40 bytes/particle (N x 4 float64)
│   └── 1000 particles ≈ 40 KB
├── Metrics JSON: ~2 KB
└── Box-counting data: ~5 KB (with log arrays)

Study with 100 simulations, 1000 particles each:
├── Geometry storage: 100 x 40 KB = 4 MB
├── Metrics storage: 100 x 7 KB = 700 KB
└── Database overhead: ~200 KB

Total: ~5 MB per study (acceptable)
```

For very large studies (1000+ simulations), consider:
- Streaming CSV export
- Paginated results endpoint
- Background cleanup of old studies
