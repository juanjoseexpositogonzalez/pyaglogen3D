# Chapter 1: System Architecture

## 1.1 High-Level Architecture

PyAglogen3D follows a three-tier architecture with clear separation between presentation, business logic, and data layers. The system is designed for horizontal scalability of compute-intensive simulation tasks.

### Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              PRESENTATION LAYER                              │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        Next.js Frontend                              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐               │   │
│  │  │   Pages      │  │  Components  │  │    Stores    │               │   │
│  │  │  (App Router)│  │  (UI + 3D)   │  │  (Zustand)   │               │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘               │   │
│  │           │                │                │                        │   │
│  │           └────────────────┼────────────────┘                        │   │
│  │                            ▼                                         │   │
│  │                    ┌──────────────┐                                  │   │
│  │                    │ React Query  │ ◄─── Caching + Polling          │   │
│  │                    └──────────────┘                                  │   │
│  │                            │                                         │   │
│  │                            ▼                                         │   │
│  │                    ┌──────────────┐                                  │   │
│  │                    │  API Client  │ ◄─── HTTP/JSON                   │   │
│  │                    └──────────────┘                                  │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ REST API (CORS)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                             BUSINESS LOGIC LAYER                             │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                      Django REST Framework                           │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐               │   │
│  │  │   ViewSets   │  │ Serializers  │  │   Services   │               │   │
│  │  │ (API Logic)  │  │ (Validation) │  │ (Business)   │               │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘               │   │
│  │           │                                  │                       │   │
│  │           ▼                                  ▼                       │   │
│  │  ┌──────────────┐                   ┌──────────────┐                │   │
│  │  │    Models    │                   │ Celery Tasks │                │   │
│  │  │   (Django)   │                   │  (Async)     │                │   │
│  │  └──────────────┘                   └──────────────┘                │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘
          │                                          │
          │ ORM                                      │ Task Dispatch
          ▼                                          ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                               DATA LAYER                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────────┐    ┌──────────────────┐    ┌──────────────────┐      │
│  │   PostgreSQL     │    │      Redis       │    │  Celery Workers  │      │
│  │   ─────────────  │    │   ───────────    │    │  ──────────────  │      │
│  │   • Projects     │    │   • Task Queue   │    │  • aglogen_core  │      │
│  │   • Simulations  │    │   • Results      │    │  • NumPy/SciPy   │      │
│  │   • Analyses     │    │   • Locks        │    │  • PIL/Matplotlib│      │
│  │   • Geometry     │    │                  │    │                  │      │
│  └──────────────────┘    └──────────────────┘    └──────────────────┘      │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 1.2 Component Responsibilities

### Frontend (Next.js)

| Component | Responsibility |
|-----------|----------------|
| **App Router** | Page routing, layouts, server components |
| **React Components** | UI rendering, form handling, 3D visualization |
| **Zustand Stores** | Client-side state (viewer settings, export) |
| **React Query** | Server state, caching, polling for status updates |
| **API Client** | HTTP requests, error handling, response parsing |

### Backend (Django)

| Component | Responsibility |
|-----------|----------------|
| **ViewSets** | HTTP request handling, permissions, pagination |
| **Serializers** | Request validation, response formatting |
| **Models** | Data structure, relationships, constraints |
| **Tasks** | Asynchronous simulation execution |
| **Services** | Business logic (projections, exports) |
| **Utils** | Shared helpers (name generation, limiting cases) |

### Simulation Engine (Rust)

| Component | Responsibility |
|-----------|----------------|
| **Simulation Modules** | Algorithm implementations (DLA, CCA, etc.) |
| **Fractal Modules** | Box-counting, FRAKTAL analysis |
| **Common** | Geometry primitives, spatial hash, RNG |
| **PyO3 Bindings** | Python interface for all Rust functions |

## 1.3 Data Flow Patterns

### Simulation Creation Flow

```
┌──────────┐    POST /simulations/     ┌──────────┐
│ Frontend │ ─────────────────────────►│ ViewSet  │
└──────────┘                           └──────────┘
                                             │
                                             ▼
                                       ┌──────────┐
                                       │Serializer│ Validate parameters
                                       └──────────┘
                                             │
                                             ▼
                                       ┌──────────┐
                                       │  Model   │ Create QUEUED simulation
                                       └──────────┘
                                             │
                                             ▼
                                       ┌──────────┐
                                       │  Celery  │ Dispatch task
                                       └──────────┘
                                             │
                                             ▼
┌──────────┐    JSON Response          ┌──────────┐
│ Frontend │ ◄─────────────────────────│ ViewSet  │ Return simulation metadata
└──────────┘                           └──────────┘
```

### Simulation Execution Flow

```
┌──────────────────────────────────────────────────────────────────┐
│                        Celery Worker                              │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│   1. Load Simulation from DB                                     │
│      │                                                           │
│      ▼                                                           │
│   2. Update status → RUNNING                                     │
│      │                                                           │
│      ▼                                                           │
│   3. Execute Algorithm (aglogen_core)                            │
│      │                                                           │
│      ├─► DLA/CCA/Ballistic/Tunable                              │
│      │                                                           │
│      ▼                                                           │
│   4. Compute Metrics                                             │
│      │                                                           │
│      ├─► Df, kf, Rg, porosity, coordination                     │
│      ├─► Inertia tensor (anisotropy, asphericity)               │
│      │                                                           │
│      ▼                                                           │
│   5. Save Results                                                │
│      │                                                           │
│      ├─► Geometry (BinaryField as NumPy)                        │
│      ├─► Metrics (JSONField)                                    │
│      │                                                           │
│      ▼                                                           │
│   6. Update status → COMPLETED                                   │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
```

### Frontend Polling Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                     React Query Polling                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│   useSimulation(projectId, simId)                               │
│      │                                                          │
│      ▼                                                          │
│   ┌──────────────────────────────────────────────────────┐     │
│   │ refetchInterval: status in [QUEUED, RUNNING]         │     │
│   │                  ? 2000ms : false                    │     │
│   └──────────────────────────────────────────────────────┘     │
│      │                                                          │
│      │                      ┌──────────────┐                    │
│      └─────────────────────►│ GET /sim/{id}│                    │
│                             └──────────────┘                    │
│                                    │                            │
│                                    ▼                            │
│   ┌──────────────────────────────────────────────────────┐     │
│   │ if status === 'completed':                           │     │
│   │   - Stop polling                                     │     │
│   │   - Fetch geometry (useSimulationGeometry)           │     │
│   │   - Render 3D viewer                                 │     │
│   └──────────────────────────────────────────────────────┘     │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘
```

## 1.4 Directory Structure

### Backend Structure

```
backend/
├── apps/
│   ├── core/
│   │   └── urls.py                    # Root URL routing
│   ├── projects/
│   │   ├── models.py                  # Project model
│   │   ├── views.py                   # ProjectViewSet
│   │   ├── serializers.py             # Project serialization
│   │   └── urls.py                    # Project routes
│   ├── simulations/
│   │   ├── models.py                  # Simulation, ParametricStudy
│   │   ├── views.py                   # SimulationViewSet, StudyViewSet
│   │   ├── serializers.py             # Parameter validation
│   │   ├── tasks.py                   # Celery tasks + algorithms
│   │   ├── utils.py                   # Helpers, limiting cases
│   │   └── services/
│   │       └── projection.py          # 2D rendering service
│   └── fractal_analysis/
│       ├── models.py                  # ImageAnalysis, FraktalAnalysis
│       ├── views.py                   # Analysis ViewSets
│       ├── serializers.py             # Analysis validation
│       └── tasks.py                   # Fractal analysis tasks
├── config/
│   ├── settings/
│   │   ├── base.py                    # Common settings
│   │   ├── development.py             # Dev overrides
│   │   ├── production.py              # Prod security
│   │   └── test.py                    # Test configuration
│   ├── celery.py                      # Celery app config
│   ├── urls.py                        # Root URL config
│   └── wsgi.py                        # WSGI application
├── tests/                             # Test suite
├── pyproject.toml                     # Dependencies
└── manage.py                          # Django CLI
```

### Frontend Structure

```
frontend/
├── src/
│   ├── app/                           # Next.js App Router
│   │   ├── page.tsx                   # Landing page
│   │   ├── layout.tsx                 # Root layout
│   │   ├── providers.tsx              # React Query provider
│   │   ├── dashboard/page.tsx         # Dashboard
│   │   └── projects/
│   │       ├── page.tsx               # Projects list
│   │       ├── new/page.tsx           # Create project
│   │       └── [id]/
│   │           ├── page.tsx           # Project detail
│   │           ├── simulations/
│   │           │   ├── new/page.tsx   # Create simulation
│   │           │   └── [simId]/page.tsx  # Simulation viewer
│   │           ├── batch/page.tsx     # Parametric studies
│   │           └── fraktal/
│   │               ├── new/page.tsx   # Create analysis
│   │               └── [analysisId]/page.tsx
│   ├── components/
│   │   ├── ui/                        # Shadcn primitives
│   │   ├── viewer3d/                  # 3D visualization
│   │   ├── forms/                     # Form components
│   │   ├── batch/                     # Batch simulation UI
│   │   ├── fraktal/                   # FRAKTAL analysis UI
│   │   ├── charts/                    # Plotly charts
│   │   ├── projection/                # 2D projection viewer
│   │   ├── topology/                  # Network graph
│   │   ├── analysis/                  # Analysis components
│   │   └── common/                    # Shared components
│   ├── hooks/                         # React Query hooks
│   ├── stores/                        # Zustand stores
│   └── lib/
│       ├── types.ts                   # TypeScript types
│       ├── api.ts                     # API client
│       └── utils.ts                   # Utilities
├── public/                            # Static assets
├── package.json                       # Dependencies
└── tailwind.config.ts                 # Tailwind config
```

### Rust Engine Structure

```
aglogen_core/
├── src/
│   ├── lib.rs                         # PyO3 module entry
│   ├── common/
│   │   ├── mod.rs
│   │   ├── geometry.rs                # Vector3, Sphere, AABB
│   │   ├── spatial.rs                 # Spatial hash grid
│   │   └── rng.rs                     # Deterministic RNG
│   ├── simulation/
│   │   ├── mod.rs
│   │   ├── dla.rs                     # DLA algorithm
│   │   ├── cca.rs                     # CCA algorithm
│   │   ├── ballistic.rs               # Ballistic PC
│   │   ├── ballistic_cc.rs            # Ballistic CC
│   │   ├── tunable.rs                 # Tunable PC
│   │   ├── tunable_cc.rs              # Tunable CC
│   │   ├── sintering.rs               # Sintering model
│   │   ├── metrics.rs                 # Rg, Df, coordination
│   │   └── result.rs                  # PySimulationResult
│   ├── fractal/
│   │   ├── mod.rs
│   │   ├── box_counting.rs            # 2D box-counting
│   │   ├── box_counting_3d.rs         # 3D Morton-code based
│   │   ├── result.rs                  # PyFractalResult
│   │   └── fraktal/
│   │       ├── mod.rs
│   │       ├── params.rs              # Analysis parameters
│   │       ├── result.rs              # FraktalResult
│   │       ├── granulated_2012.rs     # 2012 particle model
│   │       ├── voxel_2018.rs          # 2018 voxel model
│   │       ├── image_processing.rs    # Segmentation
│   │       └── bisection.rs           # Root finder
│   └── projection/
│       └── mod.rs                     # 2D projection
├── Cargo.toml                         # Rust dependencies
└── pyproject.toml                     # Maturin config
```

## 1.5 Communication Protocols

### REST API Conventions

| Method | Purpose | Example |
|--------|---------|---------|
| GET | Retrieve resources | `GET /projects/` |
| POST | Create resources | `POST /simulations/` |
| PATCH | Partial update | `PATCH /projects/{id}/` |
| DELETE | Remove resources | `DELETE /simulations/{id}/` |

### URL Patterns

```
/api/v1/
├── projects/
│   ├── GET                            # List projects
│   ├── POST                           # Create project
│   └── {id}/
│       ├── GET                        # Get project
│       ├── PATCH                      # Update project
│       ├── DELETE                     # Delete project
│       ├── simulations/
│       │   ├── GET/POST               # List/create simulations
│       │   └── {simId}/
│       │       ├── GET/DELETE         # Get/delete simulation
│       │       ├── projection/        # 2D projection
│       │       ├── geometry/          # Download geometry
│       │       ├── export/            # CSV export
│       │       ├── neighbor-graph/    # Adjacency data
│       │       ├── box-counting/      # 3D fractal analysis
│       │       └── cancel/            # Cancel running sim
│       ├── studies/                   # Parametric studies
│       ├── fraktal/                   # FRAKTAL analyses
│       └── comparisons/               # Comparison sets
```

### JSON Response Format

```json
{
  "id": "uuid-string",
  "name": "Simulation Name",
  "status": "completed",
  "algorithm": "tunable",
  "parameters": { ... },
  "metrics": {
    "fractal_dimension": 2.1,
    "prefactor": 1.3,
    "radius_of_gyration": 15.2,
    ...
  },
  "created_at": "2024-02-20T10:30:00Z",
  "completed_at": "2024-02-20T10:30:15Z"
}
```

## 1.6 Deployment Topology

### Development Environment

```
┌──────────────────────────────────────────────────────────────┐
│                     Developer Machine                         │
├──────────────────────────────────────────────────────────────┤
│                                                               │
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│   │  Frontend   │    │   Backend   │    │   Worker    │     │
│   │  npm run dev│    │ ./manage.py │    │ celery -A.. │     │
│   │  :3000      │    │ :8000       │    │             │     │
│   └─────────────┘    └─────────────┘    └─────────────┘     │
│         │                  │                  │              │
│         │                  │                  │              │
│         │            ┌─────┴─────┐      ┌─────┴─────┐       │
│         │            │ PostgreSQL│      │   Redis   │       │
│         │            │  :5432    │      │   :6379   │       │
│         │            │  (Docker) │      │  (Docker) │       │
│         │            └───────────┘      └───────────┘       │
│         │                                                    │
└─────────┼────────────────────────────────────────────────────┘
          │
          ▼
    http://localhost:3000
```

### Production Environment (Heroku + Fly.io)

```
┌───────────────────────────────────────────────────────────────────────┐
│                              Internet                                  │
└───────────────────────────────────────────────────────────────────────┘
                     │                           │
                     ▼                           ▼
         ┌───────────────────┐       ┌───────────────────┐
         │     Heroku        │       │      Fly.io       │
         │   (Frontend)      │       │    (Backend)      │
         ├───────────────────┤       ├───────────────────┤
         │                   │       │                   │
         │  ┌─────────────┐  │       │  ┌─────────────┐  │
         │  │   Next.js   │  │       │  │   Gunicorn  │  │
         │  │  (Node.js)  │  │ ─────►│  │  (Django)   │  │
         │  │  Standalone │  │  API  │  └─────────────┘  │
         │  └─────────────┘  │       │         │         │
         │                   │       │         │         │
         └───────────────────┘       │  ┌──────┴──────┐  │
                                     │  │   Celery    │  │
                                     │  │   Worker    │  │
                                     │  └─────────────┘  │
                                     │         │         │
                                     └─────────┼─────────┘
                                               │
                    ┌──────────────────────────┼──────────────────────────┐
                    │                          │                          │
                    ▼                          ▼                          ▼
          ┌─────────────────┐       ┌─────────────────┐       ┌─────────────────┐
          │  Fly Postgres   │       │  Upstash Redis  │       │   Object Store  │
          │   (Managed)     │       │   (Managed)     │       │   (Optional)    │
          └─────────────────┘       └─────────────────┘       └─────────────────┘
```

## 1.7 Scalability Considerations

### Horizontal Scaling Points

1. **Celery Workers**: Add more workers for parallel simulation execution
2. **Database Read Replicas**: For heavy read workloads
3. **Redis Cluster**: For high task queue throughput
4. **CDN**: For static frontend assets

### Vertical Scaling Considerations

1. **Worker Memory**: Large agglomerates (10k+ particles) need more RAM
2. **Worker CPU**: Tunable algorithm is CPU-intensive
3. **Database Storage**: Geometry binary fields grow with particle count

### Performance Bottlenecks

| Component | Bottleneck | Mitigation |
|-----------|------------|------------|
| Simulation | CPU-bound Rust code | More workers, larger instances |
| Geometry Storage | Large binary fields | Object storage for >100k particles |
| 3D Rendering | WebGL particle count | LOD, instanced mesh |
| Database | Connection limits | Connection pooling |
