# Chapter 7: Deployment

This chapter covers environment setup, containerization, and cloud deployment for PyAglogen3D.

## 7.1 Development Environment Setup

### Prerequisites

```
Required Software:
├── Python 3.11+
├── Node.js 18+
├── Rust 1.75+ (with cargo)
├── PostgreSQL 15+
├── Redis 7+
├── Git
└── Docker (optional, for services)
```

### Step-by-Step Setup

#### 1. Clone Repository

```bash
git clone https://github.com/your-org/pyaglogen3d.git
cd pyaglogen3d
```

#### 2. Environment Variables

```bash
# Copy example environment file
cp .env.example .env

# Edit with your values
# Required variables:
DATABASE_URL=postgres://user:password@localhost:5432/pyaglogen3d
REDIS_URL=redis://localhost:6379/0
SECRET_KEY=your-secret-key-here
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1
CORS_ALLOWED_ORIGINS=http://localhost:3000
```

#### 3. Build Rust Engine

```bash
cd aglogen_core

# Install maturin
pip install maturin

# Build and install wheel
maturin build --release
pip install target/wheels/*.whl

# Verify installation
python -c "import aglogen_core; print('OK')"
```

#### 4. Backend Setup

```bash
cd backend

# Create virtual environment
python -m venv ../.venv
source ../.venv/bin/activate  # Linux/Mac
# or: ..\.venv\Scripts\activate  # Windows

# Install dependencies
pip install -e ".[dev]"

# Run migrations
python manage.py migrate

# Create superuser (optional)
python manage.py createsuperuser
```

#### 5. Start Services (Docker)

```bash
# Start PostgreSQL and Redis
docker compose up -d postgres redis

# Or use docker-compose.yml:
version: '3.8'
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_USER: pyaglogen
      POSTGRES_PASSWORD: pyaglogen
      POSTGRES_DB: pyaglogen3d
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  postgres_data:
```

#### 6. Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Verify API URL in .env.local
echo "NEXT_PUBLIC_API_URL=http://localhost:8000/api/v1" > .env.local
```

#### 7. Start Development Servers

```bash
# Terminal 1: Django
cd backend
python manage.py runserver

# Terminal 2: Celery Worker
cd backend
celery -A config worker -l info

# Terminal 3: Frontend
cd frontend
npm run dev
```

#### 8. Verify Installation

```
Backend: http://localhost:8000/api/v1/
Frontend: http://localhost:3000
Admin: http://localhost:8000/admin/
```

---

## 7.2 Docker Configuration

### Backend Dockerfile

```dockerfile
# backend/Dockerfile

# Stage 1: Build Rust engine
FROM rust:1.75-slim-bookworm AS rust-builder

RUN apt-get update && apt-get install -y \
    python3 \
    python3-pip \
    python3-dev \
    && rm -rf /var/lib/apt/lists/*

RUN pip3 install --break-system-packages maturin==1.4.0

WORKDIR /build/aglogen_core
COPY aglogen_core/ .

RUN maturin build --release --strip

# Stage 2: Python application
FROM python:3.11-slim-bookworm AS production

# Install system dependencies
RUN apt-get update && apt-get install -y \
    libpq5 \
    && rm -rf /var/lib/apt/lists/*

# Create non-root user
RUN useradd --create-home --shell /bin/bash appuser

WORKDIR /app

# Install Rust wheel from builder
COPY --from=rust-builder /build/aglogen_core/target/wheels/*.whl /tmp/
RUN pip install /tmp/*.whl && rm -rf /tmp/*.whl

# Install Python dependencies
COPY backend/pyproject.toml backend/README.md ./
RUN pip install --no-cache-dir -e .

# Copy application code
COPY backend/ .

# Collect static files
RUN python manage.py collectstatic --noinput

# Switch to non-root user
USER appuser

# Expose port
EXPOSE 8080

# Default command
CMD ["gunicorn", "--bind", "0.0.0.0:8080", "--workers", "2", \
     "--threads", "4", "--worker-class", "gthread", \
     "config.wsgi:application"]
```

### Frontend Dockerfile

```dockerfile
# frontend/Dockerfile

FROM node:18-alpine AS builder

WORKDIR /app

# Install dependencies
COPY package.json package-lock.json ./
RUN npm ci

# Build application
COPY . .
ARG NEXT_PUBLIC_API_URL
ENV NEXT_PUBLIC_API_URL=$NEXT_PUBLIC_API_URL
RUN npm run build

# Production image
FROM node:18-alpine AS runner

WORKDIR /app

ENV NODE_ENV=production

# Copy built application
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
COPY --from=builder /app/public ./public

EXPOSE 3000

CMD ["node", "server.js"]
```

### Docker Compose (Full Stack)

```yaml
# docker-compose.yml

version: '3.8'

services:
  frontend:
    build:
      context: .
      dockerfile: frontend/Dockerfile
      args:
        NEXT_PUBLIC_API_URL: http://localhost:8000/api/v1
    ports:
      - "3000:3000"
    depends_on:
      - backend
    environment:
      - NODE_ENV=production

  backend:
    build:
      context: .
      dockerfile: backend/Dockerfile
    ports:
      - "8000:8080"
    depends_on:
      - postgres
      - redis
    environment:
      - DATABASE_URL=postgres://pyaglogen:pyaglogen@postgres:5432/pyaglogen3d
      - REDIS_URL=redis://redis:6379/0
      - SECRET_KEY=${SECRET_KEY}
      - DEBUG=False
      - ALLOWED_HOSTS=localhost,backend

  worker:
    build:
      context: .
      dockerfile: backend/Dockerfile
    command: celery -A config worker -l info --concurrency=2
    depends_on:
      - postgres
      - redis
    environment:
      - DATABASE_URL=postgres://pyaglogen:pyaglogen@postgres:5432/pyaglogen3d
      - REDIS_URL=redis://redis:6379/0
      - SECRET_KEY=${SECRET_KEY}

  postgres:
    image: postgres:15
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_USER=pyaglogen
      - POSTGRES_PASSWORD=pyaglogen
      - POSTGRES_DB=pyaglogen3d

  redis:
    image: redis:7-alpine

volumes:
  postgres_data:
```

---

## 7.3 Fly.io Deployment (Backend)

### Fly.io Configuration

```toml
# fly.toml

app = "pyaglogen3d-api"
primary_region = "mad"  # Madrid

[build]
  dockerfile = "backend/Dockerfile"

[env]
  PORT = "8080"
  DJANGO_SETTINGS_MODULE = "config.settings.production"
  ALLOWED_HOSTS = ".fly.dev,pyaglogen3d-api.fly.dev"

[http_service]
  internal_port = 8080
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 0

  [http_service.concurrency]
    type = "connections"
    hard_limit = 100
    soft_limit = 80

[[vm]]
  cpu_kind = "shared"
  cpus = 1
  memory_mb = 512

[processes]
  web = "gunicorn --bind 0.0.0.0:8080 --workers 2 --threads 4 config.wsgi:application"
  worker = "celery -A config worker -l info --concurrency=2"
```

### Deployment Steps

```bash
# 1. Install Fly CLI
curl -L https://fly.io/install.sh | sh

# 2. Login
fly auth login

# 3. Create app
fly apps create pyaglogen3d-api

# 4. Create Postgres database
fly postgres create --name pyaglogen3d-db
fly postgres attach pyaglogen3d-db --app pyaglogen3d-api

# 5. Set secrets
fly secrets set SECRET_KEY="your-production-secret-key"
fly secrets set REDIS_URL="rediss://user:pass@host.upstash.io:6379"

# 6. Deploy
fly deploy

# 7. Run migrations
fly ssh console -C "python manage.py migrate"

# 8. Scale worker
fly scale count worker=1
```

### Upstash Redis Setup

```bash
# 1. Create Upstash account at upstash.com

# 2. Create Redis database
#    - Select region close to Fly.io region
#    - Enable TLS

# 3. Get connection string
#    Format: rediss://default:password@host.upstash.io:6379

# 4. Set as Fly secret
fly secrets set REDIS_URL="rediss://default:xxx@xxx.upstash.io:6379"
```

---

## 7.4 Heroku Deployment (Frontend)

### Heroku Configuration

```json
// frontend/package.json additions

{
  "scripts": {
    "heroku-postbuild": "npm run build"
  },
  "engines": {
    "node": "18.x"
  }
}
```

### Procfile

```
# frontend/Procfile

web: npm start
```

### Deployment Steps

```bash
# 1. Install Heroku CLI
# See: https://devcenter.heroku.com/articles/heroku-cli

# 2. Login
heroku login

# 3. Create app
heroku create pyaglogen3d-frontend

# 4. Set buildpack
heroku buildpacks:set heroku/nodejs

# 5. Set environment variables
heroku config:set NEXT_PUBLIC_API_URL=https://pyaglogen3d-api.fly.dev/api/v1

# 6. Deploy
cd frontend
git subtree push --prefix frontend heroku main
# Or use Git subtree from root

# Alternative: Deploy from root with multi-buildpack
```

### Alternative: Heroku with Monorepo

```bash
# Use heroku-buildpack-monorepo

heroku buildpacks:add -i 1 https://github.com/lstoll/heroku-buildpack-monorepo
heroku buildpacks:add heroku/nodejs
heroku config:set APP_BASE=frontend
```

---

## 7.5 Environment Variables Reference

### Backend Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection | `postgres://user:pass@host:5432/db` |
| `REDIS_URL` | Redis connection | `redis://localhost:6379/0` |
| `SECRET_KEY` | Django secret key | Random 50+ char string |
| `DEBUG` | Debug mode | `False` (production) |
| `ALLOWED_HOSTS` | Allowed hostnames | `example.com,.fly.dev` |
| `CORS_ALLOWED_ORIGINS` | CORS origins | `https://frontend.com` |
| `CELERY_BROKER_URL` | Celery broker (override) | Same as REDIS_URL |
| `CELERY_RESULT_BACKEND` | Celery results (override) | Same as REDIS_URL |

### Frontend Variables

| Variable | Description | Example |
|----------|-------------|---------|
| `NEXT_PUBLIC_API_URL` | Backend API URL | `https://api.example.com/api/v1` |
| `NODE_ENV` | Environment | `production` |

---

## 7.6 Database Migrations

### Migration Commands

```bash
# Create new migration
python manage.py makemigrations

# Apply migrations
python manage.py migrate

# Show migration status
python manage.py showmigrations

# Rollback migration
python manage.py migrate app_name 0001_previous

# Generate SQL for migration
python manage.py sqlmigrate app_name 0002_new_field
```

### Production Migration Strategy

```bash
# 1. Run migrations before deploying new code
fly ssh console -C "python manage.py migrate"

# 2. Deploy new code
fly deploy

# Or use release command in fly.toml:
[deploy]
  release_command = "python manage.py migrate"
```

### Backup Before Migration

```bash
# Fly.io Postgres backup
fly postgres backup create -a pyaglogen3d-db

# Manual backup
fly postgres connect -a pyaglogen3d-db
> \copy simulations_simulation TO '/tmp/backup.csv' CSV HEADER;
```

---

## 7.7 Monitoring and Logging

### Fly.io Logs

```bash
# View real-time logs
fly logs

# View specific process logs
fly logs --region mad

# View past logs
fly logs --since 1h
```

### Heroku Logs

```bash
# View real-time logs
heroku logs --tail

# Filter by dyno
heroku logs --dyno web
```

### Application Logging

```python
# Django logging configuration

LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'verbose',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
    'loggers': {
        'apps': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
}
```

### Health Checks

```python
# Add health check endpoint

# urls.py
path('health/', health_check, name='health_check'),

# views.py
def health_check(request):
    """Health check endpoint for load balancers."""
    checks = {
        'database': check_database(),
        'redis': check_redis(),
    }

    healthy = all(checks.values())
    status = 200 if healthy else 503

    return JsonResponse(checks, status=status)
```

---

## 7.8 Scaling

### Fly.io Scaling

```bash
# Scale web process
fly scale count web=2

# Scale worker process
fly scale count worker=3

# Scale VM size
fly scale vm shared-cpu-2x

# Auto-scaling (via fly.toml)
[http_service]
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 1
```

### Heroku Scaling

```bash
# Scale dynos
heroku ps:scale web=2

# Scale dyno type
heroku ps:type web=standard-1x
```

### Celery Worker Scaling

```bash
# Increase concurrency
celery -A config worker -l info --concurrency=4

# Multiple worker processes
fly scale count worker=2

# Each with:
[processes]
  worker = "celery -A config worker -l info --concurrency=2"
```

---

## 7.9 Troubleshooting

### Common Issues

#### Database Connection Failed

```
Error: could not connect to server

Solutions:
1. Check DATABASE_URL is correct
2. Verify database is running
3. Check firewall/security groups
4. For Fly.io, ensure postgres is attached
```

#### Redis Connection Failed

```
Error: Error connecting to Redis

Solutions:
1. Check REDIS_URL format (redis:// vs rediss://)
2. Verify Redis is running
3. For Upstash, ensure TLS is used (rediss://)
```

#### Celery Tasks Not Running

```
Symptoms: Simulations stuck in 'queued'

Solutions:
1. Check worker is running: fly ssh console -C "ps aux"
2. Check Redis connectivity
3. Verify CELERY_BROKER_URL
4. Check worker logs: fly logs -a app-name --process worker
```

#### CORS Errors

```
Error: CORS policy blocked

Solutions:
1. Check CORS_ALLOWED_ORIGINS includes frontend URL
2. Ensure protocol matches (https vs http)
3. Check for trailing slashes in URLs
```

#### Static Files Not Loading (Production)

```
Error: 404 on static files

Solutions:
1. Run collectstatic: python manage.py collectstatic
2. Check whitenoise is configured
3. Verify STATIC_ROOT setting
```

### Debug Commands

```bash
# Fly.io SSH console
fly ssh console

# Check environment
fly ssh console -C "env | grep DATABASE"

# Django shell
fly ssh console -C "python manage.py shell"

# Check migrations
fly ssh console -C "python manage.py showmigrations"

# Celery inspect
fly ssh console -C "celery -A config inspect active"
```

---

## 7.10 Security Checklist

### Production Security

```
Pre-deployment checklist:

[ ] DEBUG = False
[ ] SECRET_KEY is random and not in version control
[ ] ALLOWED_HOSTS is restrictive
[ ] CORS_ALLOWED_ORIGINS is specific (not *)
[ ] Database has strong password
[ ] HTTPS enforced (force_https in fly.toml)
[ ] Secure cookies enabled
[ ] CSRF protection enabled
[ ] No sensitive data in logs
[ ] Environment variables for all secrets
```

### Security Settings

```python
# config/settings/production.py

DEBUG = False
SECRET_KEY = config('SECRET_KEY')

# Security headers
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'

# HTTPS
SECURE_SSL_REDIRECT = True
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

# Cookies
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True

# HSTS (after testing)
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
```
