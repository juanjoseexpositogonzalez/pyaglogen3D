# Chapter 10: Limiting Case Geometries

This chapter documents the limiting case geometry generators that produce reference agglomerates with known fractal dimensions. These deterministic structures serve as validation targets and theoretical benchmarks.

## 10.1 Purpose and Scientific Background

### Why Limiting Cases?

Limiting case geometries are mathematically perfect structures with exactly known fractal dimensions:

| Fractal Dimension | Geometry Type | Physical Analog |
|-------------------|---------------|-----------------|
| Df = 1.0 | Linear structures | Polymer chains, nanofibers |
| Df = 2.0 | Planar structures | Thin films, graphene-like |
| Df = 3.0 | Compact structures | Dense clusters, sintered particles |

These serve multiple purposes:

1. **Algorithm Validation**: Verify that simulation algorithms produce expected Df
2. **Box-Counting Calibration**: Test that analysis methods return correct Df
3. **Theoretical Bounds**: Provide endpoints for parameter sweeps
4. **Visual Reference**: Understand how Df relates to structure appearance

### Geometric Hierarchy

```
LIMITING CASE GEOMETRY HIERARCHY

Df = 1 (Chain-like)
├── lineal: Single straight line of particles
├── cruz2d: 2D cross (+) in xy-plane
├── asterisco: 6-branch asterisk (60deg spacing)
└── cruz3d: 3D cross (6 arms along x, y, z axes)

Df = 2 (Planar)
├── plano: Single hexagonal plane
├── dobleplano: Two perpendicular planes
└── tripleplano: Three planes at 60deg angles

Df = 3 (Compact)
└── cuboctaedro: 3D close-packed structure
    ├── HC: Hexagonal Compact packing
    ├── CS: Cubic Simple packing
    └── CCC: Face-Centered Cubic packing
```

---

## 10.2 Df = 1 Configurations (Chain-Like)

### Linear Chain (lineal)

The simplest case: particles arranged in a straight line along the x-axis.

```
ALGORITHM Generate_Linear_Chain
INPUT:
    n_particles: number of particles
    radius: particle radius (default: 1.0)
    sintering_coeff: contact coefficient (default: 1.0)

OUTPUT:
    coords: Nx3 array of particle coordinates

PROCEDURE:
    IF n_particles <= 0:
        RETURN empty array

    d = sintering_coeff * 2.0 * radius  # Center-to-center distance

    coords = zeros(n_particles, 3)

    # Position particles along x-axis
    FOR i in 0..n_particles:
        coords[i, 0] = d * i  # x position
        coords[i, 1] = 0.0    # y = 0
        coords[i, 2] = 0.0    # z = 0

    # Center at origin
    coords -= coords.mean(axis=0)

    RETURN coords

EXAMPLE:
    N=5, radius=1, sintering=1.0
    Result: [(-4, 0, 0), (-2, 0, 0), (0, 0, 0), (2, 0, 0), (4, 0, 0)]

    •───•───•───•───•
    └─────────────────→ x
```

### 2D Cross (cruz2d)

Four branches extending from a central point in the xy-plane.

```
ALGORITHM Generate_Cruz2D
INPUT:
    n_branches: particles per branch arm
    radius: particle radius
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    d = sintering_coeff * 2.0 * radius

    coords = []

    IF n_branches is ODD:
        # Main horizontal branch (along x)
        FOR i in 0..n_branches:
            coords.append([d * i, 0.0, 0.0])

        # Center x position
        center_x = (n_branches - 1) * d / 2.0

        # Vertical branch (positive y)
        FOR j in 1..(n_branches // 2 + 1):
            coords.append([center_x, d * j, 0.0])

        # Vertical branch (negative y)
        FOR k in 1..(n_branches // 2 + 1):
            coords.append([center_x, -d * k, 0.0])

    ELSE:  # EVEN
        # Use gap at junction for proper alignment
        half = n_branches // 2
        gap = 2 * (sqrt(2) - 1)

        # Left horizontal half
        FOR i in 0..half:
            coords.append([d * i, 0.0, 0.0])

        # Right horizontal half (with gap)
        FOR j in 0..half:
            coords.append([half * d + gap + d * j, 0.0, 0.0])

        # Vertical center
        center_x = half * d + gap / 2.0 - radius

        # Upper and lower vertical branches
        FOR k in 0..half:
            coords.append([center_x, sqrt(2) + d * k, 0.0])
            coords.append([center_x, -sqrt(2) - d * k, 0.0])

    coords = array(coords)
    coords -= coords.mean(axis=0)

    RETURN coords

VISUALIZATION (n_branches=5):
              •
              │
              •
              │
    •───•───•───•───•
              │
              •
              │
              •
```

### Asterisk (asterisco)

Six branches radiating from center at 60-degree intervals.

```
ALGORITHM Generate_Asterisco
INPUT:
    n_branches: particles per branch (forced to odd)
    radius: particle radius
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    # Ensure odd number for proper geometry
    IF n_branches is EVEN:
        n_branches += 1

    d = sintering_coeff * 2.0 * radius
    half = n_branches // 2

    coords = []

    # Branch 1: Vertical (along y)
    FOR i in 0..n_branches:
        x = half * d
        y = half * d - d * i
        coords.append([x, y, 0.0])

    # Branch 2: 60deg positive slope
    FOR j in 0..n_branches:
        x = (half * d + radius - half * sqrt(3)) + j * sqrt(3)
        y = -half * radius + j * radius
        coords.append([x, y, 0.0])

    # Branch 3: 60deg negative slope
    FOR k in 0..n_branches:
        x = (half * d + radius - half * sqrt(3)) + k * sqrt(3)
        y = half * radius - k * radius
        coords.append([x, y, 0.0])

    coords = array(coords)
    coords -= coords.mean(axis=0)
    coords = unique_rows(coords)  # Remove center duplicates

    RETURN coords

VISUALIZATION:
           \      /
            \    /
             \  /
        ──────•──────
             /  \
            /    \
           /      \
```

### 3D Cross (cruz3d)

Three orthogonal branches along x, y, and z axes.

```
ALGORITHM Generate_Cruz3D
INPUT:
    n_branches: particles per branch (forced to odd)
    radius: particle radius
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    IF n_branches is EVEN:
        n_branches += 1

    d = sintering_coeff * 2.0 * radius
    half = n_branches // 2

    coords = []

    center_x = half * d

    # Vertical branch (along z)
    FOR i in 0..n_branches:
        z = radius + half * d - d * i
        coords.append([center_x, 0.0, z])

    # Branch in xy-plane at +60deg
    FOR j in 0..n_branches:
        x = (half * d + radius - half * sqrt(3)) + j * sqrt(3)
        y = -half * radius + j * radius
        coords.append([x, y, 0.0])

    # Branch in xy-plane at -60deg
    FOR k in 0..n_branches:
        x = (half * d + radius - half * sqrt(3)) + k * sqrt(3)
        y = half * radius - k * radius
        coords.append([x, y, 0.0])

    coords = array(coords)
    coords -= coords.mean(axis=0)
    coords = unique_rows(coords)

    RETURN coords
```

---

## 10.3 Df = 2 Configurations (Planar)

### Hexagonal Numbers

Complete hexagonal arrangements follow the formula:

```
N(k) = 1 + 3k(k+1)

where k = number of complete rings around center

k=0: N=1   (center only)
k=1: N=7   (center + 6)
k=2: N=19  (center + 6 + 12)
k=3: N=37  (center + 6 + 12 + 18)
k=4: N=61
k=5: N=91
...
```

### Single Hexagonal Plane (plano)

```
ALGORITHM Generate_Hexagonal_Plane
INPUT:
    n_particles: target count (or None if layers specified)
    layers: number of hexagonal rings (k)
    radius: particle radius
    packing: 'HC' (hexagonal) or 'CS' (cubic simple)
    complete_rings: bool (adjust N to nearest hexagonal number)
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    d = sintering_coeff * 2.0 * radius

    IF packing == 'CS':  # Cubic Simple (square grid)
        IF layers is not None:
            n_side = layers + 1
            n_particles = n_side * n_side
        ELSE IF n_particles is None:
            n_particles = 1

        n_side = ceil(sqrt(n_particles))
        coords = []

        FOR j in 0..n_side:
            FOR i in 0..n_side:
                IF len(coords) >= n_particles:
                    BREAK
                coords.append([d * i, d * j, 0.0])

        coords = array(coords)
        coords -= coords.mean(axis=0)
        RETURN coords

    # Hexagonal Compact (HC) packing
    IF layers is not None:
        n_particles = 1 + 3 * layers * (layers + 1)
    ELSE IF n_particles is None:
        n_particles = 1

    # Adjust to nearest hexagonal number
    IF complete_rings AND n_particles > 6:
        n_particles = nearest_hexagonal_number(n_particles)

    # Generate hexagonal grid positions
    all_positions = []
    max_ring = ceil(sqrt(n_particles)) + 2

    FOR ring in 0..(max_ring + 1):
        IF ring == 0:
            all_positions.append((0.0, 0.0, 0.0))
        ELSE:
            FOR side in 0..6:
                angle = side * PI / 3.0
                next_angle = (side + 1) * PI / 3.0

                corner_x = ring * d * cos(angle)
                corner_y = ring * d * sin(angle)
                next_corner_x = ring * d * cos(next_angle)
                next_corner_y = ring * d * sin(next_angle)

                FOR j in 0..ring:
                    t = j / ring
                    px = corner_x + t * (next_corner_x - corner_x)
                    py = corner_y + t * (next_corner_y - corner_y)
                    all_positions.append((px, py, 0.0))

    # Sort by distance from center and take closest n_particles
    all_positions.sort(key=lambda p: p[0]**2 + p[1]**2)
    coords = array(all_positions[:n_particles])
    coords -= coords.mean(axis=0)

    RETURN coords

VISUALIZATION (k=2, N=19):
           • • •
          • • • •
         • • • • •
          • • • •
           • • •
```

### Double Plane (dobleplano)

Two perpendicular hexagonal planes sharing a common axis.

```
ALGORITHM Generate_Doble_Plano
INPUT:
    layers: number of layers (k value)
    radius: particle radius
    packing: 'HC' or 'CS'
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    d = sintering_coeff * 2.0 * radius
    coords = []

    IF packing == 'HC':
        esferas2 = layers * 2 + 1

        # First plane (xy-plane, z=0)
        FOR i in 1..(esferas2 // 2 + 2):
            FOR j in i..esferas2 + 1:
                xx = d * (j - 1) - (i - 1)
                yy = sqrt(3) * (i - 1)
                coords.append([xx, yy, 0.0])
                IF i > 1:
                    coords.append([xx, -yy, 0.0])

        # Second plane (xz-plane, y=0)
        FOR i in 1..(esferas2 // 2 + 2):
            FOR j in i..esferas2 + 1:
                xx = d * (j - 1) - (i - 1)
                zz = sqrt(3) * (i - 1)
                coords.append([xx, 0.0, zz])
                coords.append([xx, 0.0, -zz])

    ELSE:  # CS packing
        n_side = layers + 1

        # First plane (xy)
        FOR j in 0..n_side:
            FOR i in 0..n_side:
                coords.append([d * i, d * j, 0.0])

        # Second plane (xz), offset to share axis
        center_y = layers * d / 2.0
        FOR j in 0..n_side:
            FOR i in 0..n_side:
                z = (j - layers / 2.0) * d
                IF abs(z) > 0.01:  # Skip overlapping particles
                    coords.append([d * i, center_y, z])

    coords = array(coords)
    coords = unique_rows(round(coords, 10))
    coords -= coords.mean(axis=0)

    RETURN coords

CROSS-SECTION VIEW:
        z │
          │   /
          │  /
          │ /
    ──────•──────→ y
         /│
        / │
       /  │
```

### Triple Plane (tripleplano)

Three hexagonal planes at 60-degree angles, sharing a common axis.

```
ALGORITHM Generate_Triple_Plano
INPUT:
    layers: number of layers
    radius: particle radius
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    d = sintering_coeff * 2.0 * radius
    coords = []
    esferas2 = layers * 2 + 1

    # Plane 1: xy-plane (base)
    FOR i in 1..(esferas2 // 2 + 2):
        FOR j in i..esferas2 + 1:
            xx = d * (j - 1) - (i - 1)
            yy = sqrt(3) * (i - 1)
            coords.append([xx, yy, 0.0])
            coords.append([xx, -yy, 0.0])

    # Plane 2: rotated 60deg around x-axis
    FOR i in 1..(esferas2 // 2 + 2):
        FOR j in i..esferas2 + 1:
            xx = d * (j - 1) - (i - 1)
            yy = sqrt(3) / 2 * (i - 1)
            zz = 1.5 * (i - 1)
            coords.append([xx, yy, zz])
            coords.append([xx, -yy, -zz])

    # Plane 3: rotated -60deg around x-axis
    FOR i in 1..(esferas2 // 2 + 2):
        FOR j in i..esferas2 + 1:
            xx = d * (j - 1) - (i - 1)
            yy = -sqrt(3) / 2 * (i - 1)
            zz = 1.5 * (i - 1)
            coords.append([xx, yy, zz])
            coords.append([xx, -yy, -zz])

    coords = array(coords)
    coords = unique_rows(round(coords, 10))
    coords -= coords.mean(axis=0)

    RETURN coords
```

---

## 10.4 Df = 3 Configurations (Compact)

### Magic Numbers for Close Packing

```
NOTABLE CLOSE-PACKED CLUSTERS

N=1:  Single particle
N=4:  Tetrahedron (4 particles touching)
N=6:  Octahedron (6 particles)
N=13: Icosahedron/Cuboctahedron (first complete shell)
N=55: Second Mackay icosahedron
N=147: Third Mackay icosahedron
```

### Small N Configurations

```
ALGORITHM Generate_HCP_Sphere (Small N)
INPUT:
    n_particles: target count (1-6)
    radius: particle radius
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    d = sintering_coeff * 2.0 * radius

    SWITCH n_particles:
        CASE 1:
            RETURN [[0, 0, 0]]

        CASE 2:
            RETURN [[-radius, 0, 0], [radius, 0, 0]]

        CASE 3:  # Equilateral triangle
            coords = [
                [0, 0, 0],
                [d, 0, 0],
                [d/2, d * sqrt(3)/2, 0]
            ]
            coords -= coords.mean(axis=0)
            RETURN coords

        CASE 4:  # Tetrahedron
            h = d * sqrt(2/3)
            coords = [
                [0, 0, 0],
                [d, 0, 0],
                [d/2, d * sqrt(3)/2, 0],
                [d/2, d * sqrt(3)/6, h]
            ]
            coords -= coords.mean(axis=0)
            RETURN coords

        CASE 5:  # Bipyramid (tetrahedron + mirror)
            h = d * sqrt(2/3)
            coords = [
                [0, 0, 0],
                [d, 0, 0],
                [d/2, d * sqrt(3)/2, 0],
                [d/2, d * sqrt(3)/6, h],
                [d/2, d * sqrt(3)/6, -h]
            ]
            coords -= coords.mean(axis=0)
            RETURN coords

        CASE 6:  # Octahedron
            a = d / sqrt(2)
            RETURN [
                [a, 0, 0], [-a, 0, 0],
                [0, a, 0], [0, -a, 0],
                [0, 0, a], [0, 0, -a]
            ]
```

### Cuboctahedron (Large N)

```
ALGORITHM Generate_Cuboctaedro
INPUT:
    layers: number of layers/shells
    radius: particle radius
    packing: 'HC', 'CS', or 'CCC'
    sintering_coeff: contact coefficient

OUTPUT:
    coords: Nx3 array

PROCEDURE:
    d = sintering_coeff * 2.0 * radius
    coords = []

    IF packing == 'HC':  # Hexagonal Close-Packed
        esferas2 = layers * 2 + 1
        z_spacing = 1.6345  # sqrt(8/3)

        # Base hexagonal layer (z=0)
        FOR i in 1..(esferas2 // 2 + 2):
            FOR j in i..esferas2 + 1:
                xx = d * (j - 1) - (i - 1)
                yy = sqrt(3) * (i - 1)
                coords.append([xx, yy, 0.0])
                coords.append([xx, -yy, 0.0])

        # Upper layers
        FOR j in 1..layers:
            FOR k in 1..(layers - j + 1):
                FOR i in 1..(esferas2 - k - j + 1):
                    xx = d + d * (i - 1) + radius * (j - 1) + radius * (k - 1)
                    yy = sqrt(3) * j + sqrt(3) / 3 * k
                    zz = z_spacing * k
                    coords.append([xx, yy, zz])

        # Side triangular regions
        FOR k in 1..(esferas2 // 2):
            FOR j in 1..(esferas2 // 2 + 1):
                FOR i in 1..(esferas2 - j - (k - 1) + 1):
                    xx = (k - 1) * radius + radius * j + d * (i - 1)
                    yy = sqrt(3) / 3 - sqrt(3) * (j - 1) + (k - 1) * sqrt(3) / 3
                    zz = z_spacing * k
                    coords.append([xx, yy, zz])

        # Lower layers (mirror of upper)
        # ... (symmetric construction)

    ELSE IF packing == 'CS':  # Cubic Simple
        n_side = layers + 1
        FOR j in 0..n_side:
            FOR i in 0..n_side:
                FOR k in 0..n_side:
                    coords.append([d * i, d * j, d * k])

    ELSE IF packing == 'CCC':  # Face-Centered Cubic
        n_side = layers + 1
        spacing = 4 / sqrt(3)

        # Corner positions
        FOR j in 0..n_side:
            FOR i in 0..n_side:
                FOR k in 0..n_side:
                    coords.append([
                        spacing * radius * i,
                        spacing * radius * j,
                        spacing * radius * k
                    ])

        # Face-center positions (offset by half cell)
        offset = 2 / sqrt(3)
        FOR j in 0..layers:
            FOR i in 0..layers:
                FOR k in 0..layers:
                    coords.append([
                        offset + spacing * radius * i,
                        offset + spacing * radius * j,
                        offset + spacing * radius * k
                    ])

    coords = array(coords)
    coords = unique_rows(round(coords, 10))
    coords -= coords.mean(axis=0)

    RETURN coords
```

---

## 10.5 Sintering Coefficient Implementation

### Effect on Geometry

The sintering coefficient controls particle overlap:

```
CONTACT DISTANCE WITH SINTERING

d_contact = sintering_coeff * (r1 + r2)

sintering_coeff = 1.0:  Particles just touch (no overlap)
sintering_coeff = 0.9:  10% overlap (light sintering)
sintering_coeff = 0.5:  50% overlap (heavy sintering)

┌─────────────────────────────────────────────────┐
│  coeff=1.0    coeff=0.9    coeff=0.75   coeff=0.5
│
│    ○ ○         ○○           ○○           ⊕
│  (touching)  (overlap)   (more)       (merged)
└─────────────────────────────────────────────────┘
```

### Application in Geometry Generation

All generators use sintering to compute center-to-center distance:

```
d = sintering_coeff * 2.0 * radius
```

This ensures:
- `sintering_coeff = 1.0`: d = 2r (touching spheres)
- `sintering_coeff = 0.9`: d = 1.8r (10% overlap)
- `sintering_coeff = 0.5`: d = r (50% overlap, sphere centers at radius distance)

---

## 10.6 Theoretical Prefactor (kf) Calculations

### Prefactor Definition

The prefactor kf relates particle count N to normalized radius of gyration:

```
N = kf * (Rg / rp)^Df
```

For limiting cases with known Df, kf can be calculated analytically.

### Chain Prefactor (Df = 1)

```
ALGORITHM Compute_Kf_Chain
INPUT:
    n: number of particles

OUTPUT:
    kf: prefactor

PROCEDURE:
    IF n <= 1:
        RETURN 1.0

    # For linear chain:
    # Rg^2 = (1/N) * sum_{i=1}^{N} (x_i - x_cm)^2
    # With particles at positions -d*(N-1)/2, ..., d*(N-1)/2
    # Rg^2 = (3/5)*rp^2 + (N^2 - 1)*d^2 / (12*N)

    denominator = 3/5 + (n**2 - 1) / 3

    kf = n / sqrt(denominator)

    RETURN kf

ANALYTICAL DERIVATION:
    For chain of N particles with spacing d=2rp:
    Rg^2 = (3/5)*rp^2 + d^2*(N^2-1)/(12N)
    kf = N / (Rg/rp)^1 = N * rp / Rg
```

### Plane Prefactor (Df = 2)

```
ALGORITHM Compute_Kf_Plane
INPUT:
    n: number of particles

OUTPUT:
    kf: prefactor

PROCEDURE:
    IF n <= 1:
        RETURN 1.0

    # For hexagonal plane:
    # Based on discrete sum over hexagonal positions

    denominator = 3/5 + (5*n**2 - 4*n - 1) / (9*n)

    kf = n / denominator

    RETURN kf
```

### Sphere Prefactor (Df = 3)

```
ALGORITHM Compute_Kf_Sphere
INPUT:
    n: number of particles

OUTPUT:
    kf: prefactor (approximately 1.0 for ideal HCP)

PROCEDURE:
    # For ideal close-packed structures, kf ~ 1.0
    RETURN 1.0
```

---

## 10.7 Metrics Computation

### Limiting Case Metrics

Since limiting cases are deterministic, some metrics are computed analytically:

```
ALGORITHM Compute_Limiting_Metrics
INPUT:
    coords: Nx3 particle coordinates
    n_particles: number of particles
    radius: particle radius

OUTPUT:
    metrics: dict

PROCEDURE:
    IF len(coords) == 0:
        RETURN default_empty_metrics()

    # Center of mass
    cdg = coords.mean(axis=0)
    centered = coords - cdg

    # Radius of gyration
    rg = sqrt(sum(centered**2) / n_particles)

    # Porosity
    particle_volume = (4/3) * PI * radius**3
    total_particle_volume = n_particles * particle_volume
    effective_radius = rg + radius
    aggregate_volume = (4/3) * PI * effective_radius**3
    porosity = max(0, 1 - total_particle_volume / aggregate_volume)

    # Coordination numbers
    threshold = 2.1 * radius
    coordinations = []
    FOR i in 0..n_particles:
        count = 0
        FOR j in 0..n_particles:
            IF i != j:
                dist = norm(coords[i] - coords[j])
                IF dist <= threshold:
                    count += 1
        coordinations.append(count)

    coord_mean = mean(coordinations)
    coord_std = std(coordinations)

    # Inertia tensor
    inertia = zeros(3, 3)
    FOR coord in centered:
        r2 = dot(coord, coord)
        inertia += r2 * eye(3) - outer(coord, coord)
    inertia /= n_particles

    # Eigendecomposition
    eigenvalues, eigenvectors = eigh(inertia)
    idx = argsort(eigenvalues)
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:, idx]

    # Shape descriptors
    I1, I2, I3 = eigenvalues
    anisotropy = I3 / I1 if I1 > 1e-10 else 1.0
    asphericity = I3 - 0.5 * (I1 + I2)
    acylindricity = I2 - I1

    # Rg evolution (for plotting)
    rg_evolution = []
    FOR n in range(1, n_particles + 1, max(1, n_particles // 100)):
        subset = centered[:n]
        rg_n = sqrt(sum(subset**2) / n)
        rg_evolution.append(rg_n)

    RETURN {
        "fractal_dimension": 0.0,  # Set by caller based on geometry_type
        "fractal_dimension_std": 0.0,
        "prefactor": 0.0,  # Set by caller
        "radius_of_gyration": rg,
        "porosity": porosity,
        "coordination": {"mean": coord_mean, "std": coord_std},
        "rg_evolution": rg_evolution,
        "anisotropy": anisotropy,
        "asphericity": asphericity,
        "acylindricity": acylindricity,
        "principal_moments": eigenvalues.tolist(),
        "principal_axes": eigenvectors.T.tolist(),
    }
```

---

## 10.8 API and Task Integration

### Simulation Task Handler

```
ALGORITHM Run_Limiting_Simulation
INPUT:
    simulation: Simulation object with algorithm="limiting"

PROCEDURE:
    params = simulation.parameters
    n_particles = params.get("n_particles", 100)
    configuration_type = params.get("configuration_type")
    packing = params.get("packing", "HC")
    layers = params.get("layers")
    sintering_coeff = params.get("sintering_coeff", 1.0)
    radius = params.get("particle_radius", 1.0)

    # Infer geometry type from configuration
    (geometry_type, df) = infer_geometry_from_config(configuration_type)

    # Generate coordinates
    SWITCH geometry_type:
        CASE "chain":
            SWITCH configuration_type:
                CASE "lineal":
                    coords = generate_linear_chain(n_particles, radius, sintering_coeff)
                CASE "cruz2d":
                    coords = generate_cruz2d(n_particles, radius, sintering_coeff)
                CASE "asterisco":
                    coords = generate_asterisco(n_particles, radius, sintering_coeff)
                CASE "cruz3d":
                    coords = generate_cruz3d(n_particles, radius, sintering_coeff)

        CASE "plane":
            SWITCH configuration_type:
                CASE "plano":
                    coords = generate_hexagonal_plane(n_particles, layers, radius, packing, sintering_coeff)
                CASE "dobleplano":
                    coords = generate_doble_plano(layers, radius, packing, sintering_coeff)
                CASE "tripleplano":
                    coords = generate_triple_plano(layers, radius, sintering_coeff)

        CASE "sphere":
            coords = generate_cuboctaedro(layers, radius, packing, sintering_coeff)

    # Actual particle count may differ
    actual_n = len(coords)

    # Compute prefactor
    SWITCH geometry_type:
        CASE "chain": kf = compute_kf_chain(actual_n)
        CASE "plane": kf = compute_kf_plane(actual_n)
        CASE "sphere": kf = compute_kf_sphere(actual_n)

    # Create radii array
    radii = full(actual_n, radius)

    # Compute metrics
    metrics = compute_limiting_metrics(coords, actual_n, radius)
    metrics["fractal_dimension"] = df
    metrics["prefactor"] = kf

    # Store results
    simulation.geometry = to_numpy_binary(coords, radii)
    simulation.metrics = metrics
    simulation.status = "completed"
    simulation.save()

    # Run box-counting if configured
    run_box_counting_if_configured(simulation.id)
```

### API Request Examples

```
POST /api/v1/projects/{project_id}/simulations/

# Df=1 Linear Chain
{
    "algorithm": "limiting",
    "parameters": {
        "n_particles": 100,
        "configuration_type": "lineal",
        "particle_radius": 1.0,
        "sintering_coeff": 1.0
    }
}

# Df=2 Hexagonal Plane with 3 rings
{
    "algorithm": "limiting",
    "parameters": {
        "configuration_type": "plano",
        "layers": 3,
        "packing": "HC",
        "particle_radius": 1.0
    }
}

# Df=3 Cuboctahedron
{
    "algorithm": "limiting",
    "parameters": {
        "configuration_type": "cuboctaedro",
        "layers": 2,
        "packing": "HC",
        "particle_radius": 1.0,
        "sintering_coeff": 0.9
    }
}
```

---

## 10.9 Batch Studies with Limiting Cases

### Parametric Study Configuration

When `include_limiting_cases=true` in a parametric study:

```
POST /api/v1/projects/{project_id}/studies/

{
    "name": "Df Sweep with Limiting Cases",
    "base_algorithm": "limiting",
    "base_parameters": {
        "particle_radius": 1.0,
        "packing": "HC"
    },
    "parameter_grid": {
        "n_particles": [50, 100, 200],
        "configuration_type": ["lineal", "plano", "cuboctaedro"]
    },
    "include_limiting_cases": true,
    "limiting_cases_config": {
        "include_boundaries": true,
        "include_theoretical": true
    },
    "sintering_config": {
        "distribution_type": "fixed",
        "coefficient": 1.0
    },
    "include_box_counting": true
}
```

This generates:
- 9 regular grid combinations (3 N values x 3 configurations)
- Additional boundary cases
- Sintering extreme cases (if enabled)

---

## 10.10 Implementation Checklist

### Geometry Generators

- [ ] `generate_linear_chain()` - Df=1 lineal
- [ ] `generate_cruz2d()` - Df=1 2D cross
- [ ] `generate_asterisco()` - Df=1 asterisk
- [ ] `generate_cruz3d()` - Df=1 3D cross
- [ ] `generate_hexagonal_plane()` - Df=2 single plane
- [ ] `generate_doble_plano()` - Df=2 double plane
- [ ] `generate_triple_plano()` - Df=2 triple plane
- [ ] `generate_cuboctaedro()` - Df=3 compact
- [ ] `generate_hcp_sphere()` - Df=3 small N handler
- [ ] `get_complete_hexagonal_counts()` - hexagonal numbers

### Metrics and Prefactors

- [ ] `compute_limiting_metrics()` - all morphological metrics
- [ ] `compute_kf_chain()` - Df=1 prefactor
- [ ] `compute_kf_plane()` - Df=2 prefactor
- [ ] `compute_kf_sphere()` - Df=3 prefactor
- [ ] `infer_geometry_from_config()` - config to geometry mapping

### Task Integration

- [ ] Handle `algorithm="limiting"` in `run_simulation_task`
- [ ] Update parameters with actual particle count
- [ ] Store computed Df and kf in metrics
- [ ] Integration with box-counting
- [ ] Proper sintering coefficient application

### Testing

- [ ] Test each geometry generator independently
- [ ] Verify Df values match expectations
- [ ] Test hexagonal number calculations
- [ ] Test prefactor calculations
- [ ] Test sintering coefficient effects
- [ ] Test packing variations (HC, CS, CCC)

---

## 10.11 Validation Expected Results

### Geometry Validation Table

| Configuration | N | Expected Df | Expected kf (approx) | Rg/rp (approx) |
|---------------|---|-------------|---------------------|----------------|
| lineal | 100 | 1.0 | 0.17 | 57.7 |
| plano (k=3) | 37 | 2.0 | ~1.2 | 5.5 |
| plano (k=5) | 91 | 2.0 | ~1.2 | 8.6 |
| cuboctaedro (k=2, HC) | ~55 | 3.0 | ~1.0 | 2.8 |
| cruz2d | 17 | 1.0 | ~0.4 | 8.0 |

### Box-Counting Validation

Run box-counting on limiting geometries to verify the analysis method:

```
Expected Results:

Configuration      | True Df | BC Df   | R^2
-------------------|---------|---------|------
lineal (N=100)    | 1.0     | 0.98-1.02 | >0.99
plano (k=3)       | 2.0     | 1.95-2.05 | >0.98
cuboctaedro (k=2) | 3.0     | 2.90-3.05 | >0.97
```

If box-counting results deviate significantly, check:
1. Points per sphere (increase for better coverage)
2. Precision (increase for finer scales)
3. Linear region detection (verify robust regression)
