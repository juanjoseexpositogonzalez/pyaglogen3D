# Data Model Implementation Checklist

## Project Model

### Fields
- [ ] id: UUIDField (primary key, auto-generated)
- [ ] name: CharField (max 255, required)
- [ ] description: TextField (nullable)
- [ ] created_at: DateTimeField (auto_now_add)
- [ ] updated_at: DateTimeField (auto_now)

### Properties
- [ ] simulation_count: Count of related simulations
- [ ] analysis_count: Count of related FraktalAnalysis

### Meta Options
- [ ] ordering: ['-updated_at']

### Indexes
- [ ] Primary key index on id
- [ ] Index on -updated_at

## Simulation Model

### Fields
- [ ] id: UUIDField (primary key)
- [ ] project: ForeignKey to Project (CASCADE)
- [ ] name: CharField (max 255)
- [ ] algorithm: CharField with choices
- [ ] parameters: JSONField
- [ ] seed: BigIntegerField
- [ ] geometry: BinaryField (nullable)
- [ ] metrics: JSONField (nullable)
- [ ] status: CharField with choices (default 'queued')
- [ ] task_id: CharField (nullable)
- [ ] execution_time_ms: PositiveIntegerField (nullable)
- [ ] error_message: TextField (nullable)
- [ ] created_at: DateTimeField
- [ ] started_at: DateTimeField (nullable)
- [ ] completed_at: DateTimeField (nullable)

### Choices
- [ ] Algorithm: dla, cca, ballistic, ballistic_cc, tunable, tunable_cc, limiting
- [ ] Status: queued, running, completed, failed, cancelled

### Properties
- [ ] has_geometry: Boolean check for geometry field

### Indexes
- [ ] Primary key index on id
- [ ] Index on (project_id, -created_at)
- [ ] Index on status
- [ ] Index on algorithm

## ParametricStudy Model

### Fields
- [ ] id: UUIDField (primary key)
- [ ] project: ForeignKey to Project (CASCADE)
- [ ] name: CharField (max 255)
- [ ] description: TextField (nullable)
- [ ] base_algorithm: CharField with choices
- [ ] base_parameters: JSONField
- [ ] parameter_grid: JSONField
- [ ] seeds_per_combination: PositiveIntegerField (default 1)
- [ ] simulations: ManyToManyField to Simulation
- [ ] include_limiting_cases: BooleanField (default False)
- [ ] limiting_cases_config: JSONField (nullable)
- [ ] sintering_config: JSONField (nullable)
- [ ] include_box_counting: BooleanField (default False)
- [ ] box_counting_params: JSONField (nullable)
- [ ] status: CharField (default 'pending')
- [ ] created_at: DateTimeField
- [ ] updated_at: DateTimeField

### Properties
- [ ] total_simulations: Count of simulations
- [ ] completed_simulations: Count with status='completed'

### Indexes
- [ ] Primary key index on id
- [ ] Index on (project_id, -created_at)

## FraktalAnalysis Model

### Fields
- [ ] id: UUIDField (primary key)
- [ ] project: ForeignKey to Project (CASCADE)
- [ ] name: CharField (max 255)
- [ ] source_type: CharField (uploaded_image, simulation_projection)
- [ ] simulation: ForeignKey to Simulation (nullable, SET_NULL)
- [ ] projection_params: JSONField (nullable)
- [ ] original_image: BinaryField (nullable)
- [ ] original_filename: CharField (nullable)
- [ ] original_content_type: CharField (nullable)
- [ ] processed_image: BinaryField (nullable)
- [ ] model: CharField (granulated_2012, voxel_2018)
- [ ] npix: FloatField
- [ ] dpo: FloatField (nullable)
- [ ] delta: FloatField (default 1.0)
- [ ] correction_3d: BooleanField (default True)
- [ ] pixel_min: PositiveIntegerField (default 0)
- [ ] pixel_max: PositiveIntegerField (default 255)
- [ ] npo_limit: PositiveIntegerField (default 0)
- [ ] escala: FloatField (default 1.0)
- [ ] m_exponent: FloatField (default 0.35)
- [ ] auto_calibrate: BooleanField (default False)
- [ ] results: JSONField (nullable)
- [ ] status: CharField (default 'queued')
- [ ] execution_time_ms: PositiveIntegerField (nullable)
- [ ] engine_version: CharField (nullable)
- [ ] error_message: TextField (nullable)
- [ ] created_at: DateTimeField
- [ ] started_at: DateTimeField (nullable)
- [ ] completed_at: DateTimeField (nullable)

### Indexes
- [ ] Primary key index on id
- [ ] Index on (project_id, -created_at)
- [ ] Index on status
- [ ] Index on model
- [ ] Index on source_type

## JSON Field Structures

### Simulation Parameters (DLA)
- [ ] n_particles: integer
- [ ] sticking_probability: float
- [ ] lattice_size: integer
- [ ] seed_radius: float (optional)
- [ ] radius_min: float (optional)
- [ ] radius_max: float (optional)
- [ ] sintering_coefficient: float (optional)
- [ ] sintering_distribution: string (optional)

### Simulation Parameters (Tunable)
- [ ] n_particles: integer
- [ ] target_df: float
- [ ] target_kf: float
- [ ] sticking_probability: float (optional)
- [ ] radius_min: float (optional)
- [ ] radius_max: float (optional)
- [ ] sintering_coefficient: float (optional)
- [ ] sintering_distribution: string (optional)
- [ ] sintering_mean: float (optional)
- [ ] sintering_std: float (optional)

### Simulation Metrics
- [ ] fractal_dimension: float
- [ ] fractal_dimension_std: float
- [ ] prefactor: float
- [ ] radius_of_gyration: float
- [ ] porosity: float
- [ ] coordination: {mean: float, std: float}
- [ ] rg_evolution: array of floats
- [ ] anisotropy: float
- [ ] asphericity: float
- [ ] acylindricity: float
- [ ] principal_moments: array of 3 floats
- [ ] principal_axes: 3x3 array

### Parameter Grid
- [ ] Dictionary with parameter names as keys
- [ ] Array of values for each parameter

### Limiting Cases Config
- [ ] include_boundaries: boolean
- [ ] include_theoretical: boolean
- [ ] theoretical_overrides: dict (optional)

### Sintering Config
- [ ] distribution_type: string (fixed, uniform, normal)
- [ ] coefficient: float (for fixed)
- [ ] min, max: float (for uniform)
- [ ] mean, std: float (for normal)

### FRAKTAL Results
- [ ] status: string
- [ ] model: string
- [ ] rg: float
- [ ] ap: float
- [ ] df: float
- [ ] npo: float
- [ ] npo_visual: float
- [ ] npo_ratio: float
- [ ] npo_aligned: boolean
- [ ] kf: float
- [ ] zf: float
- [ ] jf: float (nullable)
- [ ] dpo_estimated: float
- [ ] volume: float
- [ ] mass: float
- [ ] surface_area: float
- [ ] calibration_attempts: array (optional)
- [ ] best_dpo: float (optional)

## Migrations

### Migration Files
- [ ] Create initial migration for Project
- [ ] Create initial migration for Simulation
- [ ] Create migration for ParametricStudy
- [ ] Create migration for FraktalAnalysis
- [ ] Add indexes migration
- [ ] Test migrations forward and backward

### Migration Commands
- [ ] makemigrations runs without errors
- [ ] migrate applies all migrations
- [ ] showmigrations shows all applied
