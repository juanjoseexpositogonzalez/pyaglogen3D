# Testing Implementation Checklist

## Test Infrastructure

### pytest Setup
- [ ] Install pytest, pytest-django, pytest-cov, pytest-mock
- [ ] Create pytest.ini or pyproject.toml [tool.pytest.ini_options]
- [ ] Create conftest.py with fixtures
- [ ] Configure test database settings

### Test Fixtures
- [ ] db fixture for database access
- [ ] api_client fixture for API testing
- [ ] project fixture for test project
- [ ] simulation_params fixture for valid parameters
- [ ] completed_simulation fixture with geometry/metrics
- [ ] mock_aglogen_core fixture for fast tests

### Coverage Configuration
- [ ] Configure pytest-cov with --cov=apps
- [ ] Set minimum coverage threshold (95%)
- [ ] Configure coverage exclusions (migrations, __init__)
- [ ] Generate HTML report

## Model Tests

### Project Model
- [ ] test_create_project
- [ ] test_project_uuid_generation
- [ ] test_project_timestamps
- [ ] test_project_simulation_count
- [ ] test_project_analysis_count
- [ ] test_project_cascade_delete
- [ ] test_project_ordering

### Simulation Model
- [ ] test_create_simulation
- [ ] test_simulation_uuid_generation
- [ ] test_simulation_default_status
- [ ] test_simulation_all_algorithms
- [ ] test_simulation_status_choices
- [ ] test_geometry_binary_storage
- [ ] test_geometry_retrieval
- [ ] test_metrics_json_storage

### ParametricStudy Model
- [ ] test_create_study
- [ ] test_study_simulation_m2m
- [ ] test_study_total_simulations
- [ ] test_study_completed_count

### FraktalAnalysis Model
- [ ] test_create_uploaded_analysis
- [ ] test_create_projection_analysis
- [ ] test_analysis_simulation_link
- [ ] test_results_storage

## Serializer Tests

### SimulationSerializer
- [ ] test_valid_dla_params
- [ ] test_valid_cca_params
- [ ] test_valid_tunable_params
- [ ] test_valid_limiting_params
- [ ] test_invalid_n_particles_low
- [ ] test_invalid_n_particles_high
- [ ] test_invalid_target_df_low
- [ ] test_invalid_target_df_high
- [ ] test_invalid_sticking_probability
- [ ] test_auto_seed_generation
- [ ] test_custom_seed
- [ ] test_auto_name_generation
- [ ] test_custom_name
- [ ] test_sintering_fixed_config
- [ ] test_sintering_uniform_config
- [ ] test_sintering_normal_config
- [ ] test_invalid_sintering_coefficient
- [ ] test_invalid_sintering_std

### ParametricStudySerializer
- [ ] test_valid_parameter_grid
- [ ] test_empty_parameter_grid_error
- [ ] test_single_value_grid
- [ ] test_limiting_cases_config
- [ ] test_sintering_config_validation
- [ ] test_box_counting_params_valid
- [ ] test_box_counting_precision_range
- [ ] test_box_counting_points_range

### FraktalAnalysisSerializer
- [ ] test_uploaded_image_creation
- [ ] test_projection_source_creation
- [ ] test_image_base64_validation
- [ ] test_image_size_limit
- [ ] test_model_parameter_validation
- [ ] test_auto_calibrate_without_dpo

## API Tests

### Projects API
- [ ] test_list_projects_empty
- [ ] test_list_projects_with_data
- [ ] test_list_projects_pagination
- [ ] test_create_project
- [ ] test_create_project_minimal
- [ ] test_create_project_validation
- [ ] test_get_project_detail
- [ ] test_get_project_not_found
- [ ] test_update_project
- [ ] test_partial_update_project
- [ ] test_delete_project
- [ ] test_delete_cascades

### Simulations API
- [ ] test_list_simulations_empty
- [ ] test_list_simulations_with_data
- [ ] test_list_simulations_filter_status
- [ ] test_list_simulations_filter_algorithm
- [ ] test_create_simulation_dla
- [ ] test_create_simulation_tunable
- [ ] test_create_simulation_limiting
- [ ] test_create_simulation_queues_task
- [ ] test_get_simulation
- [ ] test_get_simulation_with_geometry
- [ ] test_delete_simulation
- [ ] test_cancel_queued_simulation
- [ ] test_cancel_running_simulation
- [ ] test_cancel_completed_fails
- [ ] test_get_geometry_not_ready
- [ ] test_get_geometry_success
- [ ] test_get_geometry_content_type
- [ ] test_projection_png
- [ ] test_projection_svg
- [ ] test_projection_batch_zip
- [ ] test_export_csv
- [ ] test_export_csv_headers
- [ ] test_neighbor_graph
- [ ] test_neighbor_graph_structure
- [ ] test_box_counting
- [ ] test_box_counting_params

### Parametric Studies API
- [ ] test_create_study
- [ ] test_study_generates_simulations
- [ ] test_study_correct_count
- [ ] test_study_with_limiting_cases
- [ ] test_study_with_sintering
- [ ] test_study_results
- [ ] test_study_results_progress
- [ ] test_study_export_csv

### FRAKTAL API
- [ ] test_create_uploaded_analysis
- [ ] test_create_projection_analysis
- [ ] test_get_analysis
- [ ] test_get_original_image
- [ ] test_rerun_analysis
- [ ] test_delete_analysis

## Rust Engine Integration Tests

### Algorithm Tests
- [ ] test_dla_generates_particles
- [ ] test_dla_correct_count
- [ ] test_dla_valid_metrics
- [ ] test_cca_single_agglomerate
- [ ] test_cca_fractal_dimension_range
- [ ] test_ballistic_higher_df
- [ ] test_tunable_reaches_target_df
- [ ] test_tunable_reaches_target_kf
- [ ] test_tunable_cc_clusters
- [ ] test_limiting_chain_df
- [ ] test_limiting_plane_df
- [ ] test_limiting_sphere_df

### Metrics Tests
- [ ] test_rg_calculation
- [ ] test_df_from_regression
- [ ] test_coordination_counting
- [ ] test_porosity_calculation
- [ ] test_inertia_tensor
- [ ] test_shape_descriptors

### Determinism Tests
- [ ] test_same_seed_same_result
- [ ] test_different_seed_different_result

### Box Counting Tests
- [ ] test_box_counting_2d
- [ ] test_box_counting_3d
- [ ] test_morton_encoding
- [ ] test_known_geometry_df

## Utility Tests

### Name Generation
- [ ] test_generate_simulation_name
- [ ] test_name_includes_algorithm
- [ ] test_name_includes_timestamp
- [ ] test_generate_fraktal_name

### Limiting Cases
- [ ] test_generate_boundary_cases
- [ ] test_boundary_min_values
- [ ] test_boundary_max_values
- [ ] test_theoretical_extremes
- [ ] test_sintering_extreme_cases

### Sintering Config
- [ ] test_apply_fixed_sintering
- [ ] test_apply_uniform_sintering
- [ ] test_apply_normal_sintering
- [ ] test_normal_clamping

## Task Tests

### Simulation Tasks
- [ ] test_task_updates_status_running
- [ ] test_task_saves_geometry
- [ ] test_task_saves_metrics
- [ ] test_task_updates_status_completed
- [ ] test_task_handles_error
- [ ] test_task_saves_execution_time
- [ ] test_task_cancellation

### FRAKTAL Tasks
- [ ] test_fraktal_task_execution
- [ ] test_fraktal_auto_calibrate
- [ ] test_fraktal_projection_source

## Performance Tests

### Benchmarks
- [ ] test_dla_100_particles_time
- [ ] test_dla_1000_particles_time
- [ ] test_tunable_500_particles_time
- [ ] test_box_counting_performance

### Load Tests (Optional)
- [ ] test_concurrent_simulations
- [ ] test_api_under_load

## CI/CD Tests

### GitHub Actions
- [ ] Backend tests run on push
- [ ] Rust tests run on push
- [ ] Frontend tests run on push
- [ ] Coverage uploaded to Codecov
- [ ] Tests pass before merge
