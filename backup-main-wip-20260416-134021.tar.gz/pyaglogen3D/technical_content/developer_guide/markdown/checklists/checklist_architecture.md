# Architecture Implementation Checklist

## Project Structure

### Root Directory
- [ ] Create project root directory
- [ ] Create .gitignore with Python, Node, Rust patterns
- [ ] Create .env.example with all required variables
- [ ] Create README.md with project overview
- [ ] Create docker-compose.yml for local development

### Backend Structure
- [ ] Create backend/ directory
- [ ] Create backend/apps/ for Django apps
- [ ] Create backend/config/ for settings
- [ ] Create backend/tests/ for test files
- [ ] Create backend/pyproject.toml with dependencies
- [ ] Create backend/manage.py

### Frontend Structure
- [ ] Create frontend/ directory with Next.js
- [ ] Create frontend/src/app/ for App Router
- [ ] Create frontend/src/components/ for UI
- [ ] Create frontend/src/hooks/ for React Query
- [ ] Create frontend/src/stores/ for Zustand
- [ ] Create frontend/src/lib/ for utilities

### Rust Engine Structure
- [ ] Create aglogen_core/ directory
- [ ] Create aglogen_core/src/common/
- [ ] Create aglogen_core/src/simulation/
- [ ] Create aglogen_core/src/fractal/
- [ ] Create aglogen_core/src/projection/
- [ ] Create aglogen_core/Cargo.toml
- [ ] Create aglogen_core/pyproject.toml

## Django Configuration

### Settings Structure
- [ ] Create config/settings/__init__.py
- [ ] Create config/settings/base.py with common settings
- [ ] Create config/settings/development.py
- [ ] Create config/settings/production.py
- [ ] Create config/settings/test.py

### Base Settings
- [ ] Configure INSTALLED_APPS with all apps
- [ ] Configure database with DATABASE_URL support
- [ ] Configure REST Framework settings
- [ ] Configure pagination (20 per page)
- [ ] Configure CORS settings
- [ ] Configure static files with WhiteNoise
- [ ] Configure logging

### Celery Configuration
- [ ] Create config/celery.py
- [ ] Configure broker URL (Redis)
- [ ] Configure result backend (Redis)
- [ ] Set serializer to JSON
- [ ] Configure task discovery

## Django Apps

### Core App
- [ ] Create apps/core/__init__.py
- [ ] Create apps/core/urls.py with API router

### Projects App
- [ ] Create apps/projects/ structure
- [ ] Create Project model with UUID, name, description
- [ ] Create ProjectSerializer
- [ ] Create ProjectViewSet
- [ ] Register routes

### Simulations App
- [ ] Create apps/simulations/ structure
- [ ] Create Simulation model
- [ ] Create ParametricStudy model
- [ ] Create serializers with validation
- [ ] Create ViewSets
- [ ] Create tasks.py with Celery tasks
- [ ] Create utils.py with helpers
- [ ] Create services/projection.py
- [ ] Register routes

### Fractal Analysis App
- [ ] Create apps/fractal_analysis/ structure
- [ ] Create ImageAnalysis model
- [ ] Create FraktalAnalysis model
- [ ] Create ComparisonSet model
- [ ] Create serializers
- [ ] Create ViewSets
- [ ] Create tasks.py
- [ ] Register routes

## Frontend Configuration

### Next.js Setup
- [ ] Configure next.config.js with standalone output
- [ ] Configure TypeScript (tsconfig.json)
- [ ] Configure Tailwind CSS
- [ ] Configure PostCSS
- [ ] Create .env.local with API URL

### App Router Setup
- [ ] Create root layout.tsx
- [ ] Create providers.tsx with QueryClientProvider
- [ ] Create global CSS with Tailwind

### API Client
- [ ] Create lib/api.ts with fetch wrapper
- [ ] Create ApiError class
- [ ] Implement all API modules (projects, simulations, etc.)
- [ ] Implement NumPy binary parser

### State Management
- [ ] Create stores/viewerStore.ts
- [ ] Configure localStorage persistence
- [ ] Define all viewer state and actions

### Custom Hooks
- [ ] Create hooks/useProjects.ts
- [ ] Create hooks/useSimulations.ts
- [ ] Create hooks/useFraktalAnalyses.ts

## Rust Engine Configuration

### Cargo Dependencies
- [ ] Add pyo3 with extension-module feature
- [ ] Add numpy for array support
- [ ] Add ndarray with rayon feature
- [ ] Add nalgebra for linear algebra
- [ ] Add rand and rand_pcg for RNG
- [ ] Add rand_distr for distributions
- [ ] Add rayon for parallelism
- [ ] Add thiserror for error handling

### PyO3 Module
- [ ] Create lib.rs with #[pymodule]
- [ ] Export all simulation functions
- [ ] Export fractal analysis functions
- [ ] Export projection functions
- [ ] Configure GIL release for heavy computations

### Build Configuration
- [ ] Configure pyproject.toml for maturin
- [ ] Set release profile with LTO
- [ ] Configure wheel naming

## Integration Points

### Backend ↔ Rust Engine
- [ ] Install aglogen_core wheel in backend venv
- [ ] Import in tasks.py
- [ ] Handle PyO3 exceptions

### Frontend ↔ Backend
- [ ] Configure CORS for frontend origin
- [ ] Verify API base URL
- [ ] Test all endpoints from frontend

### Backend ↔ Services
- [ ] Verify PostgreSQL connection
- [ ] Verify Redis connection
- [ ] Verify Celery broker connection
- [ ] Test task dispatch and result retrieval
