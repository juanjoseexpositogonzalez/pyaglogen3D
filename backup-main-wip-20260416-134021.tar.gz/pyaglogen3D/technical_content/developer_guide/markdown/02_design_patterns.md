# Chapter 2: Design Patterns

This chapter documents the design patterns employed throughout PyAglogen3D, explaining their implementation and rationale.

## 2.1 Backend Patterns (Django)

### Repository Pattern via Django ORM

Django's ORM acts as the repository layer, abstracting database operations from business logic.

**Pattern Structure:**
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   ViewSet   │ ──► │    Model    │ ──► │  Database   │
│  (Consumer) │     │ (Repository)│     │  (Storage)  │
└─────────────┘     └─────────────┘     └─────────────┘
```

**Implementation Example:**

```
ViewSet.get_queryset()
    │
    ▼
Simulation.objects
    .filter(project=project)
    .select_related('project')
    .order_by('-created_at')
```

**Benefits:**
- Query optimization via select_related/prefetch_related
- Database-agnostic code
- Built-in transaction management

---

### Serializer Pattern (Data Transfer Objects)

Serializers handle data transformation between external representation (JSON) and internal representation (model instances).

**Pattern Structure:**
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Request   │ ──► │ Serializer  │ ──► │   Model     │
│   (JSON)    │     │ (Transform) │     │ (Internal)  │
└─────────────┘     └─────────────┘     └─────────────┘
                          │
                          ▼
                    ┌─────────────┐
                    │ Validation  │
                    │   Rules     │
                    └─────────────┘
```

**Key Implementation Patterns:**

1. **Nested Serializers for Read**
```
ProjectDetailSerializer
├── id, name, description
├── recent_simulations (nested)
└── recent_analyses (nested)
```

2. **Separate Create/Update Serializers**
```
SimulationSerializer       # Read (full metrics, geometry info)
SimulationCreateSerializer # Write (only parameters)
```

3. **Custom Validation**
```
validate_sintering_config(value):
    distribution_type must be in [fixed, uniform, normal]
    coefficient must be in [0.5, 1.0]
    if normal: std must be in [0.0, 0.2]
```

---

### Service Layer Pattern

Complex business logic is extracted to service modules, keeping views thin.

**Pattern Structure:**
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   ViewSet   │ ──► │   Service   │ ──► │    Model    │
│  (Request)  │     │  (Logic)    │     │   (Data)    │
└─────────────┘     └─────────────┘     └─────────────┘
```

**Implementation:**

```
services/projection.py:
    render_projection_png(x, y, radii, bounds, dpi, figsize, colors)
    render_projection_svg(x, y, radii, bounds, figsize, colors)
    create_projection_filename(base_name, azimuth, elevation, format)
```

**Benefits:**
- Testable business logic in isolation
- Reusable across multiple views
- Clear separation of concerns

---

### Command Pattern (Celery Tasks)

Asynchronous operations are encapsulated as Celery tasks, acting as commands that can be queued and executed.

**Pattern Structure:**
```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   ViewSet   │ ──► │    Task     │ ──► │   Redis     │ ──► │   Worker    │
│  (Invoker)  │     │ (Command)   │     │  (Queue)    │     │ (Executor)  │
└─────────────┘     └─────────────┘     └─────────────┘     └─────────────┘
```

**Implementation:**

```
Task Definition:
    @shared_task
    def run_simulation_task(simulation_id):
        simulation = Simulation.objects.get(id=simulation_id)
        simulation.status = RUNNING
        simulation.save()

        result = aglogen_core.run_algorithm(...)

        simulation.geometry = result.coordinates
        simulation.metrics = result.metrics
        simulation.status = COMPLETED
        simulation.save()

Invocation:
    simulation = Simulation.objects.create(...)
    run_simulation_task.delay(simulation.id)
```

**Benefits:**
- Decoupled execution from request handling
- Scalable worker pool
- Task retry and error handling

---

### Strategy Pattern (Algorithm Selection)

Different simulation algorithms implement a common interface, selected at runtime.

**Pattern Structure:**
```
                    ┌─────────────────────┐
                    │  run_simulation     │
                    │  (Context)          │
                    └─────────────────────┘
                              │
         ┌────────────────────┼────────────────────┐
         ▼                    ▼                    ▼
┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐
│  DLA Strategy   │  │  CCA Strategy   │  │ Tunable Strategy│
│  run_dla()      │  │  run_cca()      │  │ run_tunable()   │
└─────────────────┘  └─────────────────┘  └─────────────────┘
```

**Implementation (Pseudocode):**

```
ALGORITHM_HANDLERS = {
    'dla': run_dla_simulation,
    'cca': run_cca_simulation,
    'ballistic': run_ballistic_simulation,
    'ballistic_cc': run_ballistic_cc_simulation,
    'tunable': run_tunable_simulation,
    'tunable_cc': run_tunable_cc_simulation,
    'limiting': run_limiting_simulation,
}

def run_simulation_task(simulation_id):
    simulation = get_simulation(simulation_id)
    handler = ALGORITHM_HANDLERS[simulation.algorithm]
    result = handler(simulation.parameters)
```

---

### Factory Pattern (Limiting Case Geometries)

Limiting case geometries are created through factory functions based on configuration.

**Pattern Structure:**
```
┌─────────────────────┐
│  LimitingFactory    │
│  ─────────────────  │
│  create(config)     │
└─────────────────────┘
         │
         ├─── config.type == 'chain' ───► generate_linear_chain()
         ├─── config.type == 'plane' ───► generate_hexagonal_plane()
         └─── config.type == 'sphere' ──► generate_cuboctaedro()
```

**Implementation (Pseudocode):**

```
CHAIN_GENERATORS = {
    'lineal': generate_linear_chain,
    'cruz2d': generate_cruz2d,
    'asterisco': generate_asterisco,
    'cruz3d': generate_cruz3d,
}

PLANE_GENERATORS = {
    'plano': generate_hexagonal_plane,
    'dobleplano': generate_doble_plano,
    'tripleplano': generate_triple_plano,
}

def create_limiting_geometry(params):
    if params.geometry_type == 'chain':
        generator = CHAIN_GENERATORS[params.configuration_type]
    elif params.geometry_type == 'plane':
        generator = PLANE_GENERATORS[params.configuration_type]
    else:
        generator = SPHERE_GENERATORS[params.configuration_type]

    return generator(params.n_particles, params.radius, ...)
```

---

## 2.2 Frontend Patterns (React)

### Container/Presentation Pattern

Pages act as containers (data fetching) while components handle presentation.

**Pattern Structure:**
```
┌────────────────────────────────────────────────────┐
│  Page (Container)                                   │
│  ──────────────────────────────────────────────    │
│  - Data fetching (React Query hooks)               │
│  - Loading/error states                            │
│  - Layout composition                              │
│                                                     │
│  ┌──────────────────────────────────────────────┐  │
│  │  Component (Presentation)                    │  │
│  │  ────────────────────────────────────────    │  │
│  │  - Receives data via props                   │  │
│  │  - Renders UI                                │  │
│  │  - Handles user interactions                 │  │
│  └──────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────┘
```

**Implementation Example:**

```
// Page (Container)
SimulationPage:
    simulation = useSimulation(projectId, simId)
    geometry = useSimulationGeometry(simId)

    if (loading) return <LoadingSpinner />
    if (error) return <ErrorMessage />

    return (
        <SimulationViewer
            simulation={simulation}
            geometry={geometry}
        />
    )

// Component (Presentation)
SimulationViewer:
    props: { simulation, geometry }

    return (
        <div>
            <AgglomerateViewer coordinates={geometry.coordinates} />
            <MetricsPanel metrics={simulation.metrics} />
        </div>
    )
```

---

### Custom Hook Pattern

Data fetching and state logic are encapsulated in custom hooks.

**Pattern Structure:**
```
┌─────────────────────────────────────────┐
│  Custom Hook                             │
│  ─────────────────────────────────────  │
│  - Encapsulates useQuery/useMutation    │
│  - Manages loading/error states         │
│  - Provides typed data                  │
└─────────────────────────────────────────┘
         │
         │ returns
         ▼
┌─────────────────────────────────────────┐
│  { data, isLoading, error, refetch }    │
└─────────────────────────────────────────┘
```

**Implementation (Pseudocode):**

```
useSimulation(projectId, id):
    return useQuery({
        queryKey: ['simulation', projectId, id],
        queryFn: () => api.simulations.get(projectId, id),
        refetchInterval: (data) =>
            data?.status in ['queued', 'running'] ? 2000 : false
    })

useCreateSimulation(projectId):
    queryClient = useQueryClient()

    return useMutation({
        mutationFn: (data) => api.simulations.create(projectId, data),
        onSuccess: () => {
            queryClient.invalidateQueries(['simulations', projectId])
        }
    })
```

---

### Store Pattern (Zustand)

Global UI state is managed through Zustand stores with persistence.

**Pattern Structure:**
```
┌─────────────────────────────────────────────────────┐
│  Zustand Store                                       │
│  ───────────────────────────────────────────────    │
│  State:                                              │
│    - colorMode                                       │
│    - showAxes                                        │
│    - exportRequest                                   │
│                                                      │
│  Actions:                                            │
│    - setColorMode(mode)                              │
│    - toggleAxes()                                    │
│    - requestExport(format)                           │
│                                                      │
│  Middleware:                                         │
│    - persist (localStorage)                          │
└─────────────────────────────────────────────────────┘
```

**Implementation (Pseudocode):**

```
useViewerStore = create(
    persist(
        (set) => ({
            // State
            colorMode: 'uniform',
            showAxes: true,
            autoRotate: false,

            // Actions
            setColorMode: (mode) => set({ colorMode: mode }),
            toggleAxes: () => set((s) => ({ showAxes: !s.showAxes })),
            requestExport: (format) => set({ exportRequest: format }),
            clearExportRequest: () => set({ exportRequest: null }),
        }),
        { name: 'viewer-settings' }
    )
)
```

---

### Compound Component Pattern

Complex components expose sub-components for flexible composition.

**Pattern Structure:**
```
<Card>
    <Card.Header>
        <Card.Title>Title</Card.Title>
        <Card.Description>Description</Card.Description>
    </Card.Header>
    <Card.Content>
        Content here
    </Card.Content>
    <Card.Footer>
        Actions
    </Card.Footer>
</Card>
```

**Usage in Shadcn/UI Components:**
- Card (CardHeader, CardTitle, CardContent, CardFooter)
- Select (SelectTrigger, SelectContent, SelectItem)
- Tabs (TabsList, TabsTrigger, TabsContent)

---

### Render Props / Children as Function

Used in 3D viewer for access to Three.js context.

**Pattern Structure:**
```
<Canvas>
    {({ gl, camera, scene }) => (
        <ExportHandler
            gl={gl}
            onExport={handleExport}
        />
    )}
</Canvas>
```

**Implementation in Viewer:**
```
ExportHandler:
    gl = useThree().gl
    exportRequest = useViewerStore().exportRequest

    useEffect(() => {
        if (exportRequest) {
            dataURL = gl.domElement.toDataURL('image/png')
            downloadFile(dataURL, filename)
            clearExportRequest()
        }
    }, [exportRequest])
```

---

## 2.3 Rust Engine Patterns

### Builder Pattern (Simulation Configuration)

Simulation parameters are constructed through builder-like structures.

**Pattern Structure:**
```
SimulationConfig::new()
    .n_particles(1000)
    .target_df(2.1)
    .target_kf(1.3)
    .sintering(0.9)
    .seed(12345)
    .build()
```

**Note:** PyO3 uses function parameters directly, but internal Rust code uses struct builders.

---

### Strategy Pattern (Sintering Models)

Different sintering distribution types implement a common interface.

**Pattern Structure:**
```
trait SinteringStrategy:
    fn get_coefficient(&mut self) -> f64

FixedSintering:
    coefficient: f64
    fn get_coefficient(&mut self) -> f64:
        return self.coefficient

UniformSintering:
    rng: Pcg64
    min: f64
    max: f64
    fn get_coefficient(&mut self) -> f64:
        return self.rng.gen_range(min..max)

NormalSintering:
    rng: Pcg64
    mean: f64
    std: f64
    fn get_coefficient(&mut self) -> f64:
        sample = Normal::new(mean, std).sample(&mut rng)
        return clamp(sample, 0.5, 1.0)
```

---

### Spatial Indexing Pattern

Spatial hash enables O(1) collision detection.

**Pattern Structure:**
```
┌─────────────────────────────────────────────────────┐
│  SpatialHash                                         │
│  ───────────────────────────────────────────────    │
│  HashMap<(i32, i32, i32), Vec<usize>>               │
│                                                      │
│  Methods:                                            │
│    - insert(position, index)                         │
│    - remove(position, index)                         │
│    - query_neighbors(position) -> Vec<usize>         │
│                                                      │
│  Cell Size: 4 * max_radius                           │
│  Query Region: 3x3x3 neighborhood                    │
└─────────────────────────────────────────────────────┘
```

**Collision Detection Flow:**
```
For new particle at position P:
    1. cell = hash(P / cell_size)
    2. neighbors = query_neighbors(cell)  // 27 cells
    3. For each neighbor index in neighbors:
        4. If distance(P, positions[neighbor]) < threshold:
            5. Collision detected
```

---

### Result Pattern (Error Handling)

Rust's Result type propagates errors through the call stack.

**Pattern Structure:**
```
fn run_simulation(params) -> Result<SimulationResult, SimulationError>

SimulationError:
    InvalidParameter { name: String, value: String }
    MaxIterationsExceeded
    NumericalInstability
```

**PyO3 Error Conversion:**
```
impl From<SimulationError> for PyErr:
    fn from(err: SimulationError) -> PyErr:
        PyValueError::new_err(err.to_string())
```

---

## 2.4 Cross-Cutting Patterns

### Observer Pattern (Status Updates)

Frontend observes simulation status through polling.

**Pattern Structure:**
```
┌─────────────┐                        ┌─────────────┐
│  Frontend   │   GET /simulation/{id} │   Backend   │
│  (Observer) │ ─────────────────────► │ (Subject)   │
│             │ ◄───────────────────── │             │
│             │   { status: 'running' }│             │
└─────────────┘                        └─────────────┘
      │                                      │
      │ Every 2 seconds while status         │ Status changes
      │ is 'queued' or 'running'             │ as worker progresses
      ▼                                      ▼
┌─────────────┐                        ┌─────────────┐
│  Update UI  │                        │   Worker    │
│  (Reaction) │                        │  (Mutator)  │
└─────────────┘                        └─────────────┘
```

---

### Adapter Pattern (NumPy Binary Format)

Frontend parses NumPy's .npy binary format to JavaScript arrays.

**Pattern Structure:**
```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Backend        │     │  API Client     │     │  Component      │
│  .npy binary    │ ──► │  (Adapter)      │ ──► │  coordinates[]  │
│  (N,4) float64  │     │  parseNpy()     │     │  radii[]        │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

**Implementation (Pseudocode):**

```
parseNpyFile(buffer):
    // Read header
    magic = buffer[0:6]  // \x93NUMPY
    version = buffer[6:8]

    if version == 1.0:
        header_len = readUint16LE(buffer, 8)
        header_start = 10
    else:
        header_len = readUint32LE(buffer, 8)
        header_start = 12

    header = parseHeader(buffer[header_start:header_start+header_len])
    // header: { dtype: '<f8', shape: [1000, 4] }

    data_start = header_start + header_len
    data = new Float64Array(buffer.slice(data_start))

    // Reshape (N, 4) to separate arrays
    coordinates = []
    radii = []
    for i in range(0, data.length, 4):
        coordinates.push({ x: data[i], y: data[i+1], z: data[i+2] })
        radii.push(data[i+3])

    return { coordinates, radii }
```

---

### Decorator Pattern (Celery Task Wrappers)

Celery decorators add cross-cutting concerns to tasks.

**Pattern Structure:**
```
@shared_task(bind=True, max_retries=3)
@track_execution_time
@handle_errors
def run_simulation_task(self, simulation_id):
    ...
```

**Conceptual Decorators:**
```
track_execution_time:
    start = time.now()
    result = wrapped_function(...)
    duration = time.now() - start
    save_duration(duration)
    return result

handle_errors:
    try:
        return wrapped_function(...)
    except Exception as e:
        save_error(e)
        raise
```

---

## 2.5 Pattern Summary Table

| Pattern | Location | Purpose |
|---------|----------|---------|
| Repository | Django ORM | Database abstraction |
| Serializer/DTO | DRF Serializers | Data transformation |
| Service Layer | services/ modules | Business logic |
| Command | Celery Tasks | Async execution |
| Strategy | Algorithm handlers | Algorithm selection |
| Factory | Limiting geometries | Object creation |
| Container/Presentation | React pages/components | UI separation |
| Custom Hook | hooks/ directory | State encapsulation |
| Store | Zustand | Global state |
| Compound Component | Shadcn UI | Flexible composition |
| Builder | Rust configs | Complex construction |
| Spatial Index | SpatialHash | Collision detection |
| Result | Rust error handling | Error propagation |
| Observer | Status polling | State synchronization |
| Adapter | NumPy parsing | Format conversion |
| Decorator | Celery wrappers | Cross-cutting concerns |
