# PyAglogen3D - Developer Implementation Guide

## Executive Summary

PyAglogen3D is a comprehensive web-based platform for 3D agglomerate simulation and fractal analysis, designed for scientific research in particle morphology, soot formation, and aerosol physics. The system enables researchers to generate synthetic 3D particle agglomerates using multiple algorithms, analyze their fractal properties, and compare results with experimental TEM/SEM images.

### Target Audience

This guide is intended for developers who need to:
- Implement the system from scratch
- Extend the existing functionality
- Maintain and debug the codebase
- Understand architectural decisions

### System Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                         Frontend                                 │
│  Next.js 14 + React 18 + Three.js + TypeScript                  │
│  - 3D Visualization (WebGL)                                      │
│  - Parameter Forms                                                │
│  - Real-time Status Polling                                       │
│  - AI Chat Interface                                              │
└─────────────────────────────────────────────────────────────────┘
                              │ REST API
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         Backend                                  │
│  Django 5 + Django REST Framework                                │
│  - RESTful API (/api/v1/)                                        │
│  - Project/Simulation Management                                  │
│  - Task Queue Coordination                                        │
│  - AI Assistant (multi-provider)                                  │
└─────────────────────────────────────────────────────────────────┘
                              │ Celery Tasks
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Simulation Engine                           │
│  Rust (aglogen_core) + PyO3 Python Bindings                     │
│  - DLA, CCA, Ballistic, Tunable Algorithms                      │
│  - Fractal Analysis (Box-Counting, FRAKTAL)                     │
│  - High-Performance Computations                                 │
└─────────────────────────────────────────────────────────────────┘
                              │
         ┌────────────────────┼────────────────────┐
         ▼                    ▼                    ▼
┌─────────────┐      ┌─────────────┐      ┌─────────────┐
│ PostgreSQL  │      │   Redis     │      │   Celery    │
│  Database   │      │   Broker    │      │   Workers   │
└─────────────┘      └─────────────┘      └─────────────┘
                              │
                              ▼
                     ┌─────────────────┐
                     │  AI Providers   │
                     │ Anthropic/OpenAI│
                     │   Groq/xAI      │
                     └─────────────────┘
```

### Key Capabilities

| Feature | Description |
|---------|-------------|
| **Multi-Algorithm Simulation** | 7 algorithms: DLA, CCA, Ballistic PC/CC, Tunable PC/CC, Limiting Cases |
| **Parametric Studies** | Batch simulations with parameter grid exploration |
| **Fractal Analysis** | Box-counting (2D/3D), FRAKTAL models (2012, 2018) |
| **3D Visualization** | WebGL-based particle viewer with color modes |
| **2D Projections** | Generate TEM-like images from 3D agglomerates |
| **Data Export** | CSV, NumPy binary, PNG/SVG projections |
| **AI Assistant** | Conversational AI with automatic tool calling for simulation and analysis |

### Technology Stack Summary

| Layer | Technology | Purpose |
|-------|------------|---------|
| Frontend | Next.js 14, React 18, TypeScript | User interface |
| 3D Graphics | Three.js, React Three Fiber | Particle visualization |
| State | Zustand, React Query | Client state management |
| Backend | Django 5, DRF | API and business logic |
| Database | PostgreSQL | Data persistence |
| Task Queue | Celery + Redis | Async simulation execution |
| Simulation Engine | Rust + PyO3 | High-performance algorithms |

### Document Structure

| Chapter | Content |
|---------|---------|
| 01 - Architecture | System components, data flow, deployment topology |
| 02 - Design Patterns | Patterns used across the stack |
| 03 - Data Model | Database schema, relationships, JSON structures |
| 04 - Algorithms | Simulation algorithms and fractal analysis methods |
| 05 - Integrations | API endpoints, Celery tasks, external services |
| 06 - Testing | Test strategy, coverage requirements, fixtures |
| 07 - Deployment | Environment setup, Docker, cloud deployment |
| 08 - Batch Simulations | Parametric studies, grid exploration, statistical analysis |
| 09 - Box Counting | 3D box-counting algorithm, fractal dimension calculation |
| 10 - Limiting Cases | Extreme Df/kf combinations, validation against theory |
| 11 - AI Assistant | Conversational AI with tool calling, multi-provider support |

### Prerequisites for Implementation

**Development Environment:**
- Python 3.11+
- Node.js 18+
- Rust 1.75+ (with maturin)
- PostgreSQL 15+
- Redis 7+

**Knowledge Requirements:**
- Django REST Framework
- React with TypeScript
- Three.js/WebGL basics
- Celery task queues
- Rust fundamentals (for engine modifications)

### Conventions Used in This Guide

- **Pseudocode**: Algorithm descriptions use language-agnostic pseudocode
- **Diagrams**: Mermaid syntax for architecture and flow diagrams
- **File References**: `backend/apps/simulations/models.py:45` format
- **Checklists**: Implementation verification at end of each chapter
