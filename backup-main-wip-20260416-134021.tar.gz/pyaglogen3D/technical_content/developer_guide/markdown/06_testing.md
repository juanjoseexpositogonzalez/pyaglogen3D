# Chapter 6: Testing Strategy

This chapter documents the testing approach, test organization, and quality requirements for PyAglogen3D.

## 6.1 Testing Overview

### Test Pyramid

```
                    ┌───────────────┐
                    │    E2E Tests  │  (Browser automation)
                    │   (Minimal)   │
                    └───────────────┘
               ┌─────────────────────────┐
               │   Integration Tests     │  (API, Celery, DB)
               │      (Medium)           │
               └─────────────────────────┘
          ┌───────────────────────────────────┐
          │          Unit Tests               │  (Functions, Models)
          │           (Many)                  │
          └───────────────────────────────────┘
```

### Coverage Requirements

| Component | Minimum Coverage |
|-----------|------------------|
| Backend (Django) | 95% |
| Rust Engine | 90% |
| Frontend (React) | 80% |

### Testing Tools

| Layer | Tool | Purpose |
|-------|------|---------|
| Backend | pytest | Test runner |
| Backend | pytest-django | Django integration |
| Backend | pytest-cov | Coverage reporting |
| Backend | pytest-mock | Mocking |
| Backend | factory_boy | Test data generation |
| Rust | cargo test | Built-in test runner |
| Frontend | Jest | Test runner |
| Frontend | React Testing Library | Component testing |

---

## 6.2 Backend Test Structure

### Directory Organization

```
backend/tests/
├── conftest.py              # Shared fixtures
├── test_models.py           # Model unit tests
├── test_serializers.py      # Serializer validation tests
├── test_utils.py            # Utility function tests
├── test_api.py              # API endpoint integration tests
├── test_aglogen_core.py     # Rust engine integration tests
├── test_adjacency_graph.py  # Graph algorithm tests
└── test_tasks.py            # Celery task tests (optional)
```

### Fixtures (conftest.py)

```
Fixture: db_session
Scope: function
Purpose: Fresh database for each test

Fixture: api_client
Scope: function
Purpose: DRF APIClient instance

Fixture: project
Scope: function
Purpose: Create test project
Returns: Project instance

Fixture: simulation_params
Scope: function
Purpose: Valid simulation parameters
Returns: dict with DLA parameters

Fixture: completed_simulation
Scope: function
Purpose: Simulation with geometry and metrics
Returns: Simulation instance with status=completed

Fixture: mock_aglogen_core
Scope: function
Purpose: Mock Rust engine for fast tests
Returns: MagicMock with realistic return values
```

### Model Tests

```
Test Class: TestProjectModel

Test Cases:
├── test_create_project
│   - Creates project with name and description
│   - Verifies UUID generation
│   - Verifies timestamp auto-population
│
├── test_project_simulation_count
│   - Creates project with simulations
│   - Verifies simulation_count property
│
├── test_project_cascade_delete
│   - Creates project with simulations
│   - Deletes project
│   - Verifies simulations also deleted
│
└── test_project_ordering
    - Creates multiple projects
    - Verifies ordered by -updated_at

Test Class: TestSimulationModel

Test Cases:
├── test_create_simulation
│   - Creates with valid parameters
│   - Verifies default status is 'queued'
│
├── test_simulation_algorithms
│   - Tests all 7 algorithm choices
│   - Verifies enum validation
│
├── test_simulation_status_transitions
│   - Tests valid status changes
│   - Tests invalid transitions
│
├── test_geometry_storage
│   - Creates simulation with numpy geometry
│   - Verifies binary field storage
│   - Verifies retrieval and shape
│
└── test_metrics_json
    - Stores metrics dictionary
    - Retrieves and validates structure
```

### Serializer Tests

```
Test Class: TestSimulationSerializer

Test Cases:
├── test_valid_dla_params
│   - Valid DLA parameters pass validation
│
├── test_valid_tunable_params
│   - Valid tunable parameters pass validation
│
├── test_invalid_n_particles
│   - n_particles < 2 raises error
│   - n_particles > 100000 raises error
│
├── test_invalid_target_df
│   - target_df < 1.0 raises error
│   - target_df > 3.0 raises error
│
├── test_auto_seed_generation
│   - Seed generated if not provided
│   - Seed is positive integer
│
├── test_auto_name_generation
│   - Name generated from algorithm and timestamp
│
└── test_sintering_config_validation
    - Valid fixed config passes
    - Valid uniform config passes
    - Valid normal config passes
    - Invalid coefficient raises error
    - Invalid std raises error

Test Class: TestParametricStudySerializer

Test Cases:
├── test_valid_parameter_grid
│   - Multiple parameters with arrays
│
├── test_empty_parameter_grid
│   - Raises validation error
│
├── test_limiting_cases_config
│   - Valid config passes
│
└── test_box_counting_params_validation
    - Valid points_per_sphere (10-1000)
    - Valid precision (8-21)
    - Invalid values raise errors
```

### API Tests

```
Test Class: TestProjectAPI

Test Cases:
├── test_list_projects
│   - Returns paginated list
│   - Includes simulation_count
│
├── test_create_project
│   - POST creates project
│   - Returns 201 with project data
│
├── test_get_project_detail
│   - Returns project with recent items
│
├── test_update_project
│   - PATCH updates fields
│
└── test_delete_project
    - DELETE removes project
    - Returns 204

Test Class: TestSimulationAPI

Test Cases:
├── test_list_simulations
│   - Returns project simulations
│   - Supports status filter
│
├── test_create_simulation_queues_task
│   - POST creates simulation
│   - Status is 'queued'
│   - Celery task dispatched
│
├── test_get_simulation
│   - Returns full simulation data
│
├── test_delete_simulation
│   - Removes simulation
│
├── test_cancel_running_simulation
│   - Cancels with status update
│
├── test_cancel_completed_fails
│   - Returns 400 error
│
├── test_get_geometry_not_ready
│   - Returns 404 if no geometry
│
├── test_get_geometry_success
│   - Returns .npy binary file
│
├── test_projection_endpoint
│   - Generates PNG/SVG projection
│
├── test_export_csv
│   - Returns CSV with headers
│
└── test_neighbor_graph
    - Returns nodes and edges
    - Includes statistics

Test Class: TestParametricStudyAPI

Test Cases:
├── test_create_study_generates_simulations
│   - Creates N combinations
│   - All simulations queued
│
├── test_study_results_progress
│   - Returns completion progress
│
└── test_study_export_csv
    - Includes all parameters and metrics
```

### Rust Engine Tests

```
Test Class: TestAglogenCore

Test Cases:
├── test_dla_simulation
│   - Generates expected particle count
│   - Returns valid metrics
│   - Rg evolution has correct length
│
├── test_cca_simulation
│   - Single agglomerate achieved
│   - Valid fractal dimension range
│
├── test_ballistic_simulation
│   - Higher Df than DLA
│
├── test_tunable_reaches_target
│   - Df within 10% of target
│   - kf within 20% of target
│
├── test_limiting_chain_df
│   - Linear chain has Df ≈ 1.0
│
├── test_limiting_plane_df
│   - Hexagonal plane has Df ≈ 2.0
│
├── test_sintering_affects_porosity
│   - Lower coefficient → lower porosity
│
├── test_deterministic_seed
│   - Same seed produces identical results
│
└── test_box_counting_3d
    - Valid dimension for sphere
    - High R² value
```

### Utility Tests

```
Test Class: TestUtils

Test Cases:
├── test_generate_simulation_name
│   - Includes algorithm name
│   - Includes formatted timestamp
│
├── test_generate_limiting_cases
│   - Boundary cases for min values
│   - Boundary cases for max values
│   - Theoretical extremes included
│
├── test_apply_sintering_config
│   - Fixed coefficient applied
│   - Uniform range respected
│   - Normal distribution clamped
│
└── test_sintering_extreme_cases
    - Returns 4 coefficient values
    - Values are [0.5, 0.75, 0.9, 1.0]
```

---

## 6.3 Rust Engine Tests

### Test Organization

```
aglogen_core/src/
├── common/
│   ├── geometry.rs     # Unit tests for Vector3, Sphere, AABB
│   ├── spatial.rs      # Unit tests for SpatialHash
│   └── rng.rs          # Unit tests for RNG determinism
├── simulation/
│   ├── dla.rs          # DLA algorithm tests
│   ├── cca.rs          # CCA algorithm tests
│   ├── tunable.rs      # Tunable algorithm tests
│   ├── metrics.rs      # Metrics computation tests
│   └── result.rs       # Result serialization tests
└── fractal/
    ├── box_counting.rs     # 2D box-counting tests
    └── box_counting_3d.rs  # 3D Morton code tests
```

### Test Examples (Pseudocode)

```
#[cfg(test)]
mod tests {
    // Geometry Tests
    test vector3_operations {
        v1 = Vector3::new(1.0, 2.0, 3.0)
        v2 = Vector3::new(4.0, 5.0, 6.0)

        assert_eq!(v1 + v2, Vector3::new(5.0, 7.0, 9.0))
        assert_approx_eq!(v1.length(), 3.7416...)
        assert_approx_eq!(v1.distance_to(v2), 5.196...)
    }

    test sphere_intersection {
        s1 = Sphere::new(origin, 1.0)
        s2 = Sphere::new(Vector3::new(1.5, 0.0, 0.0), 1.0)

        assert!(s1.intersects(&s2))  // Overlap
    }

    // Spatial Hash Tests
    test spatial_hash_query {
        hash = SpatialHash::new(2.0)
        hash.insert(Vector3::new(0.0, 0.0, 0.0), 0)
        hash.insert(Vector3::new(1.0, 0.0, 0.0), 1)
        hash.insert(Vector3::new(10.0, 0.0, 0.0), 2)

        neighbors = hash.query_neighbors(origin)

        assert!(neighbors.contains(0))
        assert!(neighbors.contains(1))
        assert!(!neighbors.contains(2))  // Too far
    }

    // Metrics Tests
    test radius_of_gyration_linear_chain {
        particles = [
            (Vector3::new(-2.0, 0.0, 0.0), 1.0),
            (Vector3::new(0.0, 0.0, 0.0), 1.0),
            (Vector3::new(2.0, 0.0, 0.0), 1.0),
        ]

        rg = compute_radius_of_gyration(&particles)

        // For 3 particles in line: Rg = sqrt(8/3) ≈ 1.633
        assert_approx_eq!(rg, 1.633, epsilon=0.01)
    }

    // Fractal Dimension Tests
    test linear_chain_fractal_dimension {
        result = run_dla_chain(100, seed=12345)

        assert!(result.fractal_dimension > 0.9)
        assert!(result.fractal_dimension < 1.1)
    }

    test tunable_reaches_target {
        target_df = 2.1
        result = run_tunable(500, target_df, 1.3, seed=12345)

        error = abs(result.fractal_dimension - target_df) / target_df
        assert!(error < 0.1)  // Within 10%
    }

    // Morton Code Tests
    test morton_encode_decode {
        x, y, z = 5, 10, 15
        code = morton_encode_3d(x, y, z)
        decoded = morton_decode_3d(code)

        assert_eq!(decoded, (x, y, z))
    }

    test box_counting_sphere {
        // Generate sphere of known dimension (Df = 3)
        points = generate_sphere_points(1000)
        result = box_counting_3d(&points, 15)

        assert!(result.dimension > 2.8)
        assert!(result.dimension < 3.2)
    }
}
```

---

## 6.4 Frontend Tests

### Test Organization

```
frontend/
├── __tests__/
│   ├── components/
│   │   ├── SimulationForm.test.tsx
│   │   ├── BatchSimulationForm.test.tsx
│   │   └── ViewerControls.test.tsx
│   ├── hooks/
│   │   ├── useSimulations.test.ts
│   │   └── useFraktalAnalyses.test.ts
│   └── lib/
│       ├── api.test.ts
│       └── utils.test.ts
└── jest.config.js
```

### Component Tests

```
Test File: SimulationForm.test.tsx

Test Cases:
├── renders all algorithm options
│   - All 7 algorithms in dropdown
│
├── shows DLA parameters when DLA selected
│   - n_particles, sticking_probability, lattice_size visible
│   - target_df NOT visible
│
├── shows tunable parameters when tunable selected
│   - target_df, target_kf visible
│
├── validates n_particles range
│   - Shows error for n_particles < 2
│   - Shows error for n_particles > 100000
│
├── submits valid form
│   - Calls onSubmit with correct data
│
└── handles sintering parameters
    - Shows sintering fields when enabled
    - Validates coefficient range

Test File: ViewerControls.test.tsx

Test Cases:
├── renders color mode selector
│   - All 5 color modes available
│
├── changes color mode on selection
│   - Calls store setter
│
├── toggles axes visibility
│   - Checkbox state matches store
│
├── slider updates opacity
│   - Value between 0 and 1
│
└── export button triggers export
    - Calls store export request
```

### Hook Tests

```
Test File: useSimulations.test.ts

Setup:
- QueryClientProvider wrapper
- Mock API responses

Test Cases:
├── fetches simulations on mount
│   - API called with projectId
│   - Data matches mock response
│
├── returns loading state initially
│   - isLoading true before data
│
├── polls when status is running
│   - refetchInterval set to 2000
│
├── stops polling when completed
│   - refetchInterval returns false
│
└── handles API errors
    - isError true on failure
    - error contains message
```

### API Client Tests

```
Test File: api.test.ts

Mock: fetch global

Test Cases:
├── projects.list returns paginated results
│   - Parses JSON correctly
│
├── simulations.create sends correct body
│   - POST method
│   - JSON content type
│
├── simulations.getGeometry parses npy
│   - Binary response handled
│   - Returns coordinates and radii
│
├── handles 400 validation errors
│   - Throws ApiError with details
│
├── handles 404 not found
│   - Throws ApiError with status
│
└── handles network errors
    - Throws with message
```

### Utility Tests

```
Test File: utils.test.ts

Test Cases:
├── cn merges class names
│   - Combines static and conditional
│
├── formatNumber handles precision
│   - Scientific notation for large
│   - Fixed decimals for small
│
└── parseNpyFile extracts data
    - Version 1.0 format
    - Version 2.0 format
    - Correct shape extraction
```

---

## 6.5 Running Tests

### Backend

```bash
# Run all tests with coverage
cd backend
pytest --cov=apps --cov-report=html

# Run specific test file
pytest tests/test_api.py

# Run specific test
pytest tests/test_api.py::TestSimulationAPI::test_create_simulation

# Run with verbose output
pytest -v

# Run only fast tests (skip slow integration)
pytest -m "not slow"

# Run tests matching pattern
pytest -k "simulation"
```

### Rust Engine

```bash
cd aglogen_core

# Run all tests
cargo test

# Run with output
cargo test -- --nocapture

# Run specific test
cargo test test_dla_simulation

# Run tests in release mode (faster)
cargo test --release
```

### Frontend

```bash
cd frontend

# Run all tests
npm test

# Run with coverage
npm test -- --coverage

# Run in watch mode
npm test -- --watch

# Run specific file
npm test -- SimulationForm.test.tsx
```

---

## 6.6 Continuous Integration

### GitHub Actions Workflow

```yaml
# .github/workflows/test.yml

name: Tests

on: [push, pull_request]

jobs:
  backend:
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:15
        env:
          POSTGRES_PASSWORD: test
        ports:
          - 5432:5432
      redis:
        image: redis:7
        ports:
          - 6379:6379

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'

      - name: Install Rust
        uses: dtolnay/rust-action@stable

      - name: Build aglogen_core
        run: |
          cd aglogen_core
          pip install maturin
          maturin build --release
          pip install target/wheels/*.whl

      - name: Install dependencies
        run: |
          cd backend
          pip install -e ".[dev]"

      - name: Run tests
        run: |
          cd backend
          pytest --cov=apps --cov-report=xml

      - name: Upload coverage
        uses: codecov/codecov-action@v3

  rust:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: dtolnay/rust-action@stable
      - name: Run tests
        run: |
          cd aglogen_core
          cargo test

  frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '18'
      - name: Install and test
        run: |
          cd frontend
          npm ci
          npm test -- --coverage
```

---

## 6.7 Test Data and Fixtures

### Factory Pattern

```
Using factory_boy for test data generation:

class ProjectFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Project

    name = factory.Faker('company')
    description = factory.Faker('paragraph')

class SimulationFactory(factory.django.DjangoModelFactory):
    class Meta:
        model = Simulation

    project = factory.SubFactory(ProjectFactory)
    name = factory.Faker('sentence', nb_words=4)
    algorithm = 'dla'
    parameters = factory.LazyAttribute(lambda _: {
        'n_particles': 100,
        'sticking_probability': 1.0,
        'lattice_size': 500
    })
    seed = factory.Faker('random_int', min=1, max=2**31)
    status = 'queued'

class CompletedSimulationFactory(SimulationFactory):
    status = 'completed'
    geometry = factory.LazyAttribute(generate_mock_geometry)
    metrics = factory.LazyAttribute(generate_mock_metrics)
```

### Mock Geometry Generation

```
def generate_mock_geometry(n_particles=100):
    """Generate mock geometry for testing."""
    coords = np.random.randn(n_particles, 3) * 10
    radii = np.ones(n_particles)
    data = np.column_stack([coords, radii])
    return numpy_to_binary(data)

def generate_mock_metrics():
    """Generate realistic mock metrics."""
    return {
        'fractal_dimension': 2.1 + np.random.normal(0, 0.1),
        'prefactor': 1.3 + np.random.normal(0, 0.1),
        'radius_of_gyration': 15.0 + np.random.normal(0, 2),
        'porosity': 0.78 + np.random.normal(0, 0.05),
        'coordination': {
            'mean': 2.4,
            'std': 1.2
        },
        'rg_evolution': list(np.cumsum(np.random.rand(100))),
        'anisotropy': 1.15,
        'asphericity': 0.08,
        'acylindricity': 0.03,
        'principal_moments': [100.5, 98.2, 95.1],
        'principal_axes': [[1,0,0], [0,1,0], [0,0,1]]
    }
```

---

## 6.8 Performance Testing

### Simulation Benchmarks

```
Benchmark Suite: simulation_benchmarks

Benchmarks:
├── dla_100_particles
│   - Baseline: 50ms
│   - Threshold: 100ms
│
├── dla_1000_particles
│   - Baseline: 500ms
│   - Threshold: 1000ms
│
├── tunable_500_particles
│   - Baseline: 200ms
│   - Threshold: 500ms
│
├── box_counting_3d_1000_points
│   - Baseline: 10ms
│   - Threshold: 50ms
│
└── fraktal_512x512_image
    - Baseline: 100ms
    - Threshold: 300ms
```

### Load Testing (API)

```
Tool: locust

Scenarios:
├── List projects (100 req/s)
├── Get simulation (200 req/s)
├── Create simulation (10 req/s)
└── Status polling (500 req/s)

Targets:
├── p50 latency < 50ms
├── p99 latency < 200ms
└── Error rate < 0.1%
```
