# Chapter 5: Integrations

This chapter documents the API endpoints, Celery task integration, and external service connections.

## 5.1 REST API Reference

### Base URL and Versioning

```
Base URL: /api/v1/
Content-Type: application/json
Authentication: None (local development)
```

### Projects API

#### List Projects
```
GET /api/v1/projects/

Response 200:
{
  "count": 5,
  "next": null,
  "previous": null,
  "results": [
    {
      "id": "uuid",
      "name": "Project Name",
      "description": "Description",
      "simulation_count": 10,
      "analysis_count": 3,
      "created_at": "2024-02-20T10:30:00Z",
      "updated_at": "2024-02-20T15:45:00Z"
    }
  ]
}
```

#### Create Project
```
POST /api/v1/projects/

Request:
{
  "name": "My Project",
  "description": "Optional description"
}

Response 201:
{
  "id": "uuid",
  "name": "My Project",
  ...
}
```

#### Get Project Detail
```
GET /api/v1/projects/{id}/

Response 200:
{
  "id": "uuid",
  "name": "Project Name",
  "description": "...",
  "simulation_count": 10,
  "analysis_count": 3,
  "recent_simulations": [...],
  "recent_analyses": [...],
  "created_at": "...",
  "updated_at": "..."
}
```

#### Update Project
```
PATCH /api/v1/projects/{id}/

Request:
{
  "name": "New Name"
}

Response 200: Updated project
```

#### Delete Project
```
DELETE /api/v1/projects/{id}/

Response 204: No Content
```

---

### Simulations API

#### List Simulations
```
GET /api/v1/projects/{project_id}/simulations/

Query Parameters:
  - status: Filter by status (queued, running, completed, failed, cancelled)
  - algorithm: Filter by algorithm
  - page: Pagination page number

Response 200:
{
  "count": 50,
  "next": "/api/v1/projects/{id}/simulations/?page=2",
  "results": [
    {
      "id": "uuid",
      "name": "DLA Simulation - 2024-02-20 10:30",
      "algorithm": "dla",
      "parameters": {...},
      "seed": 12345,
      "metrics": {...} | null,
      "status": "completed",
      "execution_time_ms": 1523,
      "created_at": "...",
      "completed_at": "...",
      "has_geometry": true
    }
  ]
}
```

#### Create Simulation
```
POST /api/v1/projects/{project_id}/simulations/

Request (DLA):
{
  "name": "My DLA Simulation",  // optional, auto-generated if empty
  "algorithm": "dla",
  "parameters": {
    "n_particles": 500,
    "sticking_probability": 1.0,
    "lattice_size": 500
  },
  "seed": 12345  // optional, random if not provided
}

Request (Tunable):
{
  "algorithm": "tunable",
  "parameters": {
    "n_particles": 500,
    "target_df": 2.1,
    "target_kf": 1.3,
    "sticking_probability": 1.0,
    "sintering_coefficient": 0.9,
    "sintering_distribution": "normal",
    "sintering_mean": 0.9,
    "sintering_std": 0.05
  }
}

Request (Limiting):
{
  "algorithm": "limiting",
  "parameters": {
    "n_particles": 100,
    "geometry_type": "chain",
    "configuration_type": "lineal",
    "particle_radius": 1.0
  }
}

Response 201:
{
  "id": "uuid",
  "status": "queued",
  ...
}
```

#### Get Simulation
```
GET /api/v1/projects/{project_id}/simulations/{id}/

Response 200: Full simulation object
```

#### Delete Simulation
```
DELETE /api/v1/projects/{project_id}/simulations/{id}/

Response 204: No Content
```

#### Cancel Simulation
```
POST /api/v1/projects/{project_id}/simulations/{id}/cancel/

Response 200:
{
  "status": "cancelled",
  "message": "Simulation cancelled successfully"
}

Response 400:
{
  "error": "Cannot cancel simulation with status: completed"
}
```

#### Get Geometry
```
GET /api/v1/projects/{project_id}/simulations/{id}/geometry/

Response 200:
Content-Type: application/octet-stream
Content-Disposition: attachment; filename="simulation_uuid.npy"

Body: NumPy binary file (N, 4) float64 array
```

#### Generate 2D Projection
```
POST /api/v1/projects/{project_id}/simulations/{id}/projection/

Request:
{
  "azimuth": 45,
  "elevation": 30,
  "format": "png",  // or "svg"
  "dpi": 150,
  "figsize": [8, 8]
}

Response 200:
Content-Type: image/png (or image/svg+xml)
Content-Disposition: attachment; filename="SimName_Az045_El030.png"

Body: Image binary
```

#### Batch Projections
```
POST /api/v1/projects/{project_id}/simulations/{id}/projection/batch/

Request:
{
  "azimuths": [0, 45, 90, 135, 180],
  "elevations": [0, 30, 60],
  "format": "png"
}

Response 200:
Content-Type: application/zip
Content-Disposition: attachment; filename="simulation_projections.zip"

Body: ZIP file containing multiple projection images
```

#### Export CSV
```
GET /api/v1/projects/{project_id}/simulations/{id}/export/

Response 200:
Content-Type: text/csv
Content-Disposition: attachment; filename="simulation_uuid.csv"

Body:
# Agglomerate Properties
Fractal Dimension,2.1
Prefactor,1.32
...

# Particles
Index,X,Y,Z,Radius,Coordination,Distance_From_COG
0,0.0,0.0,0.0,1.0,3,0.0
1,2.0,0.0,0.0,1.0,2,2.0
...
```

#### Get Neighbor Graph
```
GET /api/v1/projects/{project_id}/simulations/{id}/neighbor-graph/

Response 200:
{
  "nodes": [
    {
      "id": 0,
      "x": 0.0,
      "y": 0.0,
      "z": 0.0,
      "radius": 1.0,
      "coordination": 3,
      "distance_from_cog": 0.0
    }
  ],
  "edges": [
    {"source": 0, "target": 1},
    {"source": 0, "target": 2}
  ],
  "stats": {
    "total_edges": 150,
    "avg_coordination": 2.4,
    "max_coordination": 6,
    "min_coordination": 1,
    "is_connected": true
  }
}
```

#### Get 3D Box-Counting
```
GET /api/v1/projects/{project_id}/simulations/{id}/box-counting/

Query Parameters:
  - points_per_sphere: 100 (default)
  - precision: 15 (default)

Response 200:
{
  "dimension": 2.15,
  "r_squared": 0.998,
  "std_error": 0.02,
  "confidence_interval": [2.11, 2.19],
  "log_scales": [...],
  "log_counts": [...],
  "linear_region_start": 3,
  "residuals": [...]
}
```

---

### Parametric Studies API

#### List Studies
```
GET /api/v1/projects/{project_id}/studies/

Response 200:
{
  "results": [
    {
      "id": "uuid",
      "name": "Parameter Sweep",
      "base_algorithm": "tunable",
      "parameter_grid": {...},
      "total_simulations": 27,
      "completed_simulations": 15,
      "status": "running",
      "created_at": "..."
    }
  ]
}
```

#### Create Study
```
POST /api/v1/projects/{project_id}/studies/

Request:
{
  "name": "Df vs N Study",
  "base_algorithm": "tunable",
  "base_parameters": {
    "target_kf": 1.3,
    "sticking_probability": 1.0
  },
  "parameter_grid": {
    "n_particles": [500, 1000, 2000],
    "target_df": [1.8, 2.1, 2.5]
  },
  "seeds_per_combination": 3,
  "include_limiting_cases": true,
  "limiting_cases_config": {
    "include_boundaries": true,
    "include_theoretical": true
  },
  "sintering_config": {
    "distribution_type": "normal",
    "mean": 0.9,
    "std": 0.05
  },
  "include_box_counting": true,
  "box_counting_params": {
    "points_per_sphere": 100,
    "precision": 15
  }
}

Response 201:
{
  "id": "uuid",
  "total_simulations": 27,
  "status": "pending"
}
```

#### Get Study Results
```
GET /api/v1/projects/{project_id}/studies/{id}/results/

Response 200:
{
  "study_id": "uuid",
  "progress": {
    "total": 27,
    "completed": 25,
    "failed": 0,
    "running": 2,
    "queued": 0
  },
  "results": [
    {
      "simulation_id": "uuid",
      "name": "Tunable (Df=2.1, N=500)",
      "seed": 12345,
      "parameters": {
        "n_particles": 500,
        "target_df": 2.1
      },
      "metrics": {...},
      "status": "completed",
      "sintering_coefficient": 0.92,
      "box_counting": {...}
    }
  ]
}
```

#### Export Study CSV
```
GET /api/v1/projects/{project_id}/studies/{id}/export/

Response 200:
Content-Type: text/csv

Body:
simulation_id,name,seed,n_particles,target_df,fractal_dimension,prefactor,...
uuid1,Tunable...,12345,500,2.1,2.08,1.31,...
```

---

### FRAKTAL Analysis API

#### List Analyses
```
GET /api/v1/projects/{project_id}/fraktal/

Response 200:
{
  "results": [
    {
      "id": "uuid",
      "name": "FRAKTAL Analysis - 2024-02-20",
      "source_type": "uploaded_image",
      "model": "granulated_2012",
      "status": "completed",
      "results": {...},
      "created_at": "..."
    }
  ]
}
```

#### Create Analysis (Image Upload)
```
POST /api/v1/projects/{project_id}/fraktal/

Request:
{
  "name": "TEM Image Analysis",
  "source_type": "uploaded_image",
  "image": "base64_encoded_image_data",
  "filename": "sample.png",
  "content_type": "image/png",
  "model": "granulated_2012",
  "npix": 10.5,
  "dpo": 20.0,
  "delta": 1.0,
  "correction_3d": true,
  "pixel_min": 0,
  "pixel_max": 128,
  "auto_calibrate": false
}

Response 201:
{
  "id": "uuid",
  "status": "queued"
}
```

#### Create Analysis (Simulation Projection)
```
POST /api/v1/projects/{project_id}/fraktal/

Request:
{
  "source_type": "simulation_projection",
  "simulation_id": "simulation-uuid",
  "projection_params": {
    "azimuth": 45,
    "elevation": 30,
    "resolution": 512
  },
  "model": "granulated_2012",
  "npix": 10.5,
  "auto_calibrate": true
}

Response 201:
{
  "id": "uuid",
  "status": "queued"
}
```

#### Get Analysis
```
GET /api/v1/projects/{project_id}/fraktal/{id}/

Response 200:
{
  "id": "uuid",
  "status": "completed",
  "results": {
    "rg": 125.4,
    "ap": 45230.5,
    "df": 1.82,
    "npo": 245,
    "npo_visual": 238,
    "npo_ratio": 1.03,
    "npo_aligned": true,
    "kf": 1.35,
    "zf": 0.42,
    "jf": 2.15,
    ...
  }
}
```

#### Get Original Image
```
GET /api/v1/projects/{project_id}/fraktal/{id}/original_image/

Response 200:
Content-Type: image/png
Body: Image binary
```

#### Rerun Analysis
```
POST /api/v1/projects/{project_id}/fraktal/{id}/rerun/

Response 200:
{
  "id": "uuid",
  "status": "queued"
}
```

---

## 5.2 Celery Task Integration

### Task Configuration

```
# config/celery.py

Celery Configuration:
├── Broker: Redis (CELERY_BROKER_URL)
├── Result Backend: Redis (CELERY_RESULT_BACKEND)
├── Serializer: JSON
├── Task Serializer: JSON
├── Result Serializer: JSON
├── Accept Content: ['json']
└── Timezone: UTC
```

### Simulation Task

```
Task: run_simulation_task
Queue: default
Arguments: simulation_id (UUID string)

Workflow:
1. Load Simulation from database
2. Update status to RUNNING, save started_at
3. Determine algorithm handler
4. Execute algorithm via aglogen_core
5. Compute metrics (Df, kf, Rg, etc.)
6. Save geometry as binary NumPy
7. Save metrics as JSON
8. Update status to COMPLETED, save completed_at

Error Handling:
- On exception: status = FAILED, save error_message
- Task ID stored in simulation.task_id for cancellation

Fallback:
- If Celery broker unavailable, execute synchronously
```

### FRAKTAL Analysis Task

```
Task: run_fraktal_analysis_task
Queue: default
Arguments: analysis_id (UUID string)

Workflow:
1. Load FraktalAnalysis from database
2. Update status to RUNNING
3. Load image (from binary field or generate projection)
4. Execute FRAKTAL algorithm
5. If auto_calibrate: run calibration attempts
6. Save results JSON
7. Update status to COMPLETED

Special Handling:
- Source type "simulation_projection": generate projection first
- Auto-calibrate: try multiple dpo values
```

### Task Cancellation

```
Mechanism: Celery revoke with terminate=True

Endpoint: POST /simulations/{id}/cancel/

Process:
1. Check simulation.task_id exists
2. Check status is cancellable (queued, running)
3. Call AsyncResult(task_id).revoke(terminate=True)
4. Update status to CANCELLED
```

### Task Monitoring

```
Check Task Status:
from celery.result import AsyncResult

result = AsyncResult(task_id)
result.state  # PENDING, STARTED, SUCCESS, FAILURE
result.info   # Task return value or exception

List Active Tasks:
celery -A config inspect active
celery -A config inspect reserved
celery -A config inspect scheduled
```

---

## 5.3 Frontend API Client

### API Client Structure

```
Location: frontend/src/lib/api.ts

Structure:
api
├── projects
│   ├── list()
│   ├── get(id)
│   ├── create(data)
│   ├── update(id, data)
│   └── delete(id)
├── simulations
│   ├── list(projectId)
│   ├── get(projectId, id)
│   ├── create(projectId, data)
│   ├── delete(projectId, id)
│   ├── cancel(projectId, id)
│   ├── getProjection(projectId, id, params)
│   ├── getProjectionBatch(projectId, id, params)
│   ├── getGeometry(id)
│   ├── exportCsv(projectId, id)
│   ├── getNeighborGraph(projectId, id)
│   └── getBoxCounting(projectId, id, params)
├── parametricStudies
│   ├── list(projectId)
│   ├── get(projectId, id)
│   ├── create(projectId, data)
│   ├── delete(projectId, id)
│   ├── getResults(projectId, id)
│   └── exportCsv(projectId, id)
├── fraktalAnalyses
│   ├── list(projectId)
│   ├── get(projectId, id)
│   ├── create(projectId, data)
│   ├── delete(projectId, id)
│   ├── rerun(projectId, id)
│   └── getOriginalImage(projectId, id)
└── imageAnalyses
    ├── list(projectId)
    ├── get(projectId, id)
    ├── create(projectId, data)
    └── delete(projectId, id)
```

### Error Handling

```
class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public details?: Record<string, string[]>
  )
}

Usage:
try {
  await api.simulations.create(projectId, data)
} catch (error) {
  if (error instanceof ApiError) {
    if (error.status === 400) {
      // Validation error, show error.details
    } else if (error.status === 404) {
      // Not found
    }
  }
}
```

### NumPy Binary Parsing

```
Function: parseNpyFile(buffer: ArrayBuffer)

Process:
1. Read magic number: \x93NUMPY
2. Read version (1.0 or 2.0+)
3. Read header length (2 or 4 bytes)
4. Parse header dictionary (dtype, shape)
5. Extract float64 data
6. Reshape to coordinates and radii

Output:
{
  coordinates: [{x, y, z}, ...],
  radii: [r1, r2, ...]
}
```

---

## 5.4 React Query Integration

### Query Hooks

```
Hook: useSimulations(projectId)
Query Key: ['simulations', projectId]
Stale Time: 60 seconds
Refetch: On window focus

Hook: useSimulation(projectId, id)
Query Key: ['simulation', projectId, id]
Stale Time: 60 seconds
Refetch Interval: 2 seconds (if status is queued/running)

Hook: useSimulationGeometry(simId)
Query Key: ['geometry', simId]
Stale Time: Infinity (geometry doesn't change)
Enabled: Only when simulation.has_geometry is true

Hook: useNeighborGraph(projectId, simId)
Query Key: ['neighborGraph', projectId, simId]
Stale Time: Infinity
```

### Mutation Hooks

```
Hook: useCreateSimulation(projectId)
Mutation Function: api.simulations.create
On Success: Invalidate ['simulations', projectId]

Hook: useDeleteSimulation(projectId)
Mutation Function: api.simulations.delete
On Success: Invalidate ['simulations', projectId]

Hook: useCreateFraktalAnalysis(projectId)
Mutation Function: api.fraktalAnalyses.create
On Success: Invalidate ['fraktalAnalyses', projectId]
```

### Polling Pattern

```
Polling for Running Simulations:

useSimulation hook:
  refetchInterval: (data) => {
    if (!data) return false
    if (['queued', 'running'].includes(data.status)) {
      return 2000  // Poll every 2 seconds
    }
    return false  // Stop polling when completed
  }
```

---

## 5.5 PyO3/Rust Integration

### Module Interface

```
Python Import: import aglogen_core

Available Functions:
├── run_dla(n_particles, sticking_probability, ...) -> PySimulationResult
├── run_cca(n_particles, sticking_probability, ...) -> PySimulationResult
├── run_ballistic(n_particles, ...) -> PySimulationResult
├── run_ballistic_cc(n_particles, ...) -> PySimulationResult
├── run_tunable(n_particles, target_df, target_kf, ...) -> PySimulationResult
├── run_tunable_cc(n_particles, target_df, target_kf, ...) -> PySimulationResult
├── box_counting(binary_image, min_size, max_size, num_scales) -> PyFractalResult
├── box_counting_3d(points, precision) -> PyFractalResult
├── box_counting_agglomerate(coordinates, radii, precision) -> PyFractalResult
├── fraktal_granulated_2012(image, npix, dpo, ...) -> PyFraktalResult
├── fraktal_voxel_2018(image, npix, escala, ...) -> PyFraktalResult
├── project_to_2d(coordinates, radii, azimuth, elevation) -> Projection
└── project_batch(coordinates, radii, azimuths, elevations) -> List[Projection]
```

### Result Types

```
PySimulationResult:
├── coordinates: numpy.ndarray (N, 3) float64
├── radii: numpy.ndarray (N,) float64
├── fractal_dimension: float
├── fractal_dimension_std: float
├── prefactor: float
├── radius_of_gyration: float
├── porosity: float
├── coordination_mean: float
├── coordination_std: float
├── anisotropy: float
├── asphericity: float
├── acylindricity: float
├── principal_moments: List[float] (3)
├── principal_axes: List[List[float]] (3x3)
└── rg_evolution: List[float]

PyFraktalResult:
├── status: str
├── model: str
├── rg: float
├── ap: float
├── df: float
├── npo: float
├── npo_visual: float
├── kf: float
├── zf: float
├── jf: float (optional)
└── ...
```

### GIL Release

```
All heavy computations release the Python GIL:

py.allow_threads(|| {
    // Rust computation here
    // Python can execute other threads
})

Benefits:
- Multiple simulations can run in parallel
- Frontend can communicate with backend during simulation
- Celery workers remain responsive
```

---

## 5.6 Database Connection

### PostgreSQL Configuration

```
Development:
DATABASE_URL = postgres://user:pass@localhost:5432/pyaglogen3d

Production (Fly.io):
DATABASE_URL = postgres://user:pass@db.internal:5432/pyaglogen3d

Settings:
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': parsed.name,
        'USER': parsed.user,
        'PASSWORD': parsed.password,
        'HOST': parsed.host,
        'PORT': parsed.port or 5432,
        'CONN_MAX_AGE': 600,  # Connection pooling
    }
}
```

### Connection Pooling

```
Django CONN_MAX_AGE: 600 seconds
Persistent connections reused across requests

For high concurrency:
Consider pgBouncer in transaction pooling mode
```

---

## 5.7 Redis Configuration

### Development

```
REDIS_URL = redis://localhost:6379/0
CELERY_BROKER_URL = redis://localhost:6379/0
CELERY_RESULT_BACKEND = redis://localhost:6379/0
```

### Production (Upstash)

```
REDIS_URL = rediss://user:pass@host.upstash.io:6379
CELERY_BROKER_URL = rediss://user:pass@host.upstash.io:6379
CELERY_RESULT_BACKEND = rediss://user:pass@host.upstash.io:6379

Note: 'rediss' (with double s) for TLS connection
```

### Redis Usage

```
Purpose:
├── Celery task queue (broker)
├── Celery task results (result backend)
└── Optional: Cache layer

Key Patterns:
├── celery-task-meta-{task_id}: Task result
├── celery-{queue_name}: Task queue
└── _kombu.binding.{exchange}: Queue bindings
```

---

## 5.8 CORS Configuration

### Development

```
CORS_ALLOW_ALL_ORIGINS = True
CORS_ALLOW_CREDENTIALS = True
```

### Production

```
CORS_ALLOWED_ORIGINS = [
    "https://pyaglogen3d.herokuapp.com",
    "https://your-custom-domain.com"
]
CORS_ALLOW_CREDENTIALS = True
CORS_ALLOW_METHODS = [
    'DELETE', 'GET', 'OPTIONS', 'PATCH', 'POST', 'PUT'
]
CORS_ALLOW_HEADERS = [
    'accept', 'accept-encoding', 'authorization',
    'content-type', 'dnt', 'origin', 'user-agent',
    'x-csrftoken', 'x-requested-with'
]
```
