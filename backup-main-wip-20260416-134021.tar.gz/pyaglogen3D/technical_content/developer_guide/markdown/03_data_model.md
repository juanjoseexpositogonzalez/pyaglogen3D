# Chapter 3: Data Model

This chapter documents the data structures, database schema, and JSON formats used throughout PyAglogen3D.

## 3.1 Database Schema Overview

### Entity Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  ┌─────────────┐     1:N      ┌─────────────────┐                           │
│  │   Project   │──────────────│   Simulation    │                           │
│  │             │              │                 │                           │
│  │  id (UUID)  │              │  id (UUID)      │                           │
│  │  name       │              │  project (FK)   │                           │
│  │  description│              │  algorithm      │                           │
│  │  created_at │              │  parameters     │                           │
│  │  updated_at │              │  geometry       │                           │
│  │             │              │  metrics        │                           │
│  └─────────────┘              │  status         │                           │
│        │                      └─────────────────┘                           │
│        │                             ▲                                       │
│        │                             │ M:N                                   │
│        │                             │                                       │
│        │      1:N      ┌─────────────────────────┐                          │
│        │───────────────│   ParametricStudy       │                          │
│        │               │                         │                          │
│        │               │  id (UUID)              │                          │
│        │               │  project (FK)           │                          │
│        │               │  base_algorithm         │                          │
│        │               │  base_parameters        │                          │
│        │               │  parameter_grid         │                          │
│        │               │  simulations (M2M)      │                          │
│        │               │  include_limiting_cases │                          │
│        │               │  sintering_config       │                          │
│        │               └─────────────────────────┘                          │
│        │                                                                     │
│        │      1:N      ┌─────────────────────────┐                          │
│        │───────────────│   FraktalAnalysis       │                          │
│        │               │                         │                          │
│        │               │  id (UUID)              │                          │
│        │               │  project (FK)           │                          │
│        │               │  simulation (FK, null)  │◄── Optional link         │
│        │               │  source_type            │                          │
│        │               │  model                  │                          │
│        │               │  results                │                          │
│        │               │  status                 │                          │
│        │               └─────────────────────────┘                          │
│        │                                                                     │
│        │      1:N      ┌─────────────────────────┐                          │
│        └───────────────│   ComparisonSet         │                          │
│                        │                         │                          │
│                        │  id (UUID)              │                          │
│                        │  project (FK)           │                          │
│                        │  simulations (M2M)      │                          │
│                        │  analyses (M2M)         │                          │
│                        └─────────────────────────┘                          │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## 3.2 Model Definitions

### Project Model

**Purpose:** Container for organizing simulations and analyses into logical groups.

**Schema:**
```
Table: projects_project
├── id: UUID (Primary Key, auto-generated)
├── name: VARCHAR(255) NOT NULL
├── description: TEXT (nullable)
├── created_at: TIMESTAMP WITH TZ (auto)
└── updated_at: TIMESTAMP WITH TZ (auto)

Indexes:
├── PRIMARY KEY (id)
└── INDEX on (-updated_at)  -- For recent projects ordering

Computed Properties:
├── simulation_count: COUNT of related simulations
└── analysis_count: COUNT of related FraktalAnalysis
```

---

### Simulation Model

**Purpose:** Represents a single 3D agglomerate simulation with parameters, results, and geometry.

**Schema:**
```
Table: simulations_simulation
├── id: UUID (Primary Key)
├── project_id: UUID (Foreign Key → Project)
├── name: VARCHAR(255) NOT NULL
├── algorithm: VARCHAR(20) NOT NULL
│   └── CHOICES: dla, cca, ballistic, ballistic_cc, tunable, tunable_cc, limiting
├── parameters: JSONB NOT NULL
├── seed: BIGINT NOT NULL
├── geometry: BYTEA (nullable)  -- NumPy binary (N,4) array
├── metrics: JSONB (nullable)
├── status: VARCHAR(20) NOT NULL DEFAULT 'queued'
│   └── CHOICES: queued, running, completed, failed, cancelled
├── task_id: VARCHAR(255) (nullable)  -- Celery task ID
├── execution_time_ms: INTEGER (nullable)
├── error_message: TEXT (nullable)
├── created_at: TIMESTAMP WITH TZ
├── started_at: TIMESTAMP WITH TZ (nullable)
└── completed_at: TIMESTAMP WITH TZ (nullable)

Indexes:
├── PRIMARY KEY (id)
├── INDEX on (project_id, -created_at)
├── INDEX on (status)
└── INDEX on (algorithm)

Foreign Keys:
└── project_id → projects_project(id) ON DELETE CASCADE
```

**Parameters JSONField Structure:**

For DLA algorithm:
```json
{
  "n_particles": 500,
  "sticking_probability": 1.0,
  "lattice_size": 500,
  "seed_radius": 1.0,
  "radius_min": 1.0,
  "radius_max": 1.0,
  "sintering_coefficient": 1.0,
  "sintering_distribution": "fixed"
}
```

For Tunable algorithm:
```json
{
  "n_particles": 500,
  "target_df": 2.1,
  "target_kf": 1.3,
  "sticking_probability": 1.0,
  "radius_min": 1.0,
  "radius_max": 1.0,
  "sintering_coefficient": 0.9,
  "sintering_distribution": "normal",
  "sintering_mean": 0.9,
  "sintering_std": 0.05
}
```

For Limiting Case:
```json
{
  "n_particles": 100,
  "geometry_type": "chain",
  "configuration_type": "lineal",
  "particle_radius": 1.0,
  "layers": 5,
  "packing": "HC"
}
```

**Metrics JSONField Structure:**
```json
{
  "fractal_dimension": 2.1,
  "fractal_dimension_std": 0.02,
  "prefactor": 1.32,
  "radius_of_gyration": 15.234,
  "porosity": 0.78,
  "coordination": {
    "mean": 2.4,
    "std": 1.2
  },
  "rg_evolution": [1.0, 1.2, 1.5, 2.1, ...],
  "anisotropy": 1.15,
  "asphericity": 0.08,
  "acylindricity": 0.03,
  "principal_moments": [100.5, 98.2, 95.1],
  "principal_axes": [
    [0.98, 0.15, 0.08],
    [-0.14, 0.99, -0.05],
    [-0.09, 0.04, 0.99]
  ],
  "center_of_gravity": [0.12, -0.05, 0.23],
  "geometrical_center": [0.10, -0.03, 0.20]
}
```

**Geometry Binary Format:**
```
NumPy .npy format (version 1.0 or 2.0)
├── Magic number: \x93NUMPY
├── Version: 1 byte major, 1 byte minor
├── Header length: 2 bytes (v1) or 4 bytes (v2+)
├── Header: Python dict string
│   └── {'descr': '<f8', 'fortran_order': False, 'shape': (N, 4)}
└── Data: N*4 float64 values
    └── Each row: [x, y, z, radius]
```

---

### ParametricStudy Model

**Purpose:** Batch simulation with parameter grid exploration and optional limiting cases.

**Schema:**
```
Table: simulations_parametricstudy
├── id: UUID (Primary Key)
├── project_id: UUID (Foreign Key → Project)
├── name: VARCHAR(255) NOT NULL
├── description: TEXT (nullable)
├── base_algorithm: VARCHAR(20) NOT NULL
├── base_parameters: JSONB NOT NULL
├── parameter_grid: JSONB NOT NULL
├── seeds_per_combination: INTEGER DEFAULT 1
├── simulations: M2M → Simulation (through table)
├── include_limiting_cases: BOOLEAN DEFAULT false
├── limiting_cases_config: JSONB (nullable)
├── sintering_config: JSONB (nullable)
├── include_box_counting: BOOLEAN DEFAULT false
├── box_counting_params: JSONB (nullable)
├── status: VARCHAR(20) DEFAULT 'pending'
├── created_at: TIMESTAMP WITH TZ
└── updated_at: TIMESTAMP WITH TZ

Indexes:
├── PRIMARY KEY (id)
└── INDEX on (project_id, -created_at)
```

**parameter_grid Example:**
```json
{
  "n_particles": [500, 1000, 2000],
  "target_df": [1.8, 2.1, 2.5],
  "sticking_probability": [0.5, 0.75, 1.0]
}
```
This generates 3 × 3 × 3 = 27 combinations.

**limiting_cases_config Example:**
```json
{
  "include_boundaries": true,
  "include_theoretical": true,
  "theoretical_overrides": {
    "target_df": [1.0, 1.5, 2.0, 3.0]
  }
}
```

**sintering_config Example:**
```json
{
  "distribution_type": "normal",
  "mean": 0.9,
  "std": 0.05
}
```
Or for uniform:
```json
{
  "distribution_type": "uniform",
  "min": 0.85,
  "max": 0.95
}
```

**box_counting_params Example:**
```json
{
  "points_per_sphere": 100,
  "precision": 15
}
```

---

### FraktalAnalysis Model

**Purpose:** FRAKTAL fractal analysis on 2D images (uploaded or from simulation projection).

**Schema:**
```
Table: fractal_analysis_fraktalanalysis
├── id: UUID (Primary Key)
├── project_id: UUID (Foreign Key → Project)
├── name: VARCHAR(255) NOT NULL
├── source_type: VARCHAR(30) NOT NULL
│   └── CHOICES: uploaded_image, simulation_projection
├── simulation_id: UUID (Foreign Key → Simulation, nullable)
├── projection_params: JSONB (nullable)
├── original_image: BYTEA (nullable)
├── original_filename: VARCHAR(255) (nullable)
├── original_content_type: VARCHAR(50) (nullable)
├── processed_image: BYTEA (nullable)
├── model: VARCHAR(30) NOT NULL
│   └── CHOICES: granulated_2012, voxel_2018
├── npix: FLOAT NOT NULL  -- pixels per 100nm
├── dpo: FLOAT (nullable)  -- primary particle diameter (nm)
├── delta: FLOAT DEFAULT 1.0  -- filling factor
├── correction_3d: BOOLEAN DEFAULT true
├── pixel_min: INTEGER DEFAULT 0
├── pixel_max: INTEGER DEFAULT 255
├── npo_limit: INTEGER DEFAULT 0
├── escala: FLOAT DEFAULT 1.0
├── m_exponent: FLOAT DEFAULT 0.35
├── auto_calibrate: BOOLEAN DEFAULT false
├── results: JSONB (nullable)
├── status: VARCHAR(20) DEFAULT 'queued'
├── execution_time_ms: INTEGER (nullable)
├── engine_version: VARCHAR(50) (nullable)
├── error_message: TEXT (nullable)
├── created_at: TIMESTAMP WITH TZ
├── started_at: TIMESTAMP WITH TZ (nullable)
└── completed_at: TIMESTAMP WITH TZ (nullable)

Indexes:
├── PRIMARY KEY (id)
├── INDEX on (project_id, -created_at)
├── INDEX on (status)
├── INDEX on (model)
└── INDEX on (source_type)
```

**projection_params Example:**
```json
{
  "azimuth": 45,
  "elevation": 30,
  "resolution": 512
}
```

**results Example (granulated_2012):**
```json
{
  "status": "success",
  "model": "granulated_2012",
  "rg": 125.4,
  "ap": 45230.5,
  "df": 1.82,
  "npo": 245,
  "npo_visual": 238,
  "npo_ratio": 1.03,
  "npo_aligned": true,
  "kf": 1.35,
  "zf": 0.42,
  "jf": 2.15,
  "dpo_estimated": 18.5,
  "volume": 1234567.8,
  "mass": 0.0234,
  "surface_area": 98765.4,
  "calibration_attempts": [
    {"dpo": 20.0, "npo": 312, "npo_visual": 238, "ratio": 1.31},
    {"dpo": 14.0, "npo": 198, "npo_visual": 238, "ratio": 0.83},
    {"dpo": 18.5, "npo": 245, "npo_visual": 238, "ratio": 1.03}
  ],
  "best_dpo": 18.5
}
```

---

### ImageAnalysis Model (2D Box-Counting)

**Purpose:** Standard 2D fractal analysis methods on images.

**Schema:**
```
Table: fractal_analysis_imageanalysis
├── id: UUID (Primary Key)
├── project_id: UUID (Foreign Key → Project)
├── name: VARCHAR(255) NOT NULL
├── method: VARCHAR(30) NOT NULL
│   └── CHOICES: box_counting, sandbox, correlation, lacunarity, multifractal
├── image: BYTEA NOT NULL
├── filename: VARCHAR(255) NOT NULL
├── content_type: VARCHAR(50) NOT NULL
├── parameters: JSONB NOT NULL
├── results: JSONB (nullable)
├── status: VARCHAR(20) DEFAULT 'queued'
├── error_message: TEXT (nullable)
├── created_at: TIMESTAMP WITH TZ
└── completed_at: TIMESTAMP WITH TZ (nullable)

Indexes:
├── PRIMARY KEY (id)
├── INDEX on (project_id, -created_at)
├── INDEX on (status)
└── INDEX on (method)
```

---

### ComparisonSet Model

**Purpose:** Group simulations and analyses for comparison.

**Schema:**
```
Table: fractal_analysis_comparisonset
├── id: UUID (Primary Key)
├── project_id: UUID (Foreign Key → Project)
├── name: VARCHAR(255) NOT NULL
├── description: TEXT (nullable)
├── simulations: M2M → Simulation
├── analyses: M2M → FraktalAnalysis
├── created_at: TIMESTAMP WITH TZ
└── updated_at: TIMESTAMP WITH TZ

Indexes:
├── PRIMARY KEY (id)
└── INDEX on (project_id, -created_at)
```

## 3.3 TypeScript Type Definitions

### Core Types

```typescript
// Enumerations
type SimulationAlgorithm =
  | 'dla'
  | 'cca'
  | 'ballistic'
  | 'ballistic_cc'
  | 'tunable'
  | 'tunable_cc'
  | 'limiting'

type SimulationStatus =
  | 'queued'
  | 'running'
  | 'completed'
  | 'failed'
  | 'cancelled'

type FraktalModel = 'granulated_2012' | 'voxel_2018'

type FraktalSourceType = 'uploaded_image' | 'simulation_projection'

type ColorMode =
  | 'uniform'      // Solid color
  | 'order'        // Deposition order gradient
  | 'coordination' // Coordination number
  | 'distance'     // Distance from center
  | 'depth'        // Z-position (front/back)

type SinteringDistributionType = 'fixed' | 'uniform' | 'normal'

type LimitingGeometryType = 'chain' | 'plane' | 'sphere'

type ChainConfig = 'lineal' | 'cruz2d' | 'asterisco' | 'cruz3d'
type PlaneConfig = 'plano' | 'dobleplano' | 'tripleplano'
type SphereConfig = 'cuboctaedro'
type PackingType = 'HC' | 'CS' | 'CCC'
```

### Project Types

```typescript
interface Project {
  id: string
  name: string
  description: string | null
  simulation_count: number
  analysis_count: number
  created_at: string  // ISO 8601
  updated_at: string
}

interface ProjectDetail extends Project {
  recent_simulations: SimulationSummary[]
  recent_analyses: AnalysisSummary[]
}

interface CreateProjectInput {
  name: string
  description?: string
}
```

### Simulation Types

```typescript
interface Simulation {
  id: string
  project: string
  name: string
  algorithm: SimulationAlgorithm
  parameters: SimulationParameters
  seed: number
  metrics: SimulationMetrics | null
  status: SimulationStatus
  task_id: string | null
  execution_time_ms: number | null
  error_message: string | null
  created_at: string
  started_at: string | null
  completed_at: string | null
  has_geometry: boolean
}

interface SimulationMetrics {
  fractal_dimension: number
  fractal_dimension_std: number
  prefactor: number
  radius_of_gyration: number
  porosity: number
  coordination: {
    mean: number
    std: number
  }
  rg_evolution: number[]
  anisotropy: number
  asphericity: number
  acylindricity: number
  principal_moments: [number, number, number]
  principal_axes: [
    [number, number, number],
    [number, number, number],
    [number, number, number]
  ]
  center_of_gravity?: [number, number, number]
  geometrical_center?: [number, number, number]
}

// Algorithm-specific parameter types
interface DlaParams {
  n_particles: number
  sticking_probability: number
  lattice_size: number
  seed_radius?: number
  radius_min?: number
  radius_max?: number
  sintering_coefficient?: number
  sintering_distribution?: SinteringDistributionType
  sintering_mean?: number
  sintering_std?: number
  sintering_min?: number
  sintering_max?: number
}

interface TunableParams {
  n_particles: number
  target_df: number
  target_kf: number
  sticking_probability?: number
  radius_min?: number
  radius_max?: number
  sintering_coefficient?: number
  sintering_distribution?: SinteringDistributionType
  sintering_mean?: number
  sintering_std?: number
}

interface LimitingParams {
  n_particles: number
  geometry_type: LimitingGeometryType
  configuration_type: ChainConfig | PlaneConfig | SphereConfig
  particle_radius?: number
  layers?: number
  packing?: PackingType
  n_branches?: number
  complete_rings?: boolean
}

type SimulationParameters =
  | DlaParams
  | TunableParams
  | LimitingParams
  | Record<string, unknown>
```

### Geometry Types

```typescript
interface GeometryData {
  coordinates: Array<{ x: number; y: number; z: number }>
  radii: number[]
}

interface NeighborGraphData {
  nodes: Array<{
    id: number
    x: number
    y: number
    z: number
    radius: number
    coordination: number
    distance_from_cog: number
  }>
  edges: Array<{
    source: number
    target: number
  }>
  stats: {
    total_edges: number
    avg_coordination: number
    max_coordination: number
    min_coordination: number
    is_connected: boolean
  }
}

interface BoxCounting3DResult {
  dimension: number
  r_squared: number
  std_error: number
  confidence_interval: [number, number]
  log_scales: number[]
  log_counts: number[]
  linear_region_start: number
  residuals: number[]
}
```

### FRAKTAL Types

```typescript
interface FraktalAnalysis {
  id: string
  project: string
  name: string
  source_type: FraktalSourceType
  original_filename: string | null
  original_content_type: string | null
  simulation_id: string | null
  projection_params: ProjectionParams | null
  model: FraktalModel
  npix: number
  dpo: number | null
  delta: number
  correction_3d: boolean
  pixel_min: number
  pixel_max: number
  npo_limit: number
  escala: number
  m_exponent: number
  auto_calibrate: boolean
  results: FraktalResults | null
  status: AnalysisStatus
  execution_time_ms: number | null
  engine_version: string | null
  error_message: string | null
  created_at: string
  started_at: string | null
  completed_at: string | null
}

interface FraktalResults {
  status: string
  model: string
  rg: number              // Radius of gyration (nm)
  ap: number              // Projected area (nm²)
  df: number              // Fractal dimension
  npo: number             // Calculated particle count
  npo_visual: number      // Visual estimate
  npo_ratio: number       // npo / npo_visual
  npo_aligned: boolean    // Within 2x tolerance
  kf: number              // Prefactor
  zf: number              // Overlap exponent
  jf: number | null       // Coordination index (2012 only)
  dpo_estimated: number   // Estimated primary particle diameter
  volume: number          // Volume (nm³)
  mass: number            // Mass (fg)
  surface_area: number    // Surface area (nm²)
  calibration_attempts?: CalibrationAttempt[]
  best_dpo?: number
}

interface CalibrationAttempt {
  dpo: number
  npo: number
  npo_visual: number
  ratio: number
}

interface ProjectionParams {
  azimuth: number
  elevation: number
  resolution?: number
}
```

### Parametric Study Types

```typescript
interface ParametricStudy {
  id: string
  project: string
  name: string
  description: string | null
  base_algorithm: SimulationAlgorithm
  base_parameters: Record<string, unknown>
  parameter_grid: Record<string, unknown[]>
  seeds_per_combination: number
  include_limiting_cases: boolean
  limiting_cases_config: LimitingCasesConfig | null
  sintering_config: SinteringConfig | null
  include_box_counting: boolean
  box_counting_params: BoxCountingParams | null
  status: string
  total_simulations: number
  completed_simulations: number
  created_at: string
}

interface LimitingCasesConfig {
  include_boundaries?: boolean
  include_theoretical?: boolean
  theoretical_overrides?: Record<string, unknown[]>
}

interface SinteringConfig {
  distribution_type: SinteringDistributionType
  coefficient?: number  // For 'fixed'
  min?: number          // For 'uniform'
  max?: number          // For 'uniform'
  mean?: number         // For 'normal'
  std?: number          // For 'normal'
}

interface BoxCountingParams {
  points_per_sphere: number  // 10-1000
  precision: number          // 8-21 bits
}

interface ParametricStudyResults {
  study_id: string
  progress: {
    total: number
    completed: number
    failed: number
    running: number
    queued: number
  }
  results: SimulationResult[]
}

interface SimulationResult {
  simulation_id: string
  name: string
  seed: number
  parameters: Record<string, unknown>
  metrics: SimulationMetrics | null
  status: SimulationStatus
  sintering_coefficient?: number
  box_counting?: BoxCounting3DResult
}
```

## 3.4 Data Validation Rules

### Simulation Parameters

| Parameter | Type | Range | Required |
|-----------|------|-------|----------|
| n_particles | integer | 2 - 100,000 | Yes |
| target_df | float | 1.0 - 3.0 | For tunable |
| target_kf | float | 0.5 - 3.0 | For tunable |
| sticking_probability | float | 0.0 - 1.0 | Yes |
| lattice_size | integer | 100 - 10,000 | For DLA |
| radius_min | float | 0.1 - 100.0 | Optional |
| radius_max | float | radius_min - 100.0 | Optional |
| sintering_coefficient | float | 0.5 - 1.0 | Optional |
| sintering_std | float | 0.0 - 0.2 | For normal |

### FRAKTAL Parameters

| Parameter | Type | Range | Required |
|-----------|------|-------|----------|
| npix | float | 0.1 - 1000.0 | Yes |
| dpo | float | 1.0 - 500.0 | If not auto_calibrate |
| delta | float | 1.0 - 2.0 | Optional |
| pixel_min | integer | 0 - 254 | Optional |
| pixel_max | integer | pixel_min+1 - 255 | Optional |
| m_exponent | float | 0.1 - 1.0 | For voxel_2018 |

### Parametric Study Validation

| Field | Validation |
|-------|------------|
| parameter_grid | At least one parameter with 2+ values |
| seeds_per_combination | 1 - 100 |
| sintering_config.coefficient | 0.5 - 1.0 |
| sintering_config.std | 0.0 - 0.2 |
| box_counting_params.points_per_sphere | 10 - 1000 |
| box_counting_params.precision | 8 - 21 |

## 3.5 Indexes and Query Optimization

### Primary Query Patterns

```
# List simulations for project (most common)
SELECT * FROM simulations_simulation
WHERE project_id = ?
ORDER BY created_at DESC
LIMIT 20

Index: (project_id, -created_at)

# Find running simulations (for monitoring)
SELECT * FROM simulations_simulation
WHERE status IN ('queued', 'running')

Index: (status)

# Get study with simulations
SELECT s.*, sim.*
FROM simulations_parametricstudy s
JOIN simulations_parametricstudy_simulations m ON s.id = m.parametricstudy_id
JOIN simulations_simulation sim ON m.simulation_id = sim.id
WHERE s.id = ?

Use: prefetch_related('simulations')
```

### Database Recommendations

1. **Connection Pooling**: Use pgBouncer or Django's CONN_MAX_AGE
2. **Binary Field Size**: Monitor geometry field sizes; consider S3 for >1MB
3. **JSONField Indexing**: Create GIN indexes on frequently queried JSON keys
4. **Vacuum Strategy**: Schedule regular VACUUM ANALYZE on simulation tables
