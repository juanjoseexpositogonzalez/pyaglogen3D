# Chapter 4: Algorithms

This chapter describes the simulation and analysis algorithms implemented in PyAglogen3D, including pseudocode and mathematical foundations.

## 4.1 Aggregation Algorithms Overview

PyAglogen3D implements seven aggregation algorithms, each producing agglomerates with different morphological properties:

| Algorithm | Df Range | Structure Type | Use Case |
|-----------|----------|----------------|----------|
| DLA | 2.4-2.6 | Open, dendritic | Diffusion-dominated growth |
| CCA | 1.8-2.0 | Hierarchical | Cluster-cluster collisions |
| Ballistic PC | 2.8-3.0 | Compact, dense | High-speed deposition |
| Ballistic CC | 1.8-2.1 | Mixed | Cluster-cluster ballistic |
| Tunable PC | 1.4-3.0 | Controlled | Target morphology research |
| Tunable CC | 1.4-3.0 | Controlled | Cluster-based controlled |
| Limiting | 1.0, 2.0, 3.0 | Reference | Validation geometries |

## 4.2 DLA (Diffusion-Limited Aggregation)

### Algorithm Description

DLA simulates particle growth where new particles undergo random walks until they contact the existing cluster.

### Pseudocode

```
ALGORITHM DLA_Simulation
INPUT:
    n_particles: number of particles to generate
    sticking_probability: probability of adhesion on contact
    radius_range: (min, max) particle radii
    sintering_config: sintering model parameters
    seed: random seed for reproducibility

OUTPUT:
    particles: list of (position, radius) tuples
    rg_evolution: Rg after each particle addition

PROCEDURE:
    rng = initialize_rng(seed)
    spatial_hash = new SpatialHash(cell_size = 4 * radius_max)

    # Seed particle at origin
    particles = [(origin, random_radius(radius_range))]
    spatial_hash.insert(origin, 0)

    WHILE particles.length < n_particles:
        radius = random_radius(radius_range)

        # Launch from sphere around cluster
        Rg = compute_radius_of_gyration(particles)
        launch_distance = 2.0 * Rg + 5.0 * radius_max
        launch_point = random_point_on_sphere() * launch_distance

        position = launch_point
        kill_distance = 3.0 * launch_distance

        # Random walk
        WHILE true:
            # Check for collision
            neighbors = spatial_hash.query_neighbors(position)

            FOR each neighbor_idx in neighbors:
                neighbor = particles[neighbor_idx]
                sintering_coeff = get_sintering_coefficient(sintering_config)
                contact_distance = sintering_coeff * (radius + neighbor.radius)

                IF distance(position, neighbor.position) <= contact_distance:
                    IF random() < sticking_probability:
                        particles.append((position, radius))
                        spatial_hash.insert(position, particles.length - 1)
                        GOTO next_particle
                    ELSE:
                        # Bounce: reflect direction
                        position = reflect(position, neighbor.position)

            # Move by random walk
            step_size = 0.5 * radius
            direction = random_point_on_sphere()
            position = position + direction * step_size

            # Kill if too far
            IF distance(position, origin) > kill_distance:
                BREAK  # Restart with new particle

        next_particle:
        rg_evolution.append(compute_radius_of_gyration(particles))

    RETURN particles, rg_evolution
```

### Key Parameters

| Parameter | Description | Typical Value |
|-----------|-------------|---------------|
| n_particles | Total particles | 100 - 10,000 |
| sticking_probability | Adhesion probability | 0.5 - 1.0 |
| lattice_size | Simulation domain | 500 - 5,000 |
| sintering_coefficient | Contact overlap | 0.9 - 1.0 |

### Complexity Analysis

- **Time**: O(N^2 x W) where W is average walk steps
- **Space**: O(N) for particle storage + O(N/k^3) for spatial hash

---

## 4.3 CCA (Cluster-Cluster Aggregation)

### Algorithm Description

CCA starts with N individual particles as separate clusters. Clusters undergo Brownian motion with mobility inversely proportional to their size. When clusters collide, they merge.

### Pseudocode

```
ALGORITHM CCA_Simulation
INPUT:
    n_particles: number of particles
    sticking_probability: adhesion probability
    box_size: periodic boundary box
    sintering_config: sintering model
    seed: random seed

OUTPUT:
    particles: final agglomerate
    rg_evolution: Rg over cluster merges

PROCEDURE:
    rng = initialize_rng(seed)
    radius = uniform_radius()

    # Initialize: each particle is its own cluster
    clusters = []
    FOR i in 0..n_particles:
        position = random_position_in_box(box_size)
        clusters.append({
            particles: [(position, radius)],
            center_of_mass: position,
            Rg: radius
        })

    max_iterations = n_particles * 1000

    FOR iteration in 0..max_iterations:
        IF clusters.length == 1:
            BREAK  # Single agglomerate achieved

        FOR each cluster in clusters:
            # Mobility inversely proportional to size
            mobility = 1.0 / (1.0 + sqrt(cluster.Rg))
            step_size = mobility * base_step_size

            # Brownian motion
            direction = random_point_on_sphere()
            displacement = direction * step_size

            # Move all particles in cluster
            FOR each particle in cluster.particles:
                particle.position += displacement

            # Periodic boundary conditions (wrap)
            cluster.center_of_mass = wrap_to_box(cluster.center_of_mass, box_size)

        # Check for collisions between clusters
        FOR i in 0..clusters.length:
            FOR j in i+1..clusters.length:
                IF clusters_collide(clusters[i], clusters[j], sintering_config):
                    IF random() < sticking_probability:
                        # Merge clusters
                        merged = merge_clusters(clusters[i], clusters[j])
                        clusters.remove(clusters[j])
                        clusters.remove(clusters[i])
                        clusters.append(merged)
                        rg_evolution.append(merged.Rg)
                        BREAK outer loop  # Restart collision check

    RETURN clusters[0].particles, rg_evolution

FUNCTION clusters_collide(c1, c2, sintering_config):
    FOR p1 in c1.particles:
        FOR p2 in c2.particles:
            dist = periodic_distance(p1.position, p2.position, box_size)
            contact = sintering_config.coefficient * (p1.radius + p2.radius)
            IF dist <= contact:
                RETURN true
    RETURN false

FUNCTION periodic_distance(p1, p2, box_size):
    delta = abs(p1 - p2)
    delta = min(delta, box_size - delta)  # Minimum image convention
    RETURN length(delta)
```

### Key Parameters

| Parameter | Description | Typical Value |
|-----------|-------------|---------------|
| n_particles | Initial monomers | 100 - 5,000 |
| box_size | Periodic domain | Auto-calculated |
| sticking_probability | Merge probability | 0.8 - 1.0 |

### Box Size Calculation

```
particle_volume = (4/3) * pi * radius^3
total_volume = n_particles * particle_volume
target_volume_fraction = 0.03  # 3%
box_volume = total_volume / target_volume_fraction
box_size = cbrt(box_volume)
```

---

## 4.4 Ballistic Aggregation

### Algorithm Description

Ballistic aggregation launches particles along straight-line trajectories toward the cluster center. This produces more compact structures than DLA.

### Pseudocode

```
ALGORITHM Ballistic_Simulation
INPUT:
    n_particles: number of particles
    sticking_probability: adhesion probability
    radius_range: particle size range
    sintering_config: sintering parameters
    seed: random seed

OUTPUT:
    particles: agglomerate particles
    rg_evolution: Rg evolution

PROCEDURE:
    rng = initialize_rng(seed)
    spatial_hash = new SpatialHash(cell_size = 4 * radius_max)

    # Seed particle
    particles = [(origin, random_radius(radius_range))]
    spatial_hash.insert(origin, 0)

    WHILE particles.length < n_particles:
        radius = random_radius(radius_range)

        Rg = compute_radius_of_gyration(particles)
        launch_distance = 2.0 * Rg + 5.0 * radius_max

        # Random launch point on sphere
        launch_direction = random_point_on_sphere()
        position = launch_direction * launch_distance

        # Direction toward cluster center (with small deviation)
        center = compute_center_of_mass(particles)
        base_direction = normalize(center - position)

        # Add +/-10% angular deviation
        deviation = random_in_range(-0.1, 0.1)
        direction = rotate_direction(base_direction, deviation)

        # Ray march toward cluster
        step_size = 0.5 * radius
        max_steps = (launch_distance * 3) / step_size

        FOR step in 0..max_steps:
            neighbors = spatial_hash.query_neighbors(position)

            FOR neighbor_idx in neighbors:
                neighbor = particles[neighbor_idx]
                sintering_coeff = get_sintering_coefficient(sintering_config)
                contact_distance = sintering_coeff * (radius + neighbor.radius)

                IF distance(position, neighbor.position) <= contact_distance:
                    IF random() < sticking_probability:
                        particles.append((position, radius))
                        spatial_hash.insert(position, particles.length - 1)
                        rg_evolution.append(compute_Rg(particles))
                        GOTO next_particle

            position = position + direction * step_size

        next_particle:

    RETURN particles, rg_evolution
```

### Ballistic CC Variant

The cluster-cluster variant (Ballistic CC) operates similarly to CCA but uses ballistic trajectories instead of Brownian motion:

```
ALGORITHM Ballistic_CC_Simulation
PROCEDURE:
    clusters = initialize_monomer_clusters(n_particles)

    WHILE clusters.length > 1:
        # Select impacted and impactor clusters
        i, j = select_two_random_clusters(clusters)
        impacted = clusters[i]
        impactor = clusters[j]

        # Move impactor ballistically toward impacted
        direction = normalize(impacted.center - impactor.center)
        step_size = 0.5 * min_radius

        WHILE not clusters_touch(impacted, impactor):
            move_cluster(impactor, direction * step_size)

        # Merge
        merged = merge_clusters(impacted, impactor)
        clusters.remove(impacted, impactor)
        clusters.append(merged)

    RETURN clusters[0].particles
```

---

## 4.5 Tunable Algorithm (Filippov/Lapuerta Method)

### Algorithm Description

The tunable algorithm allows precise control of the fractal dimension by calculating where to place each new particle to maintain the power law relationship: N = kf x (Rg/rp)^Df

### Mathematical Foundation

**Power Law:**
```
N = kf x (Rg/rp)^Df

where:
- N = number of particles
- kf = prefactor (typically 1.0-2.0)
- Rg = radius of gyration
- rp = particle radius
- Df = fractal dimension
```

**Target Distance Calculation (Gamma):**

For particle N+1, calculate the target distance from center of mass:

```
gamma1 = (N^2 / (N-1)) * [(N/kf)^(2/Df) - constante]
gamma2 = N * [(N-1)/kf]^(2/Df)
gamma3 = (N / (N-1)) * [(1/kf)^(2/Df) - constante]

gamma_sq = gamma1 - gamma2 - gamma3
gamma = rp * sqrt(gamma_sq)
```

The constant (`constante = 3/5` for Lapuerta method, `0` for pure Filippov) accounts for particle internal structure contribution to moment of inertia.

### LA- and LA+ Sets

The algorithm uses two key particle sets:

**LA- (candidate particles):** Particles that could be in contact when a new particle is placed at distance gamma from CoM. A particle i is in LA- if:
```
distance_from_com[i] > gamma - 2*rp
```

**LA+ (potential collision particles):** Particles in LA- that could cause overlap when placing near a reference particle. A particle i is in LA+ if:
```
distance(particle[i], reference_particle) < 2 * overlap_threshold
```

### Detailed Pseudocode

```
ALGORITHM Tunable_Simulation
INPUT:
    n_particles: number of particles
    target_df: target fractal dimension (1.0-3.0)
    target_kf: target prefactor (typically 1.0-2.0)
    radius_range: particle radii (min, max)
    max_rotations: rotation attempts per reference (default: 25)
    sintering_config: sintering parameters
    seed: random seed

OUTPUT:
    particles: agglomerate with target morphology
    rg_evolution: Rg evolution

CONSTANTS:
    LAPUERTA_CONSTANT = 3/5  # Internal particle contribution

PROCEDURE:
    rng = initialize_rng(seed)
    rp = mean_radius(radius_range)

    # Initialize with 2 touching particles (with sintering)
    r1 = random_radius(radius_range)
    r2 = random_radius(radius_range)
    sintering_coeff_2 = sample_sintering(sintering_config, rng)
    contact_dist_2 = sintering_coeff_2 * (r1 + r2)

    particles = [
        Sphere(origin, r1),
        Sphere((contact_dist_2, 0, 0), r2)
    ]

    # Track Rg evolution
    rg_evolution = []
    n_values = []

    # Calculate initial center of mass and recenter
    center_of_mass = calculate_center_of_mass(particles)
    FOR p in particles:
        p.center = p.center - center_of_mass
    center_of_mass = origin

    # Track distances from CoM for each particle
    distances = [p.center.length() for p in particles]

    # Add particles one by one
    FOR np in 3..n_particles:
        np_f = float(np)
        np_minus_1 = float(np - 1)
        radius = random_radius(radius_range)

        # Calculate gamma - exact distance from CoM
        gamma1 = (np_f^2 / np_minus_1) * ((np_f/kf)^(2/Df) - LAPUERTA_CONSTANT)
        gamma2 = np_f * ((np_minus_1/kf)^(2/Df))
        gamma3 = (np_f / np_minus_1) * ((1/kf)^(2/Df) - LAPUERTA_CONSTANT)
        gamma_sq = gamma1 - gamma2 - gamma3

        IF gamma_sq <= 0:
            # Fallback to ballistic placement
            position = place_particle_ballistic(particles, rng, radius, sintering_config)
            particles.append(Sphere(position, radius))
            distances.append(position.length())
            CONTINUE

        gamma = rp * sqrt(gamma_sq)

        # Find LA- set: particles that could be in contact at distance gamma
        la_minus = []
        FOR i in 0..particles.length:
            IF distances[i] > gamma - 2.0 * rp:
                la_minus.append(i)

        IF la_minus.empty:
            # Fallback
            position = place_particle_ballistic(particles, rng, radius, sintering_config)
            particles.append(Sphere(position, radius))
            distances.append(position.length())
            CONTINUE

        # Try to place particle
        lb = copy(la_minus)  # Working set
        placed = false
        sintering_coeff = sample_sintering(sintering_config, rng)

        WHILE not lb.empty AND not placed:
            # Select random reference particle from LB
            ref_idx = random_choice(lb)
            ref_particle = particles[ref_idx]
            cb = ref_particle.center
            rb = ref_particle.radius

            # Calculate sintered contact distance
            contact_dist = sintering_coeff * (rb + radius)

            # Calculate alpha - angle to rotate CB to get CA at distance gamma
            cb_norm = cb.length()
            IF cb_norm < 1e-10:
                lb.remove(ref_idx)
                CONTINUE

            # Law of cosines: contact_dist^2 = gamma^2 + cb_norm^2 - 2*gamma*cb_norm*cos(alpha)
            cos_alpha = (gamma^2 + cb_norm^2 - contact_dist^2) / (2 * gamma * cb_norm)

            IF abs(cos_alpha) > 1.0:
                lb.remove(ref_idx)
                CONTINUE

            alpha = arccos(cos_alpha)

            # Find LA+ set: particles that could cause overlap
            la_plus = []
            FOR i in lb:
                IF i != ref_idx:
                    dist_to_ref = particles[i].center.distance_to(cb)
                    overlap_threshold = sintering_coeff * (rb + particles[i].radius)
                    IF dist_to_ref < 2.0 * overlap_threshold:
                        la_plus.append(i)

            # Try different rotation angles (beta)
            FOR rotation_attempt in 0..max_rotations:
                # Generate random rotation axis perpendicular to CB
                cb_unit = cb / cb_norm
                rotation_axis = find_perpendicular_axis(cb_unit, rng)

                # Rotate CB by alpha around rotation_axis
                ca_dir = rotate_vector(cb_unit, rotation_axis, alpha)

                # Random beta rotation around CB axis
                beta = random(0, 2*PI)
                ca_final = rotate_vector(ca_dir, cb_unit, beta)

                # Scale to gamma distance
                ca = ca_final * gamma

                # Check for overlaps with LA+
                has_overlap = false
                FOR i in la_plus:
                    dist = ca.distance_to(particles[i].center)
                    min_dist = sintering_coeff * (radius + particles[i].radius)
                    IF dist < min_dist - 1e-6:
                        has_overlap = true
                        BREAK

                IF not has_overlap:
                    # Also check against all particles for safety
                    safe = true
                    FOR p in particles:
                        dist = ca.distance_to(p.center)
                        min_dist = sintering_coeff * (radius + p.radius)
                        IF dist < min_dist - 1e-6:
                            safe = false
                            BREAK

                    IF safe:
                        particles.append(Sphere(ca, radius))
                        distances.append(ca.length())
                        placed = true
                        BREAK

            IF not placed:
                lb.remove(ref_idx)

        # Fallback if placement failed
        IF not placed:
            position = place_particle_ballistic(particles, rng, radius, sintering_config)
            particles.append(Sphere(position, radius))
            distances.append(position.length())

        # Recenter around new CoM
        center_of_mass = calculate_center_of_mass(particles)
        FOR p in particles:
            p.center = p.center - center_of_mass

        # Update distances
        FOR i in 0..particles.length:
            distances[i] = particles[i].center.length()

        # Track Rg evolution periodically
        IF np % 10 == 0 OR np == n_particles:
            rg = calculate_radius_of_gyration(particles)
            rg_evolution.append(rg)
            n_values.append(np)

    # Calculate final metrics from Rg evolution
    (actual_df, actual_kf, r2) = calculate_fractal_dimension_from_evolution(n_values, rg_evolution, rp)

    RETURN {
        particles: particles,
        rg_evolution: rg_evolution,
        fractal_dimension: actual_df,
        prefactor: actual_kf
    }
```

### Rodrigues Rotation Formula

Used for rotating vectors in 3D space:

```
FUNCTION rotate_vector(v, axis, angle):
    # v_rot = v*cos(a) + (axis x v)*sin(a) + axis*(axis.v)*(1-cos(a))
    cos_a = cos(angle)
    sin_a = sin(angle)

    cross = Vector3(
        axis.y * v.z - axis.z * v.y,
        axis.z * v.x - axis.x * v.z,
        axis.x * v.y - axis.y * v.x
    )

    dot = axis.x * v.x + axis.y * v.y + axis.z * v.z

    RETURN Vector3(
        v.x * cos_a + cross.x * sin_a + axis.x * dot * (1 - cos_a),
        v.y * cos_a + cross.y * sin_a + axis.y * dot * (1 - cos_a),
        v.z * cos_a + cross.z * sin_a + axis.z * dot * (1 - cos_a)
    )
```

### Fallback Ballistic Placement

When gamma-based placement fails, use ballistic approach with sintering:

```
FUNCTION place_particle_ballistic(particles, rng, radius, sintering_config):
    sintering_coeff = sample_sintering(sintering_config, rng)

    # Calculate bounding radius
    max_dist = max(p.center.length() + p.radius for p in particles)
    launch_dist = max_dist + radius * 5.0

    FOR attempt in 0..1000:
        # Random direction inward
        (dx, dy, dz) = random_point_on_sphere(rng)
        direction = Vector3(-dx, -dy, -dz)  # Inward
        start = Vector3(dx, dy, dz) * launch_dist

        # Ray march toward center
        step = radius * 0.5
        position = start

        FOR ray_step in 0..(launch_dist * 4 / step):
            # Check for contact
            FOR p in particles:
                dist = position.distance_to(p.center)
                sintered_dist = sintering_coeff * (radius + p.radius)

                IF dist <= sintered_dist * 1.01:
                    # Place at sintered contact point
                    to_p = (p.center - position).normalize()
                    contact_pos = p.center - to_p * sintered_dist

                    # Verify no overlaps
                    safe = true
                    FOR other in particles:
                        min_dist = sintering_coeff * (radius + other.radius)
                        IF contact_pos.distance_to(other.center) < min_dist - 1e-6:
                            safe = false
                            BREAK

                    IF safe:
                        RETURN contact_pos

            position = position + direction * step

    RETURN None
```

### Df and kf Calculation from Rg Evolution

```
FUNCTION calculate_fractal_dimension_from_evolution(n_values, rg_values, rp):
    IF n_values.length < 3:
        RETURN (2.0, 1.0, 0.0)

    # Use N = kf * (Rg/rp)^Df
    # log(N) = log(kf) + Df * log(Rg/rp)
    # So: x = log(Rg/rp), y = log(N)

    data = []
    FOR i in 0..n_values.length:
        n = n_values[i]
        rg = rg_values[i]
        IF n > 1 AND rg > rp * 0.1:
            data.append((log(rg / rp), log(n)))

    IF data.length < 3:
        RETURN (2.0, 1.0, 0.0)

    # Linear regression: y = intercept + slope * x
    # slope = Df, intercept = log(kf)
    (slope, intercept, r_squared) = linear_regression(data)

    df = clamp(slope, 1.0, 3.0)
    kf = clamp(exp(intercept), 0.1, 10.0)

    RETURN (df, kf, r_squared)
```

### Tunable CC Variant

Extends the concept to cluster-cluster aggregation:

```
ALGORITHM Tunable_CC_Simulation
PROCEDURE:
    # Initialize seed clusters (can use Tunable PC to create)
    clusters = create_seed_clusters(seed_cluster_size, n_clusters)

    WHILE total_particles(clusters) < n_particles:
        # Select two clusters to merge
        c1, c2 = select_clusters_to_merge(clusters)

        # Calculate target position for c2 relative to c1
        gamma = calculate_target_distance_for_clusters(c1, c2, target_df, target_kf)

        # Position c2 relative to c1's COM
        position_cluster_at_distance(c2, c1.center_of_mass, gamma)

        # Merge
        merged = merge_clusters(c1, c2)
        clusters.remove(c1, c2)
        clusters.append(merged)

    RETURN flatten_to_particles(clusters[0])
```

---

## 4.6 Limiting Case Geometries

### Algorithm Description

Limiting cases are deterministic reference geometries with known fractal dimensions, used for validation and calibration. See Chapter 10 for detailed implementations.

### Df = 1 (Linear Chains)

```
ALGORITHM Generate_Linear_Chain
INPUT: n_particles, radius, sintering_coeff

PROCEDURE:
    d = sintering_coeff * 2.0 * radius  # Center-to-center distance
    particles = []

    FOR i in 0..n_particles:
        particles.append(((d * i, 0, 0), radius))

    # Center at origin
    center = mean(particle.position for particle in particles)
    FOR particle in particles:
        particle.position -= center

    RETURN particles  # Df = 1.0 exactly
```

### Df = 2 (Planar Structures)

```
ALGORITHM Generate_Hexagonal_Plane
INPUT: n_particles, layers, radius, packing, sintering_coeff

PROCEDURE:
    d = sintering_coeff * 2.0 * radius

    IF packing == "CS":  # Cubic Simple (square grid)
        n_side = sqrt(n_particles)
        particles = []
        FOR j in 0..n_side:
            FOR i in 0..n_side:
                particles.append(((d * i, d * j, 0), radius))
        RETURN particles

    # Hexagonal Compact (HC) packing
    # Complete hexagonal rings formula: N = 1 + 3k(k+1) for k rings
    particles = [(origin, radius)]

    FOR ring in 1..layers:
        FOR side in 0..6:
            angle = side * PI / 3.0
            next_angle = (side + 1) * PI / 3.0

            corner_x = ring * d * cos(angle)
            corner_y = ring * d * sin(angle)
            next_x = ring * d * cos(next_angle)
            next_y = ring * d * sin(next_angle)

            FOR j in 0..ring:
                t = j / ring
                px = corner_x + t * (next_x - corner_x)
                py = corner_y + t * (next_y - corner_y)
                particles.append(((px, py, 0), radius))

    RETURN particles  # Df = 2.0
```

### Df = 3 (Compact Structures)

```
ALGORITHM Generate_Cuboctahedro
INPUT: layers, radius, packing, sintering_coeff

PROCEDURE:
    d = sintering_coeff * 2.0 * radius
    particles = []

    IF packing == "HC":  # Hexagonal Close-Packed
        z_spacing = 1.6345 * d  # sqrt(8/3)

        # Build 3D hexagonal layers
        FOR z_layer in -layers..layers:
            z = z_layer * z_spacing
            # Generate hexagonal layer at this z
            layer = generate_hexagonal_plane_at_z(layers - abs(z_layer), d, z)
            particles.extend(layer)

    ELSE IF packing == "CCC":  # Face-Centered Cubic
        spacing = d * 4 / sqrt(3)
        # Corner and face-center positions
        FOR j in 0..layers:
            FOR i in 0..layers:
                FOR k in 0..layers:
                    particles.append(((spacing * i, spacing * j, spacing * k), radius))
                    # Face centers
                    offset = spacing / 2
                    particles.append(((offset + spacing * i, offset + spacing * j, spacing * k), radius))

    RETURN particles  # Df = 3.0
```

---

## 4.7 Metrics Computation

### Radius of Gyration

```
ALGORITHM Compute_Radius_of_Gyration
INPUT: particles (positions, radii)

PROCEDURE:
    # Center of gravity (mass-weighted, using radius^3 as mass proxy)
    total_mass = 0
    center = (0, 0, 0)

    FOR particle in particles:
        mass = particle.radius^3
        center += particle.position * mass
        total_mass += mass

    center /= total_mass

    # Moment of inertia (including internal sphere contribution)
    total_inertia = 0

    FOR particle in particles:
        mass = particle.radius^3
        distance_sq = |particle.position - center|^2

        # Internal contribution (sphere moment about center: 3/5 * r^2)
        internal = (3/5) * particle.radius^2 * mass

        # Distance contribution (parallel axis theorem)
        external = mass * distance_sq

        total_inertia += internal + external

    Rg = sqrt(total_inertia / total_mass)

    RETURN Rg
```

### Fractal Dimension from Rg Evolution

```
ALGORITHM Compute_Fractal_Dimension
INPUT: rg_evolution (Rg values for N = 2, 3, 4, ...)

PROCEDURE:
    # Prepare log-log data
    n_values = []
    rg_values = []

    FOR i, rg in enumerate(rg_evolution):
        n = i + 2  # N starts at 2
        IF rg > 0:
            n_values.append(log(n))
            rg_values.append(log(rg))

    # Linear regression: log(Rg) = (1/Df) * log(N) + constant
    slope, intercept = linear_regression(n_values, rg_values)

    Df = 1.0 / slope
    kf = exp(intercept * Df)

    # Statistics
    r_squared = compute_r_squared(n_values, rg_values, slope, intercept)
    std_error = compute_standard_error(n_values, rg_values, slope, intercept)

    RETURN {
        fractal_dimension: Df,
        fractal_dimension_std: std_error / slope^2,  # Error propagation
        prefactor: kf,
        r_squared: r_squared
    }
```

### Inertia Tensor and Shape Descriptors

```
ALGORITHM Compute_Inertia_Tensor
INPUT: particles

PROCEDURE:
    center = compute_center_of_mass(particles)

    # Initialize 3x3 tensor
    I = zeros(3, 3)

    FOR particle in particles:
        mass = particle.radius^3
        r = particle.position - center
        x, y, z = r
        r2 = x^2 + y^2 + z^2

        # Diagonal elements (moment about axis)
        I[0,0] += mass * (y^2 + z^2)  # Ixx
        I[1,1] += mass * (x^2 + z^2)  # Iyy
        I[2,2] += mass * (x^2 + y^2)  # Izz

        # Off-diagonal (products of inertia - negative)
        I[0,1] -= mass * x * y
        I[0,2] -= mass * x * z
        I[1,2] -= mass * y * z

    # Symmetric
    I[1,0] = I[0,1]
    I[2,0] = I[0,2]
    I[2,1] = I[1,2]

    # Eigendecomposition
    eigenvalues, eigenvectors = eigen(I)

    # Sort by eigenvalue (I1 <= I2 <= I3)
    sort_indices = argsort(eigenvalues)
    I1, I2, I3 = eigenvalues[sort_indices]
    principal_axes = eigenvectors[:, sort_indices]

    # Shape descriptors
    anisotropy = I3 / I1 if I1 > 1e-10 else 1.0
    asphericity = I3 - 0.5 * (I1 + I2)
    acylindricity = I2 - I1

    RETURN {
        principal_moments: [I1, I2, I3],
        principal_axes: principal_axes,
        anisotropy: anisotropy,
        asphericity: asphericity,
        acylindricity: acylindricity
    }
```

### Coordination Number

```
ALGORITHM Compute_Coordination
INPUT: particles, tolerance = 0.01

PROCEDURE:
    coordination = zeros(particles.length)

    FOR i in 0..particles.length:
        FOR j in i+1..particles.length:
            p1, p2 = particles[i], particles[j]
            distance = |p1.position - p2.position|
            contact_distance = p1.radius + p2.radius

            # Allow small tolerance for numerical precision
            IF distance <= contact_distance * (1 + tolerance):
                coordination[i] += 1
                coordination[j] += 1

    RETURN {
        mean: mean(coordination),
        std: std(coordination),
        values: coordination
    }
```

---

## 4.8 Box-Counting (3D with Morton Codes)

### Algorithm Description

3D box-counting fractal dimension using Morton codes (Z-order curve) for efficient multi-scale counting. See Chapter 9 for detailed implementation.

### Morton Code Encoding

```
ALGORITHM Morton_Encode_3D
INPUT: x, y, z (integers in range [0, 2^precision))

PROCEDURE:
    # Interleave bits: z2y2x2 z1y1x1 z0y0x0
    ex = expand_bits_3d(x)  # Spread x bits to positions 0, 3, 6, ...
    ey = expand_bits_3d(y)  # Spread y bits to positions 1, 4, 7, ...
    ez = expand_bits_3d(z)  # Spread z bits to positions 2, 5, 8, ...

    RETURN ex | (ey << 1) | (ez << 2)

FUNCTION expand_bits_3d(x):
    # Keep only 21 bits (max for 64-bit Morton)
    x = x AND 0x1fffff

    # Magic number spreading
    x = (x | (x << 32)) AND 0x1f00000000ffff
    x = (x | (x << 16)) AND 0x1f0000ff0000ff
    x = (x | (x <<  8)) AND 0x100f00f00f00f00f
    x = (x | (x <<  4)) AND 0x10c30c30c30c30c3
    x = (x | (x <<  2)) AND 0x1249249249249249

    RETURN x
```

### Box-Counting Algorithm

```
ALGORITHM Box_Counting_3D
INPUT:
    points: list of (x, y, z) coordinates
    precision: number of bits (8-21)

OUTPUT:
    dimension: fractal dimension
    statistics: regression quality metrics

PROCEDURE:
    # 1. Normalize coordinates to [0, 2^precision)
    bounds = compute_bounding_box(points)
    scale = (2^precision - 1) / max(bounds.size)

    normalized = []
    FOR point in points:
        nx = round((point.x - bounds.min.x) / scale * (2^precision - 1))
        ny = round((point.y - bounds.min.y) / scale * (2^precision - 1))
        nz = round((point.z - bounds.min.z) / scale * (2^precision - 1))
        normalized.append((nx, ny, nz))

    # 2. Compute Morton codes (parallelizable)
    morton_codes = [Morton_Encode_3D(p.x, p.y, p.z) for p in normalized]

    # 3. Sort codes (O(N log N))
    sort(morton_codes)

    # 4. Count occupied boxes at each scale
    log_scales = []
    log_counts = []

    FOR level in 0..precision:
        shift = 3 * level  # 3 bits per level for 3D
        box_count = count_unique_masked(morton_codes, shift)

        IF box_count > 0 AND box_count < n_points:
            box_size = scale * (1 << level) / (2^precision - 1)
            log_scales.append(ln(1.0 / box_size))
            log_counts.append(ln(box_count))

    # 5. Robust linear regression
    (linear_start, slope, intercept, r_squared, std_error, residuals) =
        linear_regression_robust(log_scales, log_counts)

    dimension = slope  # Df = slope in log(N) vs log(1/s)

    RETURN {
        dimension: dimension,
        r_squared: r_squared,
        std_error: std_error,
        confidence_interval: (dimension - 1.96*std_error, dimension + 1.96*std_error),
        log_scales: log_scales,
        log_counts: log_counts,
        linear_region_start: linear_start
    }
```

---

## 4.9 FRAKTAL Analysis

### Granulated 2012 Model

```
ALGORITHM FRAKTAL_Granulated_2012
INPUT:
    image: grayscale image
    npix: pixels per 100nm
    dpo: primary particle diameter (nm)
    delta: filling factor
    correction_3d: apply 3D correction

OUTPUT:
    fractal_results: Df, kf, Rg, Npo, etc.

PROCEDURE:
    # 1. Image segmentation (Otsu or manual threshold)
    binary = threshold_image(image, pixel_min, pixel_max)

    # 2. Calculate image properties
    projected_area_px = count_white_pixels(binary)
    center_of_mass = compute_image_centroid(binary)
    Rg_px = compute_image_radius_of_gyration(binary, center_of_mass)

    # 3. Convert to physical units
    scale = 100.0 / npix  # nm per pixel
    Ap = projected_area_px * scale^2  # nm^2
    Rg = Rg_px * scale  # nm

    # 4. Apply 3D correction if enabled
    IF correction_3d:
        Rg = Rg * 1.09  # Empirical correction factor

    # 5. Estimate visual particle count
    single_particle_area = PI * (dpo/2)^2 * delta
    Npo_visual = Ap / single_particle_area

    # 6. Solve for Df using bisection
    Df = bisection_solve(
        f = (Df) => calculate_Npo(Ap, Rg, dpo, Df) - Npo_visual,
        lower = 1.0,
        upper = 3.0,
        tolerance = 0.001
    )

    # 7. Calculate remaining parameters
    Npo = calculate_Npo(Ap, Rg, dpo, Df)
    kf = calculate_prefactor(Rg, Npo, dpo, Df)
    zf = calculate_overlap_exponent(Df)

    # For granulated model, also calculate coordination index Jf
    Jf = 1.85 * Npo^17.0 / (1 + 1.45 * Npo^1.5)

    RETURN {
        rg: Rg,
        ap: Ap,
        df: Df,
        npo: Npo,
        npo_visual: Npo_visual,
        kf: kf,
        zf: zf,
        jf: Jf
    }
```

---

## 4.10 Sintering Model

### Sintering Distributions

```
ALGORITHM Sample_Sintering
INPUT:
    sintering_config: distribution configuration
    rng: random number generator

OUTPUT:
    coefficient: sintering coefficient in [0.5, 1.0]

PROCEDURE:
    SWITCH sintering_config.distribution_type:
        CASE "fixed":
            RETURN sintering_config.coefficient

        CASE "uniform":
            RETURN uniform_random(
                sintering_config.min,
                sintering_config.max,
                rng
            )

        CASE "normal":
            sample = normal_random(
                sintering_config.mean,
                sintering_config.std,
                rng
            )
            RETURN clamp(sample, 0.5, 1.0)
```

### Contact Distance with Sintering

```
Contact distance formula:
d_contact = sintering_coeff x (r1 + r2)

Coefficient interpretation:
- 1.0 = particles just touch (no sintering, no overlap)
- 0.9 = 10% overlap (light sintering)
- 0.75 = 25% overlap (moderate sintering)
- 0.5 = 50% overlap (heavy sintering, maximum)

Sintered contact distance function:
FUNCTION sintered_contact_distance(r1, r2, coeff):
    RETURN coeff * (r1 + r2)
```

---

## 4.11 Implementation Checklist

### Simulation Algorithms

- [ ] DLA with spatial hashing
- [ ] CCA with periodic boundaries
- [ ] Ballistic PC ray marching
- [ ] Ballistic CC cluster merging
- [ ] Tunable PC with Lapuerta gamma calculation
- [ ] Tunable CC cluster-cluster variant
- [ ] All limiting case generators (Df=1, 2, 3)

### Tunable Algorithm Specifics

- [ ] LA- set identification
- [ ] LA+ collision detection
- [ ] Rodrigues rotation implementation
- [ ] Ballistic fallback placement
- [ ] Df/kf calculation from Rg evolution

### Metrics

- [ ] Radius of gyration (mass-weighted with internal contribution)
- [ ] Fractal dimension from Rg evolution
- [ ] Inertia tensor and shape descriptors
- [ ] Coordination numbers
- [ ] Porosity

### Analysis

- [ ] Morton code 3D box-counting
- [ ] Robust linear regression with outlier detection
- [ ] FRAKTAL Granulated 2012
- [ ] FRAKTAL Voxel 2018
- [ ] Auto-calibration

### Sintering

- [ ] Fixed coefficient distribution
- [ ] Uniform distribution
- [ ] Normal distribution with clamping
- [ ] Sintered contact distance calculation
