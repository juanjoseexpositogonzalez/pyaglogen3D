# Chapter 9: Box-Counting Analysis

This chapter documents the 3D box-counting fractal dimension analysis implementation, including the Morton code algorithm, integration with simulations, skip-points regression refinement, and API endpoints.

## 9.1 Box-Counting Fundamentals

### Purpose and Theory

Box-counting is a standard method for estimating the fractal dimension of geometric objects. For an object embedded in 3D space, the fractal dimension Df is defined by the power law:

```
N(s) = C * s^(-Df)

where:
- N(s) = number of boxes of size s needed to cover the object
- s = box size
- Df = fractal dimension
- C = constant (related to object size)
```

Taking logarithms:
```
log(N) = log(C) - Df * log(s)

Therefore:
Df = -d(log N) / d(log s)
```

The fractal dimension is the negative slope of the log-log plot of box count vs box size.

### Expected Values for Reference Geometries

| Geometry | Expected Df | Box-Counting Df | Notes |
|----------|-------------|-----------------|-------|
| Line (1D) | 1.0 | 0.9-1.1 | Perfect linear |
| Plane (2D) | 2.0 | 1.9-2.1 | Flat surface |
| Cube (3D) | 3.0 | 2.8-3.0 | Filled volume |
| DLA agglomerate | ~2.5 | 2.3-2.7 | Open, dendritic |
| CCA agglomerate | ~1.8 | 1.7-2.0 | Hierarchical |
| Tunable agglomerate | Target | Target +/- 0.1 | Controlled |

---

## 9.2 Morton Code Algorithm

### Why Morton Codes?

Traditional box-counting iterates through all points and boxes at each scale, giving O(N * S) complexity where S is the number of scales. The Morton code approach reduces this to O(N log N) by:

1. Encoding 3D coordinates as 1D integers (Morton codes)
2. Sorting once (O(N log N))
3. Counting unique masked codes at each scale (O(N) per scale)

For N=100,000 points and S=15 scales:
- Traditional: O(1.5M operations)
- Morton: O(1.7M + 1.5M = 3.2M) but with much better cache efficiency

### Bit Interleaving

Morton codes interleave the bits of x, y, z coordinates:

```
For 3D coordinates (x, y, z) with bits:
    x = x2 x1 x0
    y = y2 y1 y0
    z = z2 z1 z0

Morton code = z2 y2 x2 | z1 y1 x1 | z0 y0 x0
            = (interleaved bits)

Example:
    x = 5 = 101₂
    y = 3 = 011₂
    z = 6 = 110₂

    Morton = 110 001 110 011 100 001
           = interleave(x, y, z)
```

The interleaving creates a space-filling Z-order curve that preserves spatial locality.

### Expand Bits Algorithm

```
ALGORITHM Expand_Bits_3D
INPUT:
    x: 64-bit integer (only lower 21 bits used)

OUTPUT:
    expanded: 64-bit integer with bits spread to positions 0, 3, 6, 9, ...

PROCEDURE:
    # Keep only 21 bits (maximum for 3D Morton in 64-bit)
    x = x AND 0x1fffff

    # Magic number spreading using PDEP-style pattern
    x = (x OR (x << 32)) AND 0x1f00000000ffff
    x = (x OR (x << 16)) AND 0x1f0000ff0000ff
    x = (x OR (x <<  8)) AND 0x100f00f00f00f00f
    x = (x OR (x <<  4)) AND 0x10c30c30c30c30c3
    x = (x OR (x <<  2)) AND 0x1249249249249249

    RETURN x

VISUALIZATION:
    Input:  000...000 XXXXX XXXXX XXXXX XXXXX X  (21 bits)
    Output: 00X..X00X 00X00 X00X0 0X00X 00X00 X  (63 bits, every 3rd)
```

### Morton Encode 3D

```
ALGORITHM Morton_Encode_3D
INPUT:
    x, y, z: 64-bit integers (normalized coordinates)

OUTPUT:
    code: 64-bit Morton code

PROCEDURE:
    # Expand each coordinate
    ex = Expand_Bits_3D(x)
    ey = Expand_Bits_3D(y)
    ez = Expand_Bits_3D(z)

    # Interleave: x at bit 0, y at bit 1, z at bit 2
    code = ex OR (ey << 1) OR (ez << 2)

    RETURN code

# Resulting bit pattern: z₂₀y₂₀x₂₀ z₁₉y₁₉x₁₉ ... z₁y₁x₁ z₀y₀x₀
```

### Counting Unique Boxes

After sorting Morton codes, counting unique boxes at scale k requires masking off the low 3k bits:

```
ALGORITHM Count_Unique_Masked
INPUT:
    sorted_codes: sorted array of Morton codes
    shift: number of low bits to mask (3k for scale k)

OUTPUT:
    count: number of unique masked codes

PROCEDURE:
    IF sorted_codes is empty:
        RETURN 0

    IF shift >= 64:
        RETURN 1  # All codes mask to 0

    mask = NOT ((1 << shift) - 1)
    # e.g., shift=6: mask = 1111...1111000000

    count = 1
    prev_masked = sorted_codes[0] AND mask

    FOR code in sorted_codes[1:]:
        masked = code AND mask
        IF masked != prev_masked:
            count += 1
            prev_masked = masked

    RETURN count
```

### Complete Box-Counting Algorithm

```
ALGORITHM Box_Counting_3D_Morton
INPUT:
    points: Nx3 array of (x, y, z) coordinates
    precision: number of bits per dimension (8-21)

OUTPUT:
    result: BoxCountingResult3D with dimension and statistics

PROCEDURE:
    n_points = points.length
    precision = min(precision, 21)  # Maximum for 64-bit Morton

    # Step 1: Normalize coordinates to [0, 2^precision)
    (min_coords, max_coords) = find_bounding_box(points)
    scale = max_dimension_range(min_coords, max_coords)
    max_val = (1 << precision) - 1

    # Step 2: Convert to Morton codes (parallelizable)
    morton_codes = []
    FOR point in points:
        nx = normalize_coord(point.x, min_coords[0], scale, max_val)
        ny = normalize_coord(point.y, min_coords[1], scale, max_val)
        nz = normalize_coord(point.z, min_coords[2], scale, max_val)
        morton_codes.append(Morton_Encode_3D(nx, ny, nz))

    # Step 3: Sort Morton codes (O(N log N))
    sort(morton_codes)

    # Step 4: Count boxes at each scale
    log_scales = []
    log_counts = []

    FOR level in 0..precision:
        shift = 3 * level  # 3 bits per level for 3D

        box_count = Count_Unique_Masked(morton_codes, shift)

        IF box_count > 0 AND box_count < n_points:
            box_size = scale * (1 << level) / max_val
            log_scales.append(ln(1.0 / box_size))
            log_counts.append(ln(box_count))

    # Step 5: Robust linear regression
    (linear_start, slope, intercept, r_squared, std_error, residuals) =
        linear_regression_robust(log_scales, log_counts)

    dimension = slope  # Df = -d(log N)/d(log s), but we use log(1/s)
    confidence_interval = (dimension - 1.96*std_error, dimension + 1.96*std_error)

    RETURN BoxCountingResult3D {
        dimension: dimension,
        r_squared: r_squared,
        std_error: std_error,
        confidence_interval: confidence_interval,
        log_scales: log_scales,
        log_counts: log_counts,
        residuals: residuals,
        linear_region_start: linear_start,
    }
```

---

## 9.3 Coordinate Normalization

### Bounding Box Calculation

```
ALGORITHM Find_Bounding_Box
INPUT:
    points: array of 3D points

OUTPUT:
    min_coords: [x_min, y_min, z_min]
    max_coords: [x_max, y_max, z_max]

PROCEDURE:
    min_coords = [+INFINITY, +INFINITY, +INFINITY]
    max_coords = [-INFINITY, -INFINITY, -INFINITY]

    FOR point in points:
        FOR dim in 0..3:
            IF point[dim] < min_coords[dim]:
                min_coords[dim] = point[dim]
            IF point[dim] > max_coords[dim]:
                max_coords[dim] = point[dim]

    RETURN (min_coords, max_coords)
```

### Uniform Scale Calculation

To preserve aspect ratio, use the maximum range:

```
ALGORITHM Compute_Scale
INPUT:
    min_coords, max_coords: bounding box corners

OUTPUT:
    scale: uniform scaling factor

PROCEDURE:
    max_range = 0

    FOR dim in 0..3:
        range = max_coords[dim] - min_coords[dim]
        max_range = max(max_range, range)

    # Avoid division by zero
    IF max_range < 1e-15:
        RETURN 1.0

    RETURN max_range
```

### Coordinate Normalization

```
ALGORITHM Normalize_Coord
INPUT:
    value: original coordinate
    min_val: minimum of that dimension
    scale: uniform scale
    max_int: maximum integer value (2^precision - 1)

OUTPUT:
    normalized: integer in [0, max_int]

PROCEDURE:
    normalized_float = (value - min_val) / scale
    clamped = clamp(normalized_float, 0.0, 1.0)
    normalized = round(clamped * max_int)

    RETURN normalized
```

---

## 9.4 Skip-Points Linear Regression

### Problem: Non-Linear Regions

The log-log plot often has non-linear regions:

1. **Small scales (left side)**: Finite resolution effects
2. **Large scales (right side)**: Finite size effects

The true fractal dimension comes from the linear middle region.

```
LOG-LOG PLOT

log(N) │     *
       │    *
       │   *          <- Non-linear (finite size)
       │  *
       │ *
       │*   *
       │   * *        <- LINEAR REGION (target)
       │     * *
       │       * *
       │         **   <- Non-linear (finite resolution)
       └────────────────────── log(1/s)
```

### Robust Regression Algorithm

```
ALGORITHM Linear_Regression_Robust
INPUT:
    x: log(1/s) values
    y: log(N) values

OUTPUT:
    (start_index, slope, intercept, r_squared, std_error, residuals)

CONSTANTS:
    min_points = 4
    residual_threshold = 2.0  # Standardized residual cutoff
    r2_drop_threshold = 0.02  # Maximum acceptable R² drop

PROCEDURE:
    n = x.length
    IF n < 3:
        # Fall back to simple regression
        RETURN (0, *linear_regression(x, y))

    # Start from right side (large scales - more reliable)
    start_idx = n - min_points
    (slope, intercept, r2, std_error, _) = linear_regression(x[start_idx:], y[start_idx:])

    best_start = start_idx
    best_r2 = r2

    # Progressively add points from left
    FOR i in (start_idx - 1) down to 0:
        # Compute predicted value for new point
        y_pred = intercept + slope * x[i]
        residual = y[i] - y_pred
        std_residual = abs(residual) / std_error if std_error > 1e-15 else 0

        # Try including this point
        (new_slope, new_intercept, new_r2, new_se, _) = linear_regression(x[i:], y[i:])
        r2_drop = best_r2 - new_r2

        # Check if point is an outlier
        IF std_residual > residual_threshold AND r2_drop > r2_drop_threshold:
            BREAK  # Stop here, don't include this outlier

        # Accept point
        slope = new_slope
        intercept = new_intercept
        std_error = new_se

        IF new_r2 > best_r2 - 0.01:
            best_start = i
            best_r2 = max(best_r2, new_r2)

        r2 = new_r2

    # Final regression on selected range
    (final_slope, final_intercept, final_r2, final_se, _) =
        linear_regression(x[best_start:], y[best_start:])

    # Compute residuals for ALL points (for visualization)
    residuals = []
    FOR i in 0..n:
        residual = y[i] - (final_intercept + final_slope * x[i])
        residuals.append(residual)

    RETURN (best_start, final_slope, final_intercept, final_r2, final_se, residuals)
```

### Visual Interpretation

```
REGRESSION VISUALIZATION

log(N) │
       │ ● ● ●                 ← Excluded (outliers)
       │       ● ● ●           ← LINEAR REGION START (linear_region_start)
       │             ● ● ●
       │                   ● ● ← Included (linear region)
       └───────────────────────── log(1/s)

       [----excluded---][--------included--------]
                        ^
                        linear_region_start
```

---

## 9.5 Agglomerate-Specific Box-Counting

### Surface Point Generation

For particle agglomerates, we generate surface points on each sphere using the Fibonacci lattice:

```
ALGORITHM Generate_Sphere_Points
INPUT:
    cx, cy, cz: sphere center coordinates
    radius: sphere radius
    n_points: number of points to generate

OUTPUT:
    points: array of 3D points on sphere surface

PROCEDURE:
    golden_ratio = (1 + sqrt(5)) / 2
    angle_increment = 2 * PI / golden_ratio

    points = []
    FOR i in 0..n_points:
        # Parameter t ranges from 0 to 1
        t = i / (n_points - 1)

        # Spherical coordinates
        inclination = arccos(1 - 2 * t)
        azimuth = angle_increment * i

        # Convert to Cartesian
        sin_inc = sin(inclination)
        x = cx + radius * sin_inc * cos(azimuth)
        y = cy + radius * sin_inc * sin(azimuth)
        z = cz + radius * cos(inclination)

        points.append([x, y, z])

    RETURN points
```

### Agglomerate Box-Counting

```
ALGORITHM Box_Counting_Agglomerate
INPUT:
    centers: Nx3 array of sphere center coordinates
    radii: N-element array of sphere radii
    points_per_sphere: surface points per sphere (default: 100)
    precision: bits per dimension (default: 18)

OUTPUT:
    result: BoxCountingResult3D

PROCEDURE:
    n_spheres = centers.length

    # Generate surface points for all spheres
    all_points = []
    FOR i in 0..n_spheres:
        cx, cy, cz = centers[i]
        r = radii[i]
        sphere_points = Generate_Sphere_Points(cx, cy, cz, r, points_per_sphere)
        all_points.extend(sphere_points)

    # Run standard 3D box-counting
    RETURN Box_Counting_3D_Morton(all_points, precision)
```

### Points Per Sphere Selection

| Points/Sphere | Total Points (N=500) | Quality | Execution Time |
|---------------|---------------------|---------|----------------|
| 25 | 12,500 | Basic | ~10ms |
| 50 | 25,000 | Good | ~20ms |
| 100 | 50,000 | Standard | ~45ms |
| 200 | 100,000 | High | ~100ms |
| 500 | 250,000 | Research | ~250ms |

**Recommendation**: 100 points per sphere balances quality and speed.

---

## 9.6 API Endpoints

### Single Simulation Box-Counting

```
GET /api/v1/projects/{project_id}/simulations/{id}/box-counting/

Query Parameters:
    points_per_sphere: int (default: 100, range: 10-1000)
    precision: int (default: 18, range: 8-21)

Response 200:
{
    "dimension": 1.85,
    "r_squared": 0.9985,
    "std_error": 0.023,
    "confidence_interval": [1.80, 1.90],
    "log_scales": [0.5, 1.0, 1.5, 2.0, ...],
    "log_values": [4.0, 4.5, 5.0, 5.5, ...],
    "residuals": [0.01, -0.02, 0.01, ...],
    "linear_region_start": 2,
    "execution_time_ms": 45,
    "parameters": {
        "points_per_sphere": 100,
        "precision": 18,
        "n_particles": 500
    }
}

Error Responses:
    404: Geometry not available
    400: Invalid parameters
```

### Batch Box-Counting (Studies)

```
POST /api/v1/projects/{project_id}/studies/{id}/run-box-counting/

Request Body:
{
    "points_per_sphere": 100,
    "precision": 18
}

Response 200:
{
    "status": "completed",
    "message": "Box-counting completed: 40 processed, 5 skipped, 0 failed",
    "results": {
        "total": 45,
        "processed": 40,
        "skipped": 5,
        "failed": 0,
        "errors": []
    }
}
```

### Study Export with Box-Counting

When `include_box_counting=true`, the CSV export includes:

```csv
..., BC_Df, BC_R2, BC_StdError, BC_Time_ms
..., 1.85, 0.9985, 0.023, 45
```

---

## 9.7 Frontend Integration

### React Query Hooks

```
HOOK useBoxCounting(projectId, simulationId, params)

PARAMETERS:
    projectId: string
    simulationId: string
    params: { points_per_sphere?: number, precision?: number }

RETURNS:
    data: BoxCountingResult | undefined
    isLoading: boolean
    error: Error | null
    refetch: () => void

CONFIGURATION:
    staleTime: Infinity (results don't change for same simulation)
    enabled: simulation.has_geometry
```

### Log-Log Visualization Component

```
COMPONENT BoxCountingChart

PROPS:
    logScales: number[]
    logCounts: number[]
    linearRegionStart: number
    dimension: number
    rSquared: number

RENDER:
    # Scatter plot with regression line
    <ResponsiveContainer>
        <ScatterChart>
            # Data points (circles)
            <Scatter data={points}>
                # Color points: blue if in linear region, gray if excluded

            # Regression line
            <Line
                data={regressionLine}
                stroke="red"
                strokeDasharray="5 5"
            />

            # Annotation
            <Text>
                Df = {dimension.toFixed(3)}
                R² = {rSquared.toFixed(4)}
            </Text>
        </ScatterChart>
    </ResponsiveContainer>
```

### Precision Control UI

```
COMPONENT BoxCountingControls

STATE:
    pointsPerSphere: number = 100
    precision: number = 18

RENDER:
    <Slider
        label="Points per sphere"
        min={10}
        max={500}
        value={pointsPerSphere}
        onChange={setPointsPerSphere}
    />

    <Slider
        label="Precision (bits)"
        min={8}
        max={21}
        value={precision}
        onChange={setPrecision}
    />

    <Button onClick={runAnalysis}>
        Run Box-Counting
    </Button>
```

---

## 9.8 Comparison: Rg-Based vs Box-Counting Df

### Two Methods for Fractal Dimension

The system computes Df using two independent methods:

| Method | Source | Strength | Weakness |
|--------|--------|----------|----------|
| Rg-based | Growth evolution | Built into simulation | Depends on algorithm |
| Box-counting | Final geometry | Independent validation | Finite-size effects |

### Expected Correlation

For well-formed agglomerates:
```
Df_boxcounting ≈ Df_rg ± 0.1
```

Significant differences indicate:
1. Non-fractal geometry (e.g., too few particles)
2. Non-equilibrium growth
3. Pathological structure

### Visualization: Df Comparison

```
COMPONENT DfComparisonChart

DATA:
    simulations: Simulation[]
    each has:
        df_rg: fractal_dimension from metrics
        df_bc: box_counting.dimension

RENDER:
    <ScatterPlot>
        # Each point is one simulation
        x = df_rg
        y = df_bc

        # 1:1 reference line
        <Line y={x} stroke="gray" />

        # Axis labels
        xAxis: "Df (Rg-based)"
        yAxis: "Df (Box-counting)"
    </ScatterPlot>

    # Statistics panel
    <Stats>
        Correlation: r = {correlation(df_rg, df_bc)}
        Mean difference: {mean(df_bc - df_rg)}
        Std difference: {std(df_bc - df_rg)}
    </Stats>
```

---

## 9.9 Implementation Checklist

### Rust Engine (aglogen_core)

- [ ] Morton code encoding/decoding
- [ ] Expand bits 3D implementation
- [ ] Count unique masked codes
- [ ] Coordinate normalization
- [ ] Box-counting 3D Morton main function
- [ ] Robust linear regression
- [ ] Sphere surface point generation
- [ ] Agglomerate box-counting wrapper
- [ ] PyO3 Python bindings
- [ ] Unit tests for all functions

### Backend Integration

- [ ] Box-counting endpoint on SimulationViewSet
- [ ] Query parameter validation
- [ ] Box-counting in simulation task (if study configured)
- [ ] Results stored in simulation.metrics["box_counting"]
- [ ] Post-hoc box-counting on studies
- [ ] CSV export with box-counting columns

### Frontend

- [ ] useBoxCounting React Query hook
- [ ] BoxCountingChart log-log visualization
- [ ] BoxCountingControls parameter inputs
- [ ] Integration in SimulationDetail view
- [ ] Df comparison visualization
- [ ] Error handling for API failures

### Testing

- [ ] Test Morton encoding/decoding roundtrip
- [ ] Test box-counting on known geometries (line, plane, cube)
- [ ] Test agglomerate box-counting
- [ ] Test API endpoint responses
- [ ] Test CSV export format

---

## 9.10 Performance Optimization

### Parallelization

The Morton code computation is embarrassingly parallel:

```rust
// Rust with rayon
let morton_codes: Vec<u64> = points
    .par_iter()  // Parallel iterator
    .map(|p| {
        let nx = normalize_coord(p[0], min[0], scale, max_val);
        let ny = normalize_coord(p[1], min[1], scale, max_val);
        let nz = normalize_coord(p[2], min[2], scale, max_val);
        morton_encode_3d(nx, ny, nz)
    })
    .collect();
```

### Sorting Optimization

```rust
// Parallel unstable sort (fastest for primitives)
sorted_codes.par_sort_unstable();
```

### GIL Release

The Rust implementation releases the Python GIL during computation:

```rust
#[pyfunction]
pub fn box_counting_3d(py: Python<'_>, coordinates: ...) -> PyResult<...> {
    // ...setup...

    // Release GIL during heavy computation
    let result = py.allow_threads(|| {
        box_counting_3d_morton(&points, precision)
    });

    // Convert to Python types
    Ok(result.to_py())
}
```

### Benchmarks

| N Points | Precision | Time (single-threaded) | Time (8 threads) |
|----------|-----------|------------------------|------------------|
| 10,000 | 15 | 5ms | 2ms |
| 50,000 | 18 | 25ms | 8ms |
| 100,000 | 18 | 55ms | 15ms |
| 500,000 | 21 | 300ms | 80ms |

For typical agglomerates (500 particles, 100 points/sphere = 50,000 points), expect ~25-45ms execution time.
