# PyAglogen3D - Research & Science Report

## Abstract

This report presents the theoretical foundations, mathematical derivations, and algorithmic analysis underlying PyAglogen3D, a computational platform for 3D particle agglomerate simulation and fractal analysis. We provide rigorous mathematical treatment of aggregation algorithms, fractal dimension calculation methods, and image-based analysis techniques used in soot and aerosol research.

The document covers:

1. **Fractal Geometry Fundamentals**: Self-similarity, scaling laws, and the power law relationship N = kf(Rg/rp)^Df
2. **Aggregation Physics**: Diffusion-limited (DLA), cluster-cluster (CCA), ballistic, and tunable aggregation mechanisms
3. **Computational Geometry**: Radius of gyration, inertia tensor analysis, and shape descriptors
4. **Fractal Dimension Estimation**: Box-counting algorithms with Morton code optimization (O(N log N))
5. **FRAKTAL Analysis**: Granulated 2012 and Voxel 2018 models for TEM/SEM image analysis

This report serves as the scientific reference for researchers using PyAglogen3D, providing the mathematical basis for interpreting simulation results and validating experimental comparisons.

## Keywords

Fractal dimension, particle aggregation, soot morphology, diffusion-limited aggregation, cluster-cluster aggregation, box-counting, Morton codes, radius of gyration, inertia tensor, FRAKTAL analysis

## Notation

| Symbol | Description | Units |
|--------|-------------|-------|
| N | Number of primary particles | - |
| Df | Fractal dimension | - |
| kf | Fractal prefactor | - |
| Rg | Radius of gyration | nm |
| rp | Primary particle radius | nm |
| Ap | Projected area | nm² |
| Ip | Moment of inertia | nm⁵ |
| mp | Mass (or volume proxy) | nm³ |
| η | Coordination number | - |
| ε | Porosity | - |
| cs | Sintering coefficient | - |
