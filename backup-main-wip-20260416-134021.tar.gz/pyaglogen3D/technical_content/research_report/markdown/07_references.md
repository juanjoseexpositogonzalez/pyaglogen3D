# Chapter 7: References and Further Reading

## 7.1 Foundational Works

### Fractal Geometry

1. **Mandelbrot, B.B.** (1982). *The Fractal Geometry of Nature*. W.H. Freeman and Company.
   - Foundational text on fractal geometry and self-similarity
   - Introduces fractal dimension concepts

2. **Forrest, S.R., & Witten, T.A.** (1979). Long-range correlations in smoke-particle aggregates. *Journal of Physics A: Mathematical and General*, 12(5), L109.
   - Early observation of fractal scaling in particle aggregates

### Aggregation Theory

3. **Witten, T.A., & Sander, L.M.** (1981). Diffusion-Limited Aggregation, a Kinetic Critical Phenomenon. *Physical Review Letters*, 47(19), 1400-1403.
   - Original DLA algorithm
   - Established Df ≈ 2.5 for 3D DLA

4. **Meakin, P.** (1983). Formation of Fractal Clusters and Networks by Irreversible Diffusion-Limited Aggregation. *Physical Review Letters*, 51(13), 1119-1122.
   - Cluster-cluster aggregation theory
   - Df ≈ 1.8 for CCA

5. **Kolb, M., Botet, R., & Jullien, R.** (1983). Scaling of Kinetically Growing Clusters. *Physical Review Letters*, 51(13), 1123-1126.
   - Hierarchical cluster-cluster aggregation
   - Scaling relations for CCA

## 7.2 Soot and Combustion Aerosols

6. **Sorensen, C.M.** (2001). Light Scattering by Fractal Aggregates: A Review. *Aerosol Science and Technology*, 35(2), 648-687.
   - Comprehensive review of fractal aggregate optics
   - Relationship between Df, kf and optical properties

7. **Brasil, A.M., Farias, T.L., & Carvalho, M.G.** (1999). A Recipe for Image Characterization of Fractal-Like Aggregates. *Journal of Aerosol Science*, 30(10), 1379-1389.
   - FRAKTAL methodology foundations
   - Image analysis for aggregate characterization

8. **Köylü, Ü.Ö., & Faeth, G.M.** (1992). Structure of Overfire Soot in Buoyant Turbulent Diffusion Flames at Long Residence Times. *Combustion and Flame*, 89(2), 140-156.
   - Experimental soot morphology data
   - Validation benchmarks for simulations

## 7.3 Algorithm Development

### Tunable Aggregation

9. **Filippov, A.V., Zurita, M., & Rosner, D.E.** (2000). Fractal-like Aggregates: Relation between Morphology and Physical Properties. *Journal of Colloid and Interface Science*, 229(1), 261-273.
   - Tunable algorithm (target Df)
   - Morphology-property relationships

10. **Lapuerta, M., Ballesteros, R., & Martos, F.J.** (2006). A Method to Determine the Fractal Dimension of Diesel Soot Agglomerates. *Journal of Colloid and Interface Science*, 303(1), 149-158.
    - Lapuerta constant derivation (3/5 factor)
    - Extended tunable algorithm

### Box-Counting and Dimension Estimation

11. **Liebovitch, L.S., & Toth, T.** (1989). A Fast Algorithm to Determine Fractal Dimensions by Box Counting. *Physics Letters A*, 141(8-9), 386-390.
    - Efficient box-counting algorithms
    - Scale selection methods

12. **Morton, G.M.** (1966). A Computer Oriented Geodetic Data Base and a New Technique in File Sequencing. IBM Technical Report.
    - Original Morton code (Z-order curve)
    - Spatial indexing foundations

## 7.4 Computational Methods

### Spatial Data Structures

13. **Bentley, J.L.** (1975). Multidimensional Binary Search Trees Used for Associative Searching. *Communications of the ACM*, 18(9), 509-517.
    - k-d trees for spatial queries
    - Nearest neighbor algorithms

14. **Ericson, C.** (2004). *Real-Time Collision Detection*. Morgan Kaufmann.
    - Spatial hashing techniques
    - Collision detection algorithms

### Numerical Methods

15. **Press, W.H., Teukolsky, S.A., Vetterling, W.T., & Flannery, B.P.** (2007). *Numerical Recipes: The Art of Scientific Computing* (3rd ed.). Cambridge University Press.
    - Linear regression and error analysis
    - Random number generation

## 7.5 Image Analysis

### FRAKTAL Models

16. **Bescond, A., Yon, J., Ouf, F.X., et al.** (2014). Automated Determination of Aggregate Primary Particle Size Distribution by TEM Image Analysis: Application to Soot. *Aerosol Science and Technology*, 48(8), 831-841.
    - FRAKTAL 2012 (Granulated) model
    - Overlap correction methods

17. **Yon, J., Bescond, A., & Liu, F.** (2015). On the Radiative Properties of Soot Aggregates—Part 1: Necking and Overlapping. *Journal of Quantitative Spectroscopy and Radiative Transfer*, 162, 197-206.
    - Voxel-based analysis methods
    - Sintering effects on morphology

### Image Processing

18. **Otsu, N.** (1979). A Threshold Selection Method from Gray-Level Histograms. *IEEE Transactions on Systems, Man, and Cybernetics*, 9(1), 62-66.
    - Otsu's automatic thresholding
    - Bimodal histogram analysis

19. **Gonzalez, R.C., & Woods, R.E.** (2017). *Digital Image Processing* (4th ed.). Pearson.
    - Morphological operations
    - Image segmentation techniques

## 7.6 Physical Properties

### Mobility and Transport

20. **Rogak, S.N., Flagan, R.C., & Nguyen, H.V.** (1993). The Mobility and Structure of Aerosol Agglomerates. *Aerosol Science and Technology*, 18(1), 25-47.
    - Mobility diameter relationships
    - Drag on fractal aggregates

21. **Sorensen, C.M., & Roberts, G.C.** (1997). The Prefactor of Fractal Aggregates. *Journal of Colloid and Interface Science*, 186(2), 447-452.
    - Prefactor kf analysis
    - Structure-property correlations

### Sintering

22. **Koch, W., & Friedlander, S.K.** (1990). The Effect of Particle Coalescence on the Surface Area of a Coagulating Aerosol. *Journal of Colloid and Interface Science*, 140(2), 419-427.
    - Sintering kinetics
    - Surface area evolution

## 7.7 Software and Implementation

### Language-Specific

23. **Klabnik, S., & Nichols, C.** (2019). *The Rust Programming Language*. No Starch Press.
    - Rust language fundamentals
    - Memory safety guarantees

24. **PyO3 Contributors**. PyO3 User Guide. https://pyo3.rs/
    - Rust-Python bindings
    - Performance optimization

### Web Technologies

25. **Django Software Foundation**. Django Documentation. https://docs.djangoproject.com/
    - Django REST framework
    - Celery task queues

26. **Vercel**. Next.js Documentation. https://nextjs.org/docs
    - React Server Components
    - API routes

## 7.8 Mathematical Background

### Linear Algebra

27. **Strang, G.** (2019). *Linear Algebra and Learning from Data*. Wellesley-Cambridge Press.
    - Eigenvalue decomposition
    - Least squares methods

### Statistics

28. **Casella, G., & Berger, R.L.** (2002). *Statistical Inference* (2nd ed.). Duxbury.
    - Regression theory
    - Confidence intervals

## 7.9 Notation Reference

| Symbol | Definition | Units |
|--------|------------|-------|
| N | Number of primary particles | - |
| Df | Fractal dimension | - |
| kf | Fractal prefactor | - |
| Rg | Radius of gyration | nm |
| rp | Primary particle radius | nm |
| cs | Sintering coefficient | - |
| η | Coordination number | - |
| Ap | Projected area | nm² |
| I | Inertia tensor | nm⁵ |
| A | Anisotropy | - |
| b | Asphericity | - |
| c | Acylindricity | - |

## 7.10 Standards and Guidelines

29. **ISO 9276-6:2008**. Representation of results of particle size analysis — Part 6: Descriptive and quantitative representation of particle shape and morphology.

30. **ASTM E2578-07**. Standard Practice for Calculation of Mean Sizes/Diameters and Standard Deviations of Particle Size Distributions.

---

*Note: This reference list represents key works in the field. The actual implementation may incorporate additional sources and updated methodologies.*
