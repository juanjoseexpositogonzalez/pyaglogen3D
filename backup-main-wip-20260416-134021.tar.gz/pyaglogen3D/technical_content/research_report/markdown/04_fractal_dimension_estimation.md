# Chapter 4: Fractal Dimension Estimation

## 4.1 Overview of Methods

Several methods exist for estimating fractal dimension, each with different input requirements, accuracy characteristics, and computational costs.

| Method | Input | $D_f$ Range | Complexity | Best Use Case |
|--------|-------|-------------|------------|---------------|
| Log-log regression ($R_g$ vs $N$) | Simulation growth history | 1-3 | O(N) | During simulation |
| 3D Box-counting | Point cloud / voxels | 1-3 | O(N log N) | Final structure analysis |
| Sandbox method | Point cloud | 1-3 | O(N^2) | Local dimension variation |
| Correlation dimension | Point cloud | 1-3 | O(N^2) | Statistical analysis |
| 2D Box-counting | Binary image | 1-2 | O(P) | TEM/SEM images |
| FRAKTAL (projected) | Binary image | 1-3 | O(P) | Experimental images |

where P = number of pixels.

## 4.2 Log-Log Regression Method

### Theoretical Foundation

The power law relationship provides a direct method for estimating $D_f$ during simulation:

$$
N = k_f \left(\frac{R_g}{r_p}\right)^{D_f}
$$

Taking natural logarithms:

$$
\ln(N) = \ln(k_f) + D_f \cdot \ln\left(\frac{R_g}{r_p}\right)
$$

Rearranging to express $\ln(R_g)$ as function of $\ln(N)$:

$$
\ln(R_g) = \frac{1}{D_f} \ln(N) + \left[\ln(r_p) - \frac{\ln(k_f)}{D_f}\right]
$$

This is a linear equation $y = mx + b$ where:
- $y = \ln(R_g)$
- $x = \ln(N)$
- $m = 1/D_f$ (slope)
- $b = \ln(r_p) - \ln(k_f)/D_f$ (intercept)

### Linear Regression: Complete Derivation

Given $M$ data points $\{(x_i, y_i)\} = \{(\ln(N_i), \ln(R_{g,i}))\}$, find the least-squares fit.

**Objective Function**:

Minimize the sum of squared residuals:

$$
S(m, b) = \sum_{i=1}^{M} (y_i - mx_i - b)^2
$$

**Taking Partial Derivatives**:

$$
\frac{\partial S}{\partial m} = -2 \sum_{i=1}^{M} x_i(y_i - mx_i - b) = 0
$$

$$
\frac{\partial S}{\partial b} = -2 \sum_{i=1}^{M} (y_i - mx_i - b) = 0
$$

**Normal Equations**:

From the second equation:

$$
\sum_i y_i - m \sum_i x_i - Mb = 0
$$

$$
b = \frac{\sum_i y_i - m \sum_i x_i}{M} = \bar{y} - m\bar{x}
$$

Substituting into the first equation:

$$
\sum_i x_i y_i - m \sum_i x_i^2 - b \sum_i x_i = 0
$$

$$
\sum_i x_i y_i - m \sum_i x_i^2 - (\bar{y} - m\bar{x}) \sum_i x_i = 0
$$

**Solving for Slope**:

$$
m = \frac{\sum_i x_i y_i - M\bar{x}\bar{y}}{\sum_i x_i^2 - M\bar{x}^2} = \frac{S_{xy}}{S_{xx}}
$$

where:
- $S_{xy} = \sum_i (x_i - \bar{x})(y_i - \bar{y}) = \sum_i x_i y_i - M\bar{x}\bar{y}$
- $S_{xx} = \sum_i (x_i - \bar{x})^2 = \sum_i x_i^2 - M\bar{x}^2$

**Alternative Formula** (computationally equivalent):

$$
m = \frac{M \sum_i x_i y_i - (\sum_i x_i)(\sum_i y_i)}{M \sum_i x_i^2 - (\sum_i x_i)^2}
$$

**Extracting Parameters**:

$$
D_f = \frac{1}{m}
$$

$$
k_f = r_p^{D_f} \cdot e^{-b \cdot D_f}
$$

### Error Analysis

**Residual Variance**:

$$
s^2 = \frac{SS_{res}}{M - 2} = \frac{\sum_i (y_i - \hat{y}_i)^2}{M - 2}
$$

where $\hat{y}_i = mx_i + b$ is the predicted value and $(M-2)$ accounts for 2 estimated parameters.

**Standard Error of Slope**:

$$
SE_m = \sqrt{\frac{s^2}{S_{xx}}} = \sqrt{\frac{SS_{res}/(M-2)}{\sum_i (x_i - \bar{x})^2}}
$$

**Standard Error of Intercept**:

$$
SE_b = SE_m \cdot \sqrt{\frac{\sum_i x_i^2}{M}}
$$

**Standard Error of $D_f$**:

Using error propagation for $D_f = 1/m$:

$$
SE_{D_f} = \left|\frac{\partial D_f}{\partial m}\right| \cdot SE_m = \frac{1}{m^2} \cdot SE_m = D_f^2 \cdot SE_m
$$

**Confidence Interval for $D_f$** (95%):

$$
D_f \pm t_{0.975, M-2} \cdot SE_{D_f}
$$

where $t_{0.975, M-2}$ is the critical value of the t-distribution.

### Coefficient of Determination ($R^2$)

**Definition**:

$$
R^2 = 1 - \frac{SS_{res}}{SS_{tot}}
$$

where:

$$
SS_{res} = \sum_i (y_i - \hat{y}_i)^2 \quad \text{(residual sum of squares)}
$$

$$
SS_{tot} = \sum_i (y_i - \bar{y})^2 \quad \text{(total sum of squares)}
$$

**Interpretation**:
- $R^2 = 1$: Perfect linear fit
- $R^2 > 0.99$: Excellent fit, reliable $D_f$ estimate
- $R^2 \in [0.95, 0.99]$: Good fit
- $R^2 < 0.95$: Poor fit, suspect non-fractal behavior

**Alternative Calculation**:

$$
R^2 = \frac{S_{xy}^2}{S_{xx} \cdot S_{yy}}
$$

### Data Filtering Criteria

For reliable $D_f$ estimation, apply filters:

1. **Minimum Particle Count**: $N > N_{min}$ (typically 10-20)
   - Rationale: Statistical significance requires sufficient particles
   - Small N shows discrete effects, not fractal scaling

2. **Positive $R_g$**: Exclude points with $R_g \leq 0$
   - Can occur with single particle or numerical issues

3. **Outlier Rejection**: Remove points with standardized residual $> 3$
   - Indicates non-fractal behavior or errors

4. **Finite Values**: Exclude NaN, Inf from logarithms

### Weighted Least Squares

For heteroscedastic data (variance depends on $N$), use weighted regression:

**Weights**: $w_i \propto 1/\sigma_i^2$ where $\sigma_i$ is the uncertainty at point $i$.

For simulation data, larger clusters have lower relative uncertainty:

$$
w_i = N_i \quad \text{or} \quad w_i = \ln(N_i)
$$

**Weighted Formulas**:

$$
m = \frac{\sum_i w_i (x_i - \bar{x}_w)(y_i - \bar{y}_w)}{\sum_i w_i (x_i - \bar{x}_w)^2}
$$

where weighted means:

$$
\bar{x}_w = \frac{\sum_i w_i x_i}{\sum_i w_i}
$$

## 4.3 Box-Counting Method: Theory

### Fundamental Concept

The box-counting dimension is defined as:

$$
D_f = \lim_{s \to 0} \frac{\log N(s)}{\log(1/s)}
$$

where $N(s)$ is the minimum number of boxes of side $s$ needed to cover the set.

### Practical Algorithm

For discrete data:

1. Cover space with grid of boxes of side length $s$
2. Count non-empty boxes $N(s)$
3. Repeat for multiple scales $s_k$
4. Estimate $D_f$ from slope of $\log N(s)$ vs $\log(1/s)$

**Mathematical Basis**:

For a fractal set:

$$
N(s) \propto s^{-D_f}
$$

Taking logarithms:

$$
\log N(s) = -D_f \log(s) + C = D_f \log(1/s) + C
$$

The slope of $\log N(s)$ vs $\log(1/s)$ equals $D_f$.

### Scale Selection

**Minimum Scale** ($s_{min}$):
- 2D images: Limited by pixel resolution
- 3D point clouds: Related to point density or particle size

$$
s_{min} \gtrsim r_p \quad \text{(primary particle scale)}
$$

**Maximum Scale** ($s_{max}$):
- Limited by object extent

$$
s_{max} \lesssim R_g / 2 \quad \text{(aggregate scale)}
$$

**Scale Sequence**:

Use geometric (logarithmic) spacing for even sampling in log-log space:

$$
s_k = s_{min} \cdot 2^k \quad \text{for } k = 0, 1, 2, \ldots, K
$$

where $K = \lfloor \log_2(s_{max}/s_{min}) \rfloor$.

## 4.4 3D Box-Counting with Morton Codes

### Motivation

Naive 3D box-counting has complexity O(N) per scale for counting occupied boxes. With L scales, total complexity is O(N * L). Morton codes enable O(N log N) total complexity.

### Morton Codes (Z-Order Curves)

Morton codes interleave the bits of 3D coordinates to create a 1D index that preserves spatial locality.

**Bit Interleaving**:

For coordinates $(x, y, z)$ with $b$ bits each:

$$
x = x_{b-1} x_{b-2} \ldots x_1 x_0 \quad \text{(binary)}
$$

$$
y = y_{b-1} y_{b-2} \ldots y_1 y_0
$$

$$
z = z_{b-1} z_{b-2} \ldots z_1 z_0
$$

Morton code:

$$
M = z_{b-1} y_{b-1} x_{b-1} \, z_{b-2} y_{b-2} x_{b-2} \, \ldots \, z_0 y_0 x_0
$$

**Example** (3-bit coordinates):

$$
x = 5 = 101_2
$$

$$
y = 3 = 011_2
$$

$$
z = 2 = 010_2
$$

Interleaving:

| Position | z bit | y bit | x bit |
|----------|-------|-------|-------|
| 2 | 0 | 0 | 1 |
| 1 | 1 | 1 | 0 |
| 0 | 0 | 1 | 1 |

Morton code: $001 \, 110 \, 011_2 = 0001\,1001\,1_2 = 51_{10}$

### Key Property: Scale Masking

Points in the same box at scale $k$ have identical Morton code prefixes:

**Mask for Scale $k$** (box size $2^k$):

$$
\text{mask}(k) = \sim\left((1 \ll 3k) - 1\right)
$$

This zeros out the lowest $3k$ bits (k bits per dimension).

**Example**:
- Scale $k=1$ (box size 2): mask zeros bits 0,1,2
- Scale $k=2$ (box size 4): mask zeros bits 0-5
- Points with same masked code are in same box

### Algorithm with Morton Codes

**Step 1: Normalization**

Map coordinates to discrete grid $[0, 2^{precision})$:

$$
x_{norm} = \left\lfloor \frac{x - x_{min}}{x_{max} - x_{min}} \cdot (2^{precision} - 1) \right\rfloor
$$

**Step 2: Compute Morton Codes**

For each normalized point $(x_n, y_n, z_n)$:

$$
M = \text{morton\_encode}(x_n, y_n, z_n)
$$

**Step 3: Sort Codes**

Sort the array of Morton codes. This brings spatially proximate points together.

**Step 4: Count Unique Boxes at Each Scale**

For each scale $k$:

$$
\text{count}[k] = \text{count\_unique\_masked}(\text{sorted\_codes}, \text{mask}(k))
$$

With sorted codes, this is O(N) per scale:

```
function count_unique_masked(sorted_codes, mask):
    count = 0
    prev = null

    for code in sorted_codes:
        masked = code AND mask
        if masked != prev:
            count += 1
            prev = masked

    return count
```

**Step 5: Linear Regression**

Fit:

$$
\log_2(\text{count}[k]) = D_f \cdot k + b
$$

**Complexity Analysis**:

- Normalization: O(N)
- Morton encoding: O(N)
- Sorting: O(N log N) - **dominates**
- Counting (all scales): O(N * L) where L = precision
- Total: **O(N log N + N * L) = O(N log N)** (assuming L = O(log N))

### Morton Code Implementation

**Bit Interleaving Function**:

```
function morton_encode_3d(x: u64, y: u64, z: u64) -> u64:
    code = 0
    for bit in 0..21:  // 21 bits per dimension = 63-bit code
        code |= ((x >> bit) & 1) << (3 * bit)
        code |= ((y >> bit) & 1) << (3 * bit + 1)
        code |= ((z >> bit) & 1) << (3 * bit + 2)
    return code
```

**Optimized Using Magic Bits** (faster constant-time expansion):

```
function part_1_by_2(n: u64) -> u64:
    n = (n | (n << 16)) & 0x030000FF
    n = (n | (n <<  8)) & 0x0300F00F
    n = (n | (n <<  4)) & 0x030C30C3
    n = (n | (n <<  2)) & 0x09249249
    return n

function morton_encode_3d_fast(x: u64, y: u64, z: u64) -> u64:
    return part_1_by_2(x) | (part_1_by_2(y) << 1) | (part_1_by_2(z) << 2)
```

## 4.5 Linear Region Selection

### The Problem

Box-counting exhibits different behavior at extreme scales:

**Small Scales** ($s < r_p$):
- Resolution limit: cannot distinguish sub-particle detail
- Saturation: $N(s) \approx$ number of surface points sampled
- Dimension appears ~2 (surface dimension) or higher

**Large Scales** ($s > R_g$):
- Object extent limit: entire aggregate in one box
- $N(s) = 1$ (constant)
- No useful dimension information

**Intermediate Scales** ($r_p < s < R_g$):
- True fractal scaling region
- Linear behavior in log-log plot

### Automatic Linear Region Detection

**Method 1: Residual Analysis**

1. Perform global linear fit across all scales
2. Calculate residuals: $r_k = |\log N_k - (\hat{D}_f \cdot k + \hat{b})|$
3. Identify region where $|r_k| < \text{threshold}$

**Method 2: Local Slope Analysis**

1. Calculate local slopes: $D_f^{local}(k) = \frac{\log N_{k+1} - \log N_k}{\log s_k - \log s_{k+1}}$
2. Find region where local slope is approximately constant
3. Use running mean/variance of local slopes

**Method 3: Iterative Refinement**

```
function find_linear_region(log_s, log_N):
    best_r2 = 0
    best_range = (0, len(log_s))

    for start in 0 to len(log_s) - min_points:
        for end in start + min_points to len(log_s):
            slope, intercept, r2 = linear_fit(log_s[start:end], log_N[start:end])

            if r2 > best_r2:
                best_r2 = r2
                best_range = (start, end)

    return best_range
```

### Quality Metrics

**$R^2$ Within Linear Region**:

$$
R^2_{linear} = 1 - \frac{\sum_{k \in \text{linear}} (\log N_k - \hat{y}_k)^2}{\sum_{k \in \text{linear}} (\log N_k - \overline{\log N})^2}
$$

**Confidence Interval**:

$$
D_f \pm t_{0.975, n-2} \cdot SE_{D_f}
$$

For typical analysis, require:
- $R^2 > 0.99$
- At least 5 points in linear region
- Linear region spans at least one decade of scale

## 4.6 Statistical Validation Methods

### Bootstrap Confidence Intervals

For robust error estimates:

1. Resample data points with replacement
2. Compute $D_f$ for each resample
3. Use percentiles of distribution as confidence interval

```
function bootstrap_df(data, n_resamples=1000):
    df_samples = []

    for i in 1 to n_resamples:
        resampled = sample_with_replacement(data, len(data))
        df_i = compute_df(resampled)
        df_samples.append(df_i)

    df_mean = mean(df_samples)
    df_ci_low = percentile(df_samples, 2.5)
    df_ci_high = percentile(df_samples, 97.5)

    return df_mean, (df_ci_low, df_ci_high)
```

### Cross-Validation for Linear Region

Use leave-one-out or k-fold cross-validation to assess stability:

```
function cross_validate_df(data, k=5):
    fold_dfs = []

    for fold in split_k_folds(data, k):
        training = data \ fold
        df_fold = compute_df(training)
        fold_dfs.append(df_fold)

    cv_mean = mean(fold_dfs)
    cv_std = std(fold_dfs)

    return cv_mean, cv_std
```

### Comparison of Methods

For validation, compute $D_f$ using multiple methods and compare:

| Method | $D_f$ | $SE_{D_f}$ | $R^2$ |
|--------|-------|------------|-------|
| $R_g$ vs $N$ | 1.82 | 0.03 | 0.998 |
| 3D Box-counting | 1.79 | 0.05 | 0.995 |
| Correlation dimension | 1.80 | 0.04 | - |

Agreement within uncertainties indicates reliable measurement.

## 4.7 Sampling Strategies for Box-Counting

### Point Cloud Generation from Spheres

For 3D agglomerates represented as spheres, generate surface points:

**Uniform Surface Sampling**:

For each particle:

```
function sample_sphere_surface(center, radius, n_points):
    points = []

    for i in 1 to n_points:
        u = uniform(-1, 1)
        theta = uniform(0, 2*pi)

        x = center.x + radius * sqrt(1 - u^2) * cos(theta)
        y = center.y + radius * sqrt(1 - u^2) * sin(theta)
        z = center.z + radius * u

        points.append((x, y, z))

    return points
```

**Points Per Sphere**: Trade-off between accuracy and computation

| Points/Sphere | Accuracy | Memory | Time |
|---------------|----------|--------|------|
| 10-20 | Low | Low | Fast |
| 50-100 | Medium | Medium | Medium |
| 200-500 | High | High | Slow |

Recommendation: 100 points per sphere for typical analysis.

### Volume vs Surface Sampling

**Surface Sampling** (default):
- Points only on sphere surfaces
- $N(s) \propto s^{-D_f}$ for fractal surfaces

**Volume Sampling**:
- Points throughout sphere volumes
- More points, but includes interior (always $D=3$ for filled spheres)
- May bias toward $D_f = 3$

For fractal agglomerates, **surface sampling** is preferred as it captures the fractal structure.

## 4.8 Error Sources and Mitigation

### Finite Size Effects

**Problem**: Small agglomerates show discretization effects.

**Manifestation**: $D_f$ estimates vary strongly with $N$, power law doesn't hold.

**Mitigation**:
- Require $N > 100$ particles
- Verify $R^2 > 0.95$
- Check that local slope is constant

### Lacunarity Effects

**Problem**: Fractals with same $D_f$ can have different textures (lacunarity).

**Manifestation**: Oscillations in log-log plot around the linear trend.

**Mitigation**:
- Use larger scale range
- Average over multiple random realizations
- Report lacunarity as separate parameter

### Anisotropy

**Problem**: Anisotropic structures have direction-dependent dimension.

**Manifestation**: Different $D_f$ from different projection directions.

**Mitigation**:
- Compute spherical average for 3D analysis
- Report anisotropy separately (from inertia tensor)
- For 2D, use orientation-averaged projection

### Polydispersity

**Problem**: Variable particle sizes affect $R_g$ calculation.

**Manifestation**: Deviation from simple power law at small $N$.

**Mitigation**:
- Use mass-weighted quantities
- Include self-moment contribution (3/5 factor)
- Model explicit polydispersity effects

### Numerical Precision

**Problem**: Logarithm of very small or zero values causes errors.

**Manifestation**: NaN or Inf in calculations.

**Mitigation**:
- Filter $R_g > \epsilon$ (small positive threshold)
- Use stable algorithms for variance/covariance
- Check for overflow in Morton codes (limit precision)

## 4.9 Summary

### Method Selection Guidelines

| Situation | Recommended Method | Rationale |
|-----------|-------------------|-----------|
| During simulation | $R_g$ vs $N$ regression | Direct, O(N), tracks growth |
| Final structure analysis | 3D box-counting | Uses final geometry |
| TEM/SEM images | 2D box-counting or FRAKTAL | Handles projections |
| Ensemble statistics | Multiple methods | Cross-validation |

### Best Practices

1. **Report uncertainty**: Always provide $SE_{D_f}$ or confidence intervals
2. **State method**: Box-counting, regression, or other
3. **Specify scale range**: Report $s_{min}$, $s_{max}$ used
4. **Verify assumptions**: Check $R^2$, linearity, scale range
5. **Compare methods**: Agreement indicates reliability

### Key Formulas

| Quantity | Formula |
|----------|---------|
| Fractal dimension (regression) | $D_f = 1/m$ where $m = d\ln(R_g)/d\ln(N)$ |
| Standard error of $D_f$ | $SE_{D_f} = D_f^2 \cdot SE_m$ |
| Fractal prefactor | $k_f = e^{-b \cdot D_f} \cdot r_p^{D_f}$ |
| Box-counting dimension | $D_f = d\log N(s) / d\log(1/s)$ |
| Morton code (3D) | $M = \text{interleave}(x, y, z)$ |
| Scale mask | $\text{mask}(k) = \sim((1 \ll 3k) - 1)$ |
