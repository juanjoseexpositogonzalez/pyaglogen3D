# Chapter 3: Computational Geometry

## 3.1 Radius of Gyration: Complete Theory

### Definition and Physical Meaning

The radius of gyration $R_g$ characterizes the spatial extent of an agglomerate. It represents the root-mean-square distance of mass from the center of mass, providing a single scalar measure of aggregate size that accounts for mass distribution.

**Physical Analogy**: Think of $R_g$ as the "effective radius" at which all the mass could be concentrated (in a thin shell) while maintaining the same moment of inertia as the original distribution.

$$
R_g = \sqrt{\frac{I_p}{m_p}}
$$

where:
- $I_p$ = moment of inertia about the center of mass
- $m_p$ = total mass

### Derivation for Point Masses

For $N$ point masses $m_i$ at positions $\vec{r}_i$:

**Step 1: Center of Mass**

$$
\vec{r}_{cm} = \frac{\sum_{i=1}^{N} m_i \vec{r}_i}{\sum_{i=1}^{N} m_i} = \frac{1}{M} \sum_{i=1}^{N} m_i \vec{r}_i
$$

where $M = \sum_i m_i$ is the total mass.

**Step 2: Distances from Center of Mass**

$$
d_i = |\vec{r}_i - \vec{r}_{cm}|
$$

**Step 3: Moment of Inertia (Point Masses)**

$$
I_p = \sum_{i=1}^{N} m_i d_i^2
$$

**Step 4: Radius of Gyration**

$$
R_g^2 = \frac{I_p}{M} = \frac{\sum_{i=1}^{N} m_i d_i^2}{\sum_{i=1}^{N} m_i}
$$

This is the mass-weighted mean square distance from the center of mass.

### Extension to Finite-Size Spheres: The 3/5 Factor

For spherical particles with radius $r_{p,i}$ (not point masses), each particle has its own internal moment of inertia that must be included.

**Moment of Inertia of a Uniform Sphere**:

For a solid sphere of radius $r$ and mass $m$ about an axis through its center:

$$
I_{sphere} = \frac{2}{5} m r^2
$$

**Derivation**:

Using spherical coordinates with density $\rho$:

$$
I = \int_V \rho \cdot r_\perp^2 \, dV
$$

where $r_\perp$ is the perpendicular distance to the rotation axis. For rotation about the z-axis:

$$
r_\perp^2 = x^2 + y^2 = r^2 \sin^2\theta
$$

$$
I = \rho \int_0^R \int_0^\pi \int_0^{2\pi} (r^2 \sin^2\theta) \cdot r^2 \sin\theta \, d\phi \, d\theta \, dr
$$

$$
= 2\pi\rho \int_0^R r^4 dr \int_0^\pi \sin^3\theta \, d\theta
$$

Using $\int_0^\pi \sin^3\theta \, d\theta = 4/3$:

$$
I = 2\pi\rho \cdot \frac{R^5}{5} \cdot \frac{4}{3} = \frac{8\pi\rho R^5}{15}
$$

Since $m = \frac{4}{3}\pi\rho R^3$:

$$
I = \frac{2}{5} m R^2
$$

**Contribution to $R_g^2$: The Self-Moment**

For a uniform sphere, the mean square distance of mass from the center is:

$$
\langle r^2 \rangle_{sphere} = \frac{\int_0^R r^2 \cdot 4\pi r^2 \rho \, dr}{\frac{4}{3}\pi R^3 \rho} = \frac{\int_0^R r^4 dr}{\frac{R^3}{3}} = \frac{R^5/5}{R^3/3} = \frac{3R^2}{5}
$$

This gives the **3/5 factor** for the internal contribution.

### Complete $R_g$ Formula for Spherical Particles

**Parallel Axis Theorem**: The total moment about the center of mass includes:
1. Self-moment of each sphere about its own center
2. Contribution from the displacement of each sphere from the aggregate center

$$
I_p = \sum_{i=1}^{N} \left[I_{self,i} + m_i d_i^2\right]
$$

For spheres with mass proportional to volume ($m_i \propto r_{p,i}^3$):

$$
I_{self,i} = \frac{2}{5} m_i r_{p,i}^2 = \frac{2}{5} r_{p,i}^3 \cdot r_{p,i}^2 = \frac{2}{5} r_{p,i}^5
$$

Using the alternative normalization where we track mean square distance:

$$
R_g^2 = \frac{\sum_{i=1}^{N} \left[\frac{3}{5}r_{p,i}^5 + r_{p,i}^3 d_i^2\right]}{\sum_{i=1}^{N} r_{p,i}^3}
$$

**Note**: The switch from $2/5$ to $3/5$ depends on whether we're computing moment of inertia about an axis (2/5) or mean square distance from a point (3/5). For gyration radius, we need the latter.

### Monodisperse Simplification

When all particles have the same radius $r_p$:

$$
R_g^2 = \frac{N \cdot \frac{3}{5}r_p^5 + r_p^3 \sum_{i=1}^{N} d_i^2}{N \cdot r_p^3}
$$

$$
R_g^2 = \frac{3}{5}r_p^2 + \frac{1}{N}\sum_{i=1}^{N} d_i^2
$$

The first term is the **internal contribution** (self-moment).
The second term is the **variance of particle positions** (external contribution).

For large aggregates ($N >> 1$), the external term dominates.

### Alternative Representations

**Tensor Form**:

The gyration tensor is defined as:

$$
\mathbf{S} = \frac{1}{M} \sum_i m_i (\vec{r}_i - \vec{r}_{cm}) \otimes (\vec{r}_i - \vec{r}_{cm})
$$

The radius of gyration squared is:

$$
R_g^2 = \text{Tr}(\mathbf{S}) = S_{xx} + S_{yy} + S_{zz}
$$

**Matrix Elements**:

$$
S_{\alpha\beta} = \frac{1}{M} \sum_i m_i (r_{i,\alpha} - r_{cm,\alpha})(r_{i,\beta} - r_{cm,\beta})
$$

where $\alpha, \beta \in \{x, y, z\}$.

### Incremental Update Algorithm

Instead of recalculating $R_g$ from scratch after each particle addition (O(N) per particle = O(N^2) total), use incremental updates:

**After adding particle at position $\vec{r}_{new}$ with mass $m_{new}$:**

$$
M_{new} = M_{old} + m_{new}
$$

$$
\vec{r}_{cm,new} = \frac{M_{old} \cdot \vec{r}_{cm,old} + m_{new} \cdot \vec{r}_{new}}{M_{new}}
$$

$$
\Delta \vec{r}_{cm} = \vec{r}_{cm,new} - \vec{r}_{cm,old}
$$

For the sum of squared distances, use the parallel axis theorem:

$$
\sum_i m_i d_{i,new}^2 = \sum_i m_i d_{i,old}^2 + M_{old} |\Delta \vec{r}_{cm}|^2 + m_{new} |\vec{r}_{new} - \vec{r}_{cm,new}|^2
$$

This reduces complexity to **O(1) per particle = O(N) total**.

## 3.2 Inertia Tensor: Complete Theory

### Definition

The inertia tensor $\mathbf{I}$ describes the rotational properties of the agglomerate. It is a symmetric 3x3 matrix:

$$
\mathbf{I} = \begin{pmatrix}
I_{xx} & I_{xy} & I_{xz} \\
I_{xy} & I_{yy} & I_{yz} \\
I_{xz} & I_{yz} & I_{zz}
\end{pmatrix}
$$

### Component Definitions

For point masses (or treating spheres as point masses at their centers), relative to the center of mass:

**Diagonal elements (moments of inertia about principal planes)**:

$$
I_{xx} = \sum_i m_i (y_i^2 + z_i^2)
$$

$$
I_{yy} = \sum_i m_i (x_i^2 + z_i^2)
$$

$$
I_{zz} = \sum_i m_i (x_i^2 + y_i^2)
$$

**Off-diagonal elements (products of inertia)**:

$$
I_{xy} = -\sum_i m_i x_i y_i
$$

$$
I_{xz} = -\sum_i m_i x_i z_i
$$

$$
I_{yz} = -\sum_i m_i y_i z_i
$$

where $(x_i, y_i, z_i) = \vec{r}_i - \vec{r}_{cm}$ are coordinates relative to the center of mass.

**Note**: The negative signs on off-diagonal elements follow the standard physics convention. Some texts use positive signs; consistency is key.

### Including Sphere Self-Moments

For finite-size spheres, add the self-moment contribution to diagonal elements:

$$
I_{xx}^{total} = \sum_i \left[m_i(y_i^2 + z_i^2) + \frac{2}{5}m_i r_{p,i}^2\right]
$$

Similarly for $I_{yy}$ and $I_{zz}$.

Off-diagonal elements are unchanged (spheres contribute zero to products of inertia about their own centers due to symmetry).

### Eigendecomposition

The inertia tensor is real and symmetric, guaranteeing:
1. Real eigenvalues (principal moments)
2. Orthogonal eigenvectors (principal axes)

**Diagonalization**:

$$
\mathbf{I} = \mathbf{Q} \boldsymbol{\Lambda} \mathbf{Q}^T
$$

where:
- $\boldsymbol{\Lambda} = \text{diag}(I_1, I_2, I_3)$ with $I_1 \leq I_2 \leq I_3$ (sorted principal moments)
- $\mathbf{Q} = [\vec{e}_1, \vec{e}_2, \vec{e}_3]$ columns are orthonormal principal axes

**Physical Interpretation**:
- $I_1$ (smallest): Moment about axis of greatest elongation
- $I_3$ (largest): Moment about axis of greatest compression
- Principal axes define the natural coordinate system of the object

### Analytical Solution for 3x3 Symmetric Matrix

For numerical implementation, direct eigendecomposition using cubic formula (Cardano's method) is more efficient than iterative methods for 3x3:

**Characteristic Polynomial**:

$$
\det(\mathbf{I} - \lambda \mathbf{E}) = -\lambda^3 + c_2\lambda^2 - c_1\lambda + c_0 = 0
$$

where:

$$
c_0 = \det(\mathbf{I})
$$

$$
c_1 = I_{xx}I_{yy} + I_{xx}I_{zz} + I_{yy}I_{zz} - I_{xy}^2 - I_{xz}^2 - I_{yz}^2
$$

$$
c_2 = \text{Tr}(\mathbf{I}) = I_{xx} + I_{yy} + I_{zz}
$$

**Cardano's Solution**:

Substitute $\lambda = \mu + c_2/3$ to eliminate quadratic term, then solve the depressed cubic.

## 3.3 Shape Descriptors from Principal Moments

### Anisotropy

$$
A = \frac{I_3}{I_1}
$$

Measures the ratio of maximum to minimum principal moments.

| $A$ Value | Shape Interpretation |
|-----------|---------------------|
| $A = 1$ | Isotropic (spherical symmetry) |
| $1 < A < 2$ | Slightly elongated |
| $2 \leq A < 5$ | Moderately elongated |
| $A \geq 5$ | Highly anisotropic (rod-like or disk-like) |

**For Ideal Shapes**:
- Sphere: $A = 1$
- Cube: $A = 1$
- Linear chain of $N$ spheres: $A \approx N^2/12$ (grows quadratically)
- Thin disk (radius $R$, thickness $t$): $A \approx (R/t)^2$

### Asphericity

$$
b = \frac{I_3 - \frac{1}{2}(I_1 + I_2)}{I_1 + I_2 + I_3}
$$

Measures deviation from spherical symmetry (equal $I_1 = I_2 = I_3$).

**Range**: $0 \leq b < 1$

| $b$ Value | Shape |
|-----------|-------|
| $b = 0$ | Spherically symmetric ($I_1 = I_2 = I_3$) |
| $0 < b < 0.25$ | Nearly spherical |
| $b > 0.25$ | Significantly aspherical |
| $b \to 1$ | Maximally aspherical (linear) |

**Derivation**:

For a sphere: $I_1 = I_2 = I_3 = I$

$$
b = \frac{I - \frac{1}{2}(I + I)}{3I} = \frac{I - I}{3I} = 0
$$

For a linear chain along z-axis: $I_1 = I_2 = 0$, $I_3 = I$

$$
b = \frac{I - \frac{1}{2}(0 + 0)}{0 + 0 + I} = 1
$$

(In practice, $I_1, I_2 > 0$ due to finite particle size)

### Acylindricity

$$
c = \frac{I_2 - I_1}{I_1 + I_2 + I_3}
$$

Measures deviation from cylindrical symmetry (where $I_1 = I_2$).

**Range**: $0 \leq c < 1/2$

| $c$ Value | Shape |
|-----------|-------|
| $c = 0$ | Cylindrically symmetric ($I_1 = I_2$) |
| $c > 0.05$ | Significant departure from cylindrical |

**Examples**:
- Sphere: $c = 0$ (also cylindrical about any axis)
- Cylinder: $c = 0$
- Ellipsoid with three distinct axes: $c > 0$
- Flat ribbon: $c$ large

### Relative Shape Anisotropy (Alternative)

$$
\kappa^2 = \frac{3(I_1^2 + I_2^2 + I_3^2)}{(I_1 + I_2 + I_3)^2} - 1
$$

**Range**: $0 \leq \kappa^2 \leq 1$

| $\kappa^2$ Value | Shape |
|------------------|-------|
| $\kappa^2 = 0$ | Sphere |
| $\kappa^2 = 0.25$ | Uniform disk |
| $\kappa^2 = 1$ | Linear (all mass on one axis) |

This measure is particularly useful for polymer physics.

### Combined Shape Classification

| Shape | $A$ | $b$ | $c$ |
|-------|-----|-----|-----|
| Sphere | 1 | 0 | 0 |
| Prolate ellipsoid (cigar) | >1 | >0 | $\approx 0$ |
| Oblate ellipsoid (disk) | >1 | >0 | >0 |
| Triaxial ellipsoid | >1 | >0 | >0 |
| Linear chain | >>1 | $\to 1$ | $\approx 0$ |

## 3.4 Spatial Hashing Algorithm

### Purpose

Spatial hashing accelerates neighbor queries from O(N) to O(1) average case, critical for:
- Collision detection during aggregation
- Contact counting for coordination number
- Box-counting at fine scales

### Data Structure

A hash map with 3D integer cell coordinates as keys:

$$
\text{HashMap}\langle (i_x, i_y, i_z), \text{Vec}\langle \text{particle\_idx} \rangle \rangle
$$

### Cell Size Selection

The cell size must be large enough that particles in non-adjacent cells cannot touch:

$$
\text{cell\_size} = 2 \times (r_{max} + r_{max}) = 4 r_{max}
$$

For particles of maximum radius $r_{max}$, two particles can touch if their centers are within $2r_{max}$. A cell of size $4r_{max}$ ensures that only the 27 adjacent cells (including the cell itself) need to be checked.

**Optimal Cell Size**:

Trade-off between:
- **Too small**: Many cells to check (27 * many cells per dimension)
- **Too large**: Many particles per cell (all particles in one cell = O(N) queries)

Optimal when average occupancy $\approx 1$ particle per cell.

### Hash Function Implementation

**Cell Coordinates from Position**:

$$
i_x = \lfloor x / \text{cell\_size} \rfloor
$$

$$
i_y = \lfloor y / \text{cell\_size} \rfloor
$$

$$
i_z = \lfloor z / \text{cell\_size} \rfloor
$$

**Cell Key**: The tuple $(i_x, i_y, i_z)$ directly as hash key.

For languages without tuple hashing, use spatial hash:

$$
\text{hash} = (i_x \cdot p_1) \oplus (i_y \cdot p_2) \oplus (i_z \cdot p_3)
$$

where $p_1, p_2, p_3$ are large primes (e.g., 73856093, 19349663, 83492791) and $\oplus$ is XOR.

### Neighbor Query Algorithm

```
function query_neighbors(position, query_radius):
    cell = get_cell(position)
    neighbors = []

    for dx in [-1, 0, 1]:
        for dy in [-1, 0, 1]:
            for dz in [-1, 0, 1]:
                neighbor_cell = (cell.x + dx, cell.y + dy, cell.z + dz)

                if neighbor_cell in hash_map:
                    for particle_idx in hash_map[neighbor_cell]:
                        if distance(position, particles[particle_idx].position) <= query_radius:
                            neighbors.append(particle_idx)

    return neighbors
```

### Complexity Analysis

**Assumptions**:
- $N$ particles
- Uniform distribution
- Cell size $s$
- Bounding box volume $V$

**Number of cells**: $M \approx V / s^3$

**Average particles per cell**: $k = N/M$

**Operations**:

| Operation | Complexity | Notes |
|-----------|------------|-------|
| Insert | O(1) average | Hash table insertion |
| Remove | O(k) worst case | Find in cell's list |
| Query | O(27k) = O(k) | Check 27 cells |
| Rebuild | O(N) | After many changes |

**Overall**: Neighbor queries are O(1) average when $k = O(1)$, i.e., when cell size is tuned appropriately.

### Dynamic Resizing

When particle density changes significantly (e.g., during cluster merging), resize:

```
if total_particles / num_cells > threshold:
    new_cell_size = cell_size / 2  # Finer grid
    rebuild_hash()
```

## 3.5 Collision Detection Mathematics

### Sphere-Sphere Intersection Test

Two spheres with centers $\vec{c}_1, \vec{c}_2$ and radii $r_1, r_2$:

**Distance Calculation**:

$$
d = |\vec{c}_1 - \vec{c}_2| = \sqrt{(x_1-x_2)^2 + (y_1-y_2)^2 + (z_1-z_2)^2}
$$

**Intersection Conditions**:

| Condition | Relationship | Geometric Meaning |
|-----------|--------------|-------------------|
| $d < r_1 + r_2$ | Overlap | Spheres interpenetrate |
| $d = r_1 + r_2$ | Tangent | Spheres touch at one point |
| $d > r_1 + r_2$ | Separated | No intersection |
| $d < |r_1 - r_2|$ | Contained | Smaller inside larger |

### Optimized Distance Comparison

Avoid square root when only comparing to threshold:

```
distance_squared = (x1-x2)^2 + (y1-y2)^2 + (z1-z2)^2
threshold_squared = (r1 + r2)^2

collision = distance_squared <= threshold_squared
```

### With Sintering Coefficient

The contact threshold incorporates sintering:

$$
d_{contact} = c_s \cdot (r_1 + r_2)
$$

**Collision test**:

$$
|\vec{c}_1 - \vec{c}_2| \leq c_s \cdot (r_1 + r_2)
$$

### Contact Point Calculation

When spheres touch, the contact point lies on the line connecting centers:

$$
\vec{p}_{contact} = \vec{c}_1 + \frac{r_1}{r_1 + r_2}(\vec{c}_2 - \vec{c}_1)
$$

### Contact Normal

The normal vector at contact (pointing from sphere 1 to sphere 2):

$$
\hat{n} = \frac{\vec{c}_2 - \vec{c}_1}{|\vec{c}_2 - \vec{c}_1|}
$$

### Overlap Resolution

If spheres overlap (e.g., due to numerical error), resolve by moving along contact normal:

$$
\text{overlap} = (r_1 + r_2) - d
$$

$$
\vec{c}_1' = \vec{c}_1 - \frac{\text{overlap}}{2} \hat{n}
$$

$$
\vec{c}_2' = \vec{c}_2 + \frac{\text{overlap}}{2} \hat{n}
$$

## 3.6 2D Projection Mathematics

### Orthographic Projection

For visualization and image analysis, we project 3D coordinates onto a 2D plane. Orthographic projection preserves parallel lines and relative distances in the projection plane.

### Rotation Matrices

**Azimuth Rotation** (around Z-axis by angle $\alpha$):

$$
\mathbf{R}_z(\alpha) = \begin{pmatrix}
\cos\alpha & -\sin\alpha & 0 \\
\sin\alpha & \cos\alpha & 0 \\
0 & 0 & 1
\end{pmatrix}
$$

**Elevation Rotation** (around X-axis by angle $\beta$):

$$
\mathbf{R}_x(\beta) = \begin{pmatrix}
1 & 0 & 0 \\
0 & \cos\beta & -\sin\beta \\
0 & \sin\beta & \cos\beta
\end{pmatrix}
$$

**Combined Rotation** (first azimuth, then elevation):

$$
\mathbf{R} = \mathbf{R}_x(\beta) \cdot \mathbf{R}_z(\alpha)
$$

Expanded:

$$
\mathbf{R} = \begin{pmatrix}
\cos\alpha & -\sin\alpha & 0 \\
\sin\alpha\cos\beta & \cos\alpha\cos\beta & -\sin\beta \\
\sin\alpha\sin\beta & \cos\alpha\sin\beta & \cos\beta
\end{pmatrix}
$$

### Projection Operation

For a point $\vec{p} = (x, y, z)^T$:

$$
\vec{p}' = \mathbf{R} \cdot \vec{p} = \begin{pmatrix} x' \\ y' \\ z' \end{pmatrix}
$$

The 2D projected coordinates are $(x', y')$.

The depth $z'$ is used for:
- Z-ordering (painter's algorithm)
- Depth-based coloring
- Occlusion testing

### Projected Properties

**Projected Radius**:

For orthographic projection of a sphere, the projected radius equals the 3D radius:

$$
r_{projected} = r_{3D}
$$

(Unlike perspective projection where distant objects appear smaller)

**Projected Area of Sphere**:

$$
A_{projected} = \pi r^2
$$

**Projected Bounding Box**:

$$
x_{min} = \min_i(x'_i - r_i), \quad x_{max} = \max_i(x'_i + r_i)
$$

$$
y_{min} = \min_i(y'_i - r_i), \quad y_{max} = \max_i(y'_i + r_i)
$$

### View-Independent Properties

Some properties are independent of viewing direction:

**Orientation-Averaged Projected Area**:

For a convex body, the average projected area over all orientations equals 1/4 of surface area:

$$
\langle A_p \rangle = \frac{S}{4}
$$

For non-convex fractals, the relationship is more complex and depends on $D_f$.

### Standard Views

| View | $\alpha$ | $\beta$ | Description |
|------|----------|---------|-------------|
| Front | 0 | 0 | Looking along -Z |
| Side | 90 | 0 | Looking along -X |
| Top | 0 | 90 | Looking along -Y |
| Isometric | 45 | 35.264 | Equal foreshortening |

The isometric angle $\beta = \arctan(1/\sqrt{2}) \approx 35.264$ gives equal scaling along all three axes when projected.

## 3.7 Coordination Number Calculation

### Algorithm

```
function calculate_coordination(particles, sintering_coeff):
    coordination = array of zeros, length N
    contact_tolerance = 0.01 * min_radius

    for i in 0 to N-1:
        for j in i+1 to N-1:
            distance = |particles[i].position - particles[j].position|
            contact_distance = sintering_coeff * (particles[i].radius + particles[j].radius)

            if distance <= contact_distance + contact_tolerance:
                coordination[i] += 1
                coordination[j] += 1

    mean = sum(coordination) / N
    std = sqrt(sum((coordination - mean)^2) / N)

    return coordination, mean, std
```

### Optimized with Spatial Hashing

```
function calculate_coordination_fast(particles, spatial_hash, sintering_coeff):
    coordination = array of zeros, length N
    contact_tolerance = 0.01 * min_radius

    for i in 0 to N-1:
        neighbors = spatial_hash.query_neighbors(particles[i].position)

        for j in neighbors:
            if j > i:  # Avoid double counting
                distance = |particles[i].position - particles[j].position|
                contact_distance = sintering_coeff * (particles[i].radius + particles[j].radius)

                if distance <= contact_distance + contact_tolerance:
                    coordination[i] += 1
                    coordination[j] += 1

    return coordination
```

**Complexity**: O(N * k) where k is average neighbors per cell, typically O(N) total.

### Coordination Distribution Analysis

The distribution of coordination numbers provides structural information:

**Metrics**:
- Mean $\langle \eta \rangle$
- Standard deviation $\sigma_\eta$
- Mode (most common value)
- Maximum (highest coordination)

**Expected for Different Structures**:

| Structure | $\langle \eta \rangle$ | $\sigma_\eta$ | Mode |
|-----------|------------------------|---------------|------|
| Linear chain | 2 (exact) | 0 | 2 |
| Branched chain | 2.1 - 2.3 | 0.3 - 0.5 | 2 |
| Open aggregate (DLCA) | 2.2 - 2.5 | 0.5 - 0.8 | 2 |
| Dense aggregate | 3 - 5 | 1 - 2 | 3 or 4 |
| Random packing | 5 - 7 | 1 - 2 | 6 |

## 3.8 Summary of Computational Geometry

| Concept | Formula | Complexity | Notes |
|---------|---------|------------|-------|
| Center of mass | $\vec{r}_{cm} = \sum m_i\vec{r}_i / \sum m_i$ | O(N) | Single pass |
| Radius of gyration | $R_g = \sqrt{I_p/m_p}$ | O(N) | Include 3/5 factor |
| Incremental $R_g$ update | Via parallel axis theorem | O(1) | Per particle added |
| Inertia tensor | 6 unique components | O(N) | Symmetric matrix |
| Eigendecomposition | $\mathbf{I} = \mathbf{Q}\boldsymbol{\Lambda}\mathbf{Q}^T$ | O(1) | Analytical for 3x3 |
| Shape descriptors | $A$, $b$, $c$ from eigenvalues | O(1) | After eigendecomposition |
| Spatial hash query | Check 27 cells | O(k) average | k = particles per cell |
| Collision detection | $d \leq c_s(r_1 + r_2)$ | O(1) per pair | Avoid sqrt when possible |
| 2D projection | $\vec{p}' = \mathbf{R}\vec{p}$ | O(N) | Matrix multiplication |
| Coordination number | Count touching pairs | O(N) with hash | O(N^2) naive |

### Implementation Notes

1. **Numerical Stability**: Use Welford's algorithm for variance calculations; avoid catastrophic cancellation in distance calculations.

2. **Precision**: Use 64-bit floating point for coordinates; 32-bit can accumulate errors in large aggregates.

3. **Caching**: Store computed values (center of mass, $R_g$) and update incrementally when possible.

4. **Parallelization**: Shape descriptors and projections are embarrassingly parallel; spatial hashing requires care with concurrent updates.
