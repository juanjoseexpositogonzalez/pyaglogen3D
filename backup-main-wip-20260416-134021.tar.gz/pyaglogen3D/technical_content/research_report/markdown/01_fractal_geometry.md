# Chapter 1: Fractal Geometry Fundamentals

## 1.1 Introduction to Fractals

Fractal geometry provides the mathematical framework for describing objects that exhibit self-similarity across multiple scales. Unlike Euclidean geometry where dimension is always an integer (1D line, 2D plane, 3D volume), fractal objects possess non-integer dimensions that characterize their space-filling properties.

The term "fractal" was coined by Benoit Mandelbrot in 1975, derived from the Latin *fractus* meaning "broken" or "fractured." This nomenclature reflects the fragmented, irregular nature of these geometric structures that appear similar regardless of the scale at which they are examined.

### Historical Context

The mathematical foundations of fractal geometry predate Mandelbrot's formalization:

- **1883**: Georg Cantor's "dust" - a set with zero length but uncountably infinite points
- **1890**: Giuseppe Peano's space-filling curve - a 1D curve that fills a 2D plane
- **1904**: Helge von Koch's snowflake - infinite perimeter enclosing finite area
- **1915**: Waclaw Sierpinski's triangle and carpet
- **1918**: Felix Hausdorff's generalized dimension definition

These mathematical curiosities found physical relevance when researchers recognized that natural structures like coastlines, clouds, trees, and particle agglomerates exhibit similar self-similar scaling properties.

### Definition of Fractal Dimension

The fractal dimension $D_f$ quantifies how the "mass" (or number of constituent elements) scales with the characteristic length scale:

$$
N \propto L^{D_f}
$$

More precisely, for a set $S$ covered by $N(\epsilon)$ boxes of side length $\epsilon$, the box-counting dimension is:

$$
D_f = \lim_{\epsilon \to 0} \frac{\ln N(\epsilon)}{\ln(1/\epsilon)}
$$

For practical measurements with discrete data, this becomes a slope in log-log space.

### Physical Interpretation of $D_f$

| $D_f$ Value | Geometry | Structure | Physical Example |
|-------------|----------|-----------|------------------|
| $D_f \approx 1.0$ | Linear | Chain-like, 1D arrangement | Polymer chains |
| $D_f \approx 1.8$ | Open fractal | Typical soot agglomerates (DLA/CCA) | Flame-generated soot |
| $D_f \approx 2.0$ | Planar | Sheet-like, 2D arrangement | Graphene oxide sheets |
| $D_f \approx 2.5$ | Dense fractal | Moderately compacted | Restructured soot |
| $D_f \approx 3.0$ | Compact | Space-filling, solid sphere | Dense granular packing |

## 1.2 The Power Law Relationship

### Fundamental Derivation

For particle agglomerates composed of $N$ primary spherical particles with radius $r_p$:

$$
\boxed{N = k_f \left(\frac{R_g}{r_p}\right)^{D_f}}
$$

where:
- $N$ = Number of primary particles
- $k_f$ = Fractal prefactor (structure-dependent constant)
- $R_g$ = Radius of gyration (characteristic length)
- $r_p$ = Primary particle radius
- $D_f$ = Fractal dimension ($1 \leq D_f \leq 3$)

### Step-by-Step Derivation

**Step 1: Mass-Size Scaling**

Consider an agglomerate of characteristic size $L$. For a fractal structure, the mass (or equivalently, number of particles) within a sphere of radius $r$ centered at the center of mass scales as:

$$
N(r) = A \cdot r^{D_f}
$$

where $A$ is a proportionality constant with dimensions $[length]^{-D_f}$.

**Step 2: Characteristic Length Selection**

The radius of gyration $R_g$ serves as the characteristic length scale because it represents the root-mean-square distance of mass from the center of mass:

$$
R_g^2 = \frac{\sum_i m_i |\vec{r}_i - \vec{r}_{cm}|^2}{\sum_i m_i}
$$

At this characteristic scale:

$$
N = A \cdot R_g^{D_f}
$$

**Step 3: Non-Dimensionalization**

To make the equation dimensionally consistent and physically meaningful, we normalize by the primary particle radius $r_p$:

$$
N = k_f \left(\frac{R_g}{r_p}\right)^{D_f}
$$

where $k_f = A \cdot r_p^{D_f}$ absorbs the dimensional prefactor and becomes the dimensionless fractal prefactor.

**Step 4: Verification of Limiting Cases**

For a single particle ($N = 1$): The equation gives $R_g/r_p = k_f^{-1/D_f}$. For typical $k_f \approx 1$, we get $R_g \approx r_p$, consistent with the gyration radius of a sphere.

For a linear chain ($D_f = 1$): $N \propto R_g/r_p$, meaning radius grows linearly with particle count.

For solid packing ($D_f = 3$): $N \propto (R_g/r_p)^3$, giving the expected cubic scaling.

### Logarithmic Form

Taking the natural logarithm of the power law:

$$
\ln(N) = \ln(k_f) + D_f \cdot \ln\left(\frac{R_g}{r_p}\right)
$$

Rearranging to express $\ln(R_g)$ as a function of $\ln(N)$:

$$
\ln(R_g) = \frac{1}{D_f} \ln(N) - \frac{\ln(k_f)}{D_f} + \ln(r_p)
$$

This can be written as:

$$
\ln(R_g) = \frac{1}{D_f} \ln(N) + \frac{1}{D_f} \ln\left(k_f^{-1} \cdot r_p^{D_f}\right)
$$

Or more compactly:

$$
\ln(R_g) = \frac{1}{D_f} \ln(N) + \ln\left(\frac{r_p}{k_f^{1/D_f}}\right)
$$

This linear relationship in log-log space (with slope $1/D_f$) enables fractal dimension estimation through linear regression.

### Alternate Form: $R_g$ vs $N$

The power law can also be written as:

$$
R_g = r_p \cdot k_f^{-1/D_f} \cdot N^{1/D_f}
$$

Defining the effective prefactor $\alpha = r_p \cdot k_f^{-1/D_f}$:

$$
R_g = \alpha \cdot N^{1/D_f}
$$

## 1.3 Fractal Prefactor $k_f$

### Physical Meaning

The prefactor $k_f$ describes the local compactness of the agglomerate structure, independent of its overall size. It quantifies how efficiently particles pack within the characteristic radius.

**Intuitive Understanding**: Imagine two agglomerates with the same $R_g$ and $D_f$. The one with higher $k_f$ has more particles - it's locally denser while maintaining the same fractal scaling.

The prefactor relates to several structural properties:

1. **Local Coordination**: Higher $k_f$ indicates more neighbors per particle
2. **Overlap/Sintering**: Particle fusion increases effective $k_f$
3. **Structural Regularity**: Ordered arrangements yield higher $k_f$ than random ones
4. **Polydispersity**: Size distribution affects packing efficiency

### Derivation of $k_f$ Bounds

**Lower Bound**: For a linear chain ($D_f = 1$):

For $N$ touching spheres in a line, the gyration radius is:

$$
R_g^2 = \frac{1}{N} \sum_{i=0}^{N-1} (i \cdot 2r_p - \bar{x})^2
$$

where $\bar{x} = (N-1)r_p$ is the center of mass. For large $N$:

$$
R_g \approx \frac{N \cdot r_p}{\sqrt{3}}
$$

Thus $N = k_f (R_g/r_p)^1$ gives $k_f = \sqrt{3} \approx 1.73$ for the ideal chain.

**Upper Bound**: For close-packed spheres ($D_f = 3$):

For FCC/HCP packing with packing fraction $\eta = \pi/(3\sqrt{2}) \approx 0.74$:

The number of spheres in a volume of radius $R$ is approximately:

$$
N \approx \eta \cdot \frac{4\pi R^3/3}{4\pi r_p^3/3} = \eta \left(\frac{R}{r_p}\right)^3
$$

For a uniform sphere, $R_g^2 = (3/5)R^2$, so $R = \sqrt{5/3} \cdot R_g$:

$$
N \approx \eta \cdot (5/3)^{3/2} \left(\frac{R_g}{r_p}\right)^3 \approx 1.6 \left(\frac{R_g}{r_p}\right)^3
$$

This gives $k_f \approx 1.6$ for ideal close packing.

### Physical Interpretation for Different $D_f$ Values

| $D_f$ | Expected $k_f$ Range | Physical Interpretation |
|-------|---------------------|-------------------------|
| 1.0 | 1.0 - 2.0 | Number of parallel chains; higher for branched structures |
| 1.5 | 1.0 - 1.5 | Transition between linear and planar growth |
| 1.8 | 1.2 - 2.0 | Open aggregates; typical CCA structures |
| 2.0 | 1.0 - 2.5 | Surface density of 2D arrangement |
| 2.5 | 1.3 - 2.5 | Intermediate compactness |
| 3.0 | 1.0 - 2.0 | Packing efficiency; approaches $\sqrt{2}$ for random packing |

### Typical Experimental Values

| Aggregation Type | $D_f$ Range | $k_f$ Range | Source |
|------------------|-------------|-------------|--------|
| DLA (particle-cluster) | 2.4 - 2.6 | 1.0 - 1.5 | Witten & Sander (1981) |
| DLCA (diffusion-limited cluster-cluster) | 1.75 - 1.85 | 1.3 - 1.5 | Meakin (1983) |
| RLCA (reaction-limited cluster-cluster) | 2.0 - 2.2 | 1.5 - 2.0 | Weitz et al. (1984) |
| Ballistic aggregation | 2.8 - 3.0 | 1.5 - 2.5 | Sutherland (1970) |
| Flame-generated soot | 1.6 - 2.0 | 1.0 - 3.0 | Sorensen (2011) |
| Diesel exhaust soot | 1.7 - 1.9 | 1.3 - 2.0 | Park et al. (2004) |

### $k_f$ as a Function of Structure

For a given $D_f$, the prefactor encodes structural information beyond scaling:

**Relationship to Coordination Number**: Higher average coordination $\langle \eta \rangle$ correlates with higher $k_f$:

$$
k_f \approx \frac{\langle \eta \rangle}{2} \cdot f(D_f)
$$

where $f(D_f)$ is a dimension-dependent function.

**Effect of Polydispersity**: For a distribution of particle sizes with coefficient of variation $CV = \sigma/\mu$:

$$
k_f^{poly} \approx k_f^{mono} \cdot (1 + CV^2)^{D_f/2}
$$

This increase reflects more efficient packing when small particles fill interstices.

## 1.4 Self-Similarity and Scaling Laws

### Types of Self-Similarity

**Exact Self-Similarity** (Mathematical fractals only):

$$
S \equiv \lambda S \quad \forall \lambda > 0
$$

Examples: Sierpinski triangle, Koch snowflake, Cantor set

**Statistical Self-Similarity** (Physical fractals):

$$
P(\text{structure at scale } L) \approx P(\text{structure at scale } \lambda L)
$$

The probability distribution of structural features is scale-invariant within a range.

**Self-Affinity**:

$$
S(x, y, z) \rightarrow S(\lambda^{H_x} x, \lambda^{H_y} y, \lambda^{H_z} z)
$$

Different scaling in different directions; characterized by Hurst exponents $H_i$.

### Scale Range of Self-Similarity

Physical fractals exhibit self-similarity only within a bounded range:

- **Lower cutoff** $l_{min}$: Primary particle size $r_p$
- **Upper cutoff** $l_{max}$: Agglomerate size $R_g$ or system boundaries

Outside this range, behavior deviates from power-law scaling:

$$
N(r) = k_f \left(\frac{r}{r_p}\right)^{D_f} \quad \text{for} \quad r_p \lesssim r \lesssim R_g
$$

### Scaling Laws for Fractal Agglomerates

For a scale transformation $r \rightarrow \lambda r$ (with $\lambda > 0$):

| Property | Scaling Relation | Exponent |
|----------|------------------|----------|
| Number of particles | $N \rightarrow \lambda^{D_f} \cdot N$ | $D_f$ |
| Radius of gyration | $R_g \rightarrow \lambda \cdot R_g$ | 1 |
| Volume of particles | $V_p \rightarrow \lambda^3 \cdot V_p$ | 3 |
| Total mass | $m \rightarrow \lambda^3 \cdot m$ | 3 |
| Projected area | $A_p \rightarrow \lambda^{D_{f,2D}} \cdot A_p$ | $D_{f,2D}$ |
| Surface area | $S \rightarrow \lambda^{D_s} \cdot S$ | $D_s$ |
| Mobility diameter | $d_m \rightarrow \lambda^{D_f/3} \cdot d_m$ | $D_f/3$ |
| Drag force | $F_d \rightarrow \lambda^{1} \cdot F_d$ | 1 (free molecular) |

### Derivation of Projected Area Scaling

The 2D projected area of a fractal agglomerate scales as:

$$
A_p \propto R_g^{D_{f,2D}}
$$

where $D_{f,2D}$ is the 2D projected fractal dimension. For randomly oriented agglomerates:

- If $D_f < 2$: $D_{f,2D} = D_f$ (projection doesn't overlap much)
- If $D_f > 2$: $D_{f,2D} = 2$ (projection saturates to filled area)

More precisely, for intermediate $D_f$:

$$
D_{f,2D} = \min(D_f, 2)
$$

However, overlap correction introduces the exponent $z_f$ (covered in FRAKTAL analysis):

$$
A_p = C \cdot N^{z_f/D_f} \cdot r_p^2
$$

### Mobility Scaling

In the free molecular regime (particle size << mean free path), the mobility equivalent diameter scales as:

$$
d_m \propto N^{1/D_f} \cdot r_p
$$

This has important implications for aerosol dynamics and filtration.

## 1.5 Porosity and Packing Theory

### Definition of Porosity

Porosity $\varepsilon$ is the void fraction within the bounding volume:

$$
\varepsilon = 1 - \frac{V_{particles}}{V_{bounding}}
$$

For an agglomerate bounded by a sphere of radius $R_{bound}$:

$$
\varepsilon = 1 - \frac{N \cdot \frac{4}{3}\pi r_p^3}{\frac{4}{3}\pi R_{bound}^3} = 1 - N \left(\frac{r_p}{R_{bound}}\right)^3
$$

### Bounding Radius Definition

Different definitions of bounding radius yield different porosity values:

**Using $2R_g$** (encompasses most mass):

$$
\varepsilon = 1 - N \left(\frac{r_p}{2R_g}\right)^3
$$

**Using $R_{max}$** (maximum extent):

$$
\varepsilon = 1 - N \left(\frac{r_p}{R_{max}}\right)^3
$$

Typically $R_{max} \approx 2.5 - 3 \cdot R_g$ for open fractals.

### Relationship to $D_f$

Substituting the power law $N = k_f(R_g/r_p)^{D_f}$ with bounding radius $R_b = 2R_g$:

$$
\varepsilon = 1 - k_f \left(\frac{r_p}{2R_g}\right)^3 \left(\frac{R_g}{r_p}\right)^{D_f}
$$

Simplifying:

$$
\varepsilon = 1 - \frac{k_f}{8} \left(\frac{R_g}{r_p}\right)^{D_f - 3}
$$

### Limiting Behavior

**Case $D_f < 3$**: As $R_g/r_p \rightarrow \infty$:

$$
\varepsilon \rightarrow 1 - \frac{k_f}{8} \cdot 0 = 1
$$

Large fractals with $D_f < 3$ become increasingly porous. The porosity approaches unity.

**Case $D_f = 3$**:

$$
\varepsilon = 1 - \frac{k_f}{8} = \text{constant}
$$

Size-independent porosity. For $k_f = 1$: $\varepsilon = 0.875$ (87.5% void).

**Physical Interpretation**:

The exponent $(D_f - 3)$ determines whether density increases, decreases, or stays constant with size:

$$
\rho_{bulk} = \frac{N \cdot m_p}{V_{bounding}} \propto \left(\frac{R_g}{r_p}\right)^{D_f - 3}
$$

- $D_f < 3$: Bulk density decreases with size (fractals become more tenuous)
- $D_f = 3$: Bulk density constant (solid-like scaling)
- $D_f > 3$: Impossible for physical structures

### Effective Density

The effective density $\rho_{eff}$ (mass per unit bounding volume) relates to particle density $\rho_p$:

$$
\rho_{eff} = (1 - \varepsilon) \cdot \rho_p = \frac{k_f}{8} \cdot \rho_p \cdot \left(\frac{R_g}{r_p}\right)^{D_f - 3}
$$

For mobility equivalent diameter measurements:

$$
\rho_{eff} = \frac{6m}{\pi d_m^3}
$$

This gives the mass-mobility exponent relationship used in aerosol science.

## 1.6 Coordination Number Theory

### Definition

The coordination number $\eta$ is the average number of neighbors in contact with each particle:

$$
\eta = \frac{2 \times (\text{number of contacts})}{N}
$$

The factor of 2 accounts for each contact being shared by two particles.

Equivalently:

$$
\eta = \frac{1}{N} \sum_{i=1}^{N} n_i
$$

where $n_i$ is the number of neighbors of particle $i$.

### Contact Detection Criterion

Two particles $i$ and $j$ are in contact when:

$$
|\vec{r}_i - \vec{r}_j| \leq c_s \cdot (r_{p,i} + r_{p,j})
$$

where $c_s$ is the sintering coefficient:
- $c_s = 1.0$: Touching (no sintering)
- $c_s < 1.0$: Overlapping (sintered)

With numerical tolerance $\delta$:

$$
|\vec{r}_i - \vec{r}_j| \leq c_s \cdot (r_{p,i} + r_{p,j}) + \delta
$$

where $\delta \approx 0.01 \cdot r_p$ accounts for numerical imprecision.

### Relationship to Structure Type

| $\eta$ Value | Structure Type | Examples |
|--------------|----------------|----------|
| $\eta = 2$ | Pure chains | Linear polymers, elongated agglomerates |
| $\eta \approx 2.2$ | Branched chains | Open DLA/CCA structures |
| $\eta \approx 3-4$ | Networks | Typical soot agglomerates |
| $\eta \approx 4-6$ | Dense clusters | Restructured soot, sintered particles |
| $\eta = 6$ | Simple cubic | SC lattice packing |
| $\eta = 8$ | Body-centered cubic | BCC lattice |
| $\eta = 12$ | Close-packed | FCC/HCP theoretical maximum |

### Theoretical Limits

**Lower Bound** ($\eta = 2$):

Every particle except the two endpoints has exactly 2 neighbors (linear chain).

**Upper Bound** ($\eta = 12$):

The kissing number in 3D - maximum sphere neighbors that can touch a central sphere.

### Coordination Distribution

For random aggregates, the coordination number follows a distribution:

$$
P(\eta = n) \propto n^{\alpha} \cdot e^{-n/\beta}
$$

where $\alpha$ and $\beta$ depend on $D_f$ and growth mechanism.

**For DLA/CCA structures**:
- Mode: $n = 2$ (most particles are chain links)
- Mean: $\langle \eta \rangle \approx 2.2 - 2.5$
- Maximum: $n \leq 6$ typically

### Relationship to $D_f$

Higher coordination correlates with higher fractal dimension:

$$
D_f \approx 1 + c \cdot \ln(\langle \eta \rangle)
$$

where $c$ is a mechanism-dependent constant.

More rigorously, for particle-cluster aggregation:

$$
\langle \eta \rangle \approx 2 + 0.4 \cdot (D_f - 1)
$$

## 1.7 Complete Packing Theory

### Lattice Packings

| Lattice | $\eta$ | Packing Fraction $\phi$ | $D_f$ |
|---------|--------|------------------------|-------|
| Simple Cubic (SC) | 6 | $\pi/6 \approx 0.524$ | 3.0 |
| Body-Centered Cubic (BCC) | 8 | $\pi\sqrt{3}/8 \approx 0.680$ | 3.0 |
| Face-Centered Cubic (FCC) | 12 | $\pi/(3\sqrt{2}) \approx 0.740$ | 3.0 |
| Hexagonal Close-Packed (HCP) | 12 | $\pi/(3\sqrt{2}) \approx 0.740$ | 3.0 |

### Random Packings

**Random Loose Packing (RLP)**: $\phi \approx 0.60$

Achieved by gently pouring spheres; represents minimum density of mechanically stable random packing.

**Random Close Packing (RCP)**: $\phi \approx 0.64$

Maximum density achievable by random packing without crystalline order. Also called "Bernal packing."

### Implications for Agglomerates

Real agglomerates never achieve lattice packing efficiency due to:
1. Kinetic trapping during growth
2. Lack of thermal annealing
3. Irregular growth fronts
4. Polydispersity effects

Effective packing fractions for fractal agglomerates:

$$
\phi_{eff} = 1 - \varepsilon = \frac{k_f}{8} \left(\frac{R_g}{r_p}\right)^{D_f - 3}
$$

For typical soot ($D_f = 1.8$, $k_f = 1.3$, $R_g/r_p = 10$):

$$
\phi_{eff} = \frac{1.3}{8} \cdot 10^{-1.2} \approx 0.01
$$

Only ~1% of bounding volume is occupied - extremely porous.

## 1.8 Mathematical Foundations Summary

The fundamental equation of fractal agglomerates:

$$
\boxed{N = k_f \left(\frac{R_g}{r_p}\right)^{D_f}}
$$

connects particle count to characteristic size through the fractal dimension. This power law emerges from:

1. **Self-similarity**: Structure is statistically invariant under scaling within range $[r_p, R_g]$
2. **Non-integer dimension**: Space-filling is intermediate between Euclidean dimensions
3. **Scaling relations**: All geometric properties follow predictable scaling laws

### Key Relationships

| Quantity | Expression | Notes |
|----------|------------|-------|
| Particle count | $N = k_f (R_g/r_p)^{D_f}$ | Fundamental power law |
| Gyration radius | $R_g = r_p k_f^{-1/D_f} N^{1/D_f}$ | Size vs. mass |
| Porosity | $\varepsilon = 1 - (k_f/8)(R_g/r_p)^{D_f-3}$ | Void fraction |
| Effective density | $\rho_{eff} = (k_f/8) \rho_p (R_g/r_p)^{D_f-3}$ | Mass-mobility |
| Projected area | $A_p \propto R_g^{\min(D_f, 2)}$ | 2D scaling |

### Understanding these foundations is essential for:

- Interpreting simulation results
- Validating against experimental data
- Predicting aggregate optical, mechanical, and transport properties
- Designing processes that create desired morphologies
