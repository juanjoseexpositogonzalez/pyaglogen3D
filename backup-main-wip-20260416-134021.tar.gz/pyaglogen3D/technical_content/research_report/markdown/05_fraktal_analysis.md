# Chapter 5: FRAKTAL Image Analysis

## 5.1 Overview

FRAKTAL analysis methods determine fractal properties of particle agglomerates from 2D images (TEM, SEM). Two models are implemented:

| Model | Year | Key Feature | Complexity |
|-------|------|-------------|------------|
| Granulated | 2012 | Particle overlap correction | Higher |
| Voxel | 2018 | Voxel-based counting | Lower |

Both models relate 2D projected properties to 3D fractal characteristics.

## 5.2 Image Preprocessing

### Segmentation

Convert grayscale image to binary using thresholding:

**Manual threshold:**
```
binary[x,y] = 1 if pixel_min ≤ image[x,y] ≤ pixel_max else 0
```

**Otsu's Method (automatic):**

Minimize intra-class variance:
```
σ²_within = ω₀σ₀² + ω₁σ₁²
```

where:
- ω₀, ω₁ = class probabilities (background, foreground)
- σ₀², σ₁² = class variances

Optimal threshold maximizes inter-class variance:
```
σ²_between = ω₀ω₁(μ₀ - μ₁)²
```

### Morphological Operations

**Erosion:** Remove isolated pixels
**Dilation:** Fill small holes
**Opening:** Erosion followed by dilation (removes noise)
**Closing:** Dilation followed by erosion (fills gaps)

## 5.3 Geometric Measurements

### Projected Area

```
Ap = (number of white pixels) × (scale factor)²
   = Σ binary[x,y] × (100/npix)²  [nm²]
```

where npix = pixels per 100 nm.

### Center of Mass

```
x_cm = Σ(x × binary[x,y]) / Σ binary[x,y]
y_cm = Σ(y × binary[x,y]) / Σ binary[x,y]
```

### Radius of Gyration (2D)

```
Rg² = Σ[(x - x_cm)² + (y - y_cm)²] × binary[x,y] / Σ binary[x,y]
```

In physical units:
```
Rg = Rg_pixels × (100/npix)  [nm]
```

### 3D Correction

The 2D projected Rg underestimates the 3D Rg. Empirical correction:

```
Rg_3D = Rg_2D × correction_factor

correction_factor ≈ 1.09 (typical value)
```

This factor depends on viewing angle distribution and structure type.

## 5.4 Primary Particle Count Estimation

### Visual Estimation (Npo_visual)

Count distinguishable particles in the image:

**From projected area:**
```
Ap_single = π × (dpo/2)² × δ

where:
- dpo = primary particle diameter [nm]
- δ = filling factor (accounts for overlap)

Npo_visual = Ap / Ap_single = Ap / (π × dpo²/4 × δ)
```

### Calculated Count (Npo)

Using the fractal power law:

```
Npo = kf × (Rg / (dpo/2))^Df
```

This is the target value we solve for by finding appropriate Df.

## 5.5 Granulated 2012 Model

### Fundamental Equations

**Projected Area:**
```
Ap = C × Rg² × (Npo/kf)^(zf/Df)
```

where:
- C = constant depending on model assumptions
- zf = overlap exponent

**Overlap Exponent:**
```
zf = f(Df, δ)
```

The overlap exponent accounts for particle overlap in projection.

### Solving for Df

The bisection method finds Df such that:
```
Npo_calculated(Df) ≈ Npo_visual
```

**Bisection Algorithm:**
```
function solve_df(Ap, Rg, dpo, Npo_visual, kf):
    lower = 1.0
    upper = 3.0
    tolerance = 0.001

    while upper - lower > tolerance:
        mid = (lower + upper) / 2
        Npo_calc = calculate_npo(Ap, Rg, dpo, mid, kf)

        if Npo_calc > Npo_visual:
            upper = mid
        else:
            lower = mid

    return mid
```

### Coordination Index (Jf)

The coordination index describes average particle connectivity:

```
Jf = A × Npo^B / (1 + C × Npo^D)

where:
- A = 1.85
- B = 17.0
- C = 1.45
- D = 1.5
```

This empirical formula relates particle count to connectivity.

### Model Parameters

| Parameter | Symbol | Typical Value | Description |
|-----------|--------|---------------|-------------|
| Pixels per 100nm | npix | 5-50 | Image scale |
| Primary diameter | dpo | 10-50 nm | Particle size |
| Filling factor | δ | 1.0-1.5 | Overlap correction |
| 3D correction | - | true/false | Apply Rg correction |
| Pixel range | [min,max] | [0,255] | Segmentation |

## 5.6 Voxel 2018 Model

### Simplified Approach

The Voxel model treats each pixel as a voxel, eliminating particle overlap assumptions:

```
Npo = Ap / (π × rp²)    (no overlap correction)
```

### m-Exponent

The Zp (projected area exponent) calculation uses:

```
Zp = f(Df, m)

where m ≈ 0.35 (empirical parameter)
```

### Comparison with Granulated

| Aspect | Granulated 2012 | Voxel 2018 |
|--------|-----------------|------------|
| Overlap handling | δ correction | None |
| Complexity | Higher | Lower |
| Parameters | More | Fewer |
| Accuracy | Higher for spherical particles | General use |
| Coordination index | Yes (Jf) | No |

## 5.7 Auto-Calibration

### Problem

The primary particle diameter dpo is often unknown or imprecise.

### Calibration Algorithm

```
function auto_calibrate(params, initial_dpo):
    candidates = [
        initial_dpo,
        initial_dpo × 0.7,
        initial_dpo × 1.4,
        initial_dpo × 0.5
    ]

    best_result = null
    best_ratio = infinity

    for dpo in candidates:
        result = analyze_with_dpo(params, dpo)
        ratio = |result.npo / result.npo_visual - 1|

        if ratio < best_ratio:
            best_ratio = ratio
            best_result = result
            best_result.best_dpo = dpo

        # Early exit if alignment too low
        if result.npo_visual / result.npo < 0.2:
            return error("Alignment too low")

    return best_result
```

### Calibration Quality

**Good calibration:** npo_ratio ≈ 1.0 (calculated ≈ visual)
**Acceptable:** 0.5 < npo_ratio < 2.0
**Poor:** npo_ratio outside [0.5, 2.0]

## 5.8 Result Interpretation

### Output Parameters

| Parameter | Symbol | Units | Description |
|-----------|--------|-------|-------------|
| Radius of gyration | Rg | nm | Characteristic size |
| Projected area | Ap | nm² | 2D extent |
| Fractal dimension | Df | - | Space-filling |
| Particle count (calc) | Npo | - | From Df |
| Particle count (visual) | Npo_visual | - | From area |
| Prefactor | kf | - | Structure factor |
| Overlap exponent | zf | - | Projection correction |
| Coordination index | Jf | - | Connectivity (2012 only) |
| Volume | V | nm³ | Estimated |
| Mass | m | fg | Estimated |
| Surface area | SA | nm² | Estimated |

### Derived Quantities

**Volume:**
```
V = Npo × (4/3)π × (dpo/2)³
```

**Mass (assuming density ρ):**
```
m = ρ × V = ρ × Npo × (4/3)π × (dpo/2)³
```

**Surface Area:**
```
SA = Npo × 4π × (dpo/2)² × overlap_correction
```

## 5.9 Validation and Error Analysis

### Sources of Error

1. **Image quality:** Noise, blur, artifacts
2. **Segmentation:** Threshold selection
3. **Scale calibration:** npix uncertainty
4. **dpo estimation:** Primary particle size
5. **Projection effects:** 3D to 2D information loss

### Validation Strategies

1. **Known geometries:** Analyze synthetic images of known Df
2. **Multiple images:** Consistency across viewing angles
3. **Comparison methods:** Box-counting vs FRAKTAL
4. **Sensitivity analysis:** Vary parameters, check stability

### Confidence Assessment

**High confidence:**
- R² > 0.95
- npo_ratio ∈ [0.8, 1.2]
- Consistent across angles

**Low confidence:**
- R² < 0.90
- npo_ratio outside [0.5, 2.0]
- High sensitivity to parameters

## 5.10 Summary

FRAKTAL analysis enables extraction of 3D fractal properties from 2D images:

1. **Image preprocessing:** Segmentation, morphological operations
2. **Geometric measurements:** Ap, Rg, center of mass
3. **Particle counting:** Visual and calculated methods
4. **Model fitting:** Bisection for Df
5. **Validation:** npo ratio, auto-calibration

The Granulated 2012 model provides higher accuracy for spherical particle agglomerates, while the Voxel 2018 model offers simpler analysis for general structures.
