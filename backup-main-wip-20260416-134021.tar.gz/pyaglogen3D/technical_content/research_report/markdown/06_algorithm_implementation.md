# Chapter 6: Algorithm Implementation Theory

## 6.1 Computational Complexity Analysis

### Time Complexity Summary

| Algorithm | Phase | Complexity | Dominant Operation |
|-----------|-------|------------|-------------------|
| DLA | Random walk | O(N × W) | W = walk steps per particle |
| DLA | Collision detection | O(1) average | Spatial hash query |
| CCA | Cluster motion | O(C × S) | C = clusters, S = steps |
| CCA | Collision detection | O(C² × k) | k = particles per cluster |
| Ballistic PC | Trajectory | O(N) | Single ray per particle |
| Ballistic CC | Cluster merge | O(C × k²) | Pairwise particle checks |
| Tunable | Placement | O(N² worst) | Candidate search |
| Box-counting | Morton sort | O(N log N) | Sorting dominates |
| Rg calculation | All particles | O(N) | Single pass summation |

### Space Complexity

| Structure | Space | Purpose |
|-----------|-------|---------|
| Particle array | O(N) | Store positions, radii |
| Spatial hash | O(N + M) | M = grid cells |
| Growth history | O(N) | (Rg, N) pairs for regression |
| Morton codes | O(N) | Box-counting |
| Cluster membership | O(N) | CCA algorithm |

## 6.2 Random Number Generation

### Requirements

For physically realistic simulations:

1. **Uniformity**: Uniform distribution over [0, 1)
2. **Independence**: No correlation between successive values
3. **Reproducibility**: Same seed → same sequence
4. **Period**: > 10^15 for large simulations

### Spherical Uniform Distribution

**Problem**: Generate uniformly distributed points on a sphere surface.

**Naive (incorrect) approach**:
```
θ = random() × 2π
φ = random() × π

This produces clustering near poles!
```

**Correct approach** (Marsaglia method):
```
u = 2 × random() - 1     # [-1, 1]
v = 2 × random() - 1     # [-1, 1]

while u² + v² ≥ 1:
    regenerate u, v

s = u² + v²
x = 2u × √(1 - s)
y = 2v × √(1 - s)
z = 1 - 2s
```

**Alternative** (trigonometric):
```
z = 2 × random() - 1     # Uniform in [-1, 1]
θ = 2π × random()
r = √(1 - z²)
x = r × cos(θ)
y = r × sin(θ)
```

### Seed Management

For batch simulations:
```
base_seed = user_provided_seed
for i in 0..batch_size:
    simulation_seed = hash(base_seed, i)
    rng = create_rng(simulation_seed)
    run_simulation(rng)
```

## 6.3 Numerical Stability

### Floating-Point Considerations

**Distance calculations**:
```
# Unstable for nearly-coincident points
distance = √((x₁-x₂)² + (y₁-y₂)² + (z₁-z₂)²)

# More stable
Δx, Δy, Δz = x₁-x₂, y₁-y₂, z₁-z₂
max_Δ = max(|Δx|, |Δy|, |Δz|)
if max_Δ < ε:
    return 0
distance = max_Δ × √((Δx/max_Δ)² + (Δy/max_Δ)² + (Δz/max_Δ)²)
```

**Radius of gyration**:
```
# Unstable: accumulating large values then dividing
Rg² = Σᵢ(mᵢdᵢ²) / Σᵢmᵢ

# More stable: Welford's online algorithm
mean_d² = 0
for i in 1..N:
    mean_d² += (dᵢ² - mean_d²) / i
Rg² = mean_d²
```

### Tolerance Selection

| Operation | Recommended Tolerance | Rationale |
|-----------|----------------------|-----------|
| Contact detection | 0.01 × rp | 1% of particle radius |
| Position equality | 10⁻⁹ | Near machine epsilon |
| Df convergence | 10⁻³ | Physical measurement precision |
| Rg equality | 10⁻⁶ | Intermediate precision |

## 6.4 Parallel Algorithm Design

### Embarrassingly Parallel Components

**Batch simulations**:
```
# Each simulation is independent
parallel_for i in 0..batch_size:
    result[i] = run_simulation(params, seed=i)
```

**Box-counting at different scales**:
```
# After Morton codes are sorted
parallel_for scale in min_scale..max_scale:
    count[scale] = count_unique_at_scale(sorted_codes, scale)
```

### Challenging Parallelization

**Sequential growth algorithms** (DLA, Tunable):
- Each particle placement depends on previous structure
- Cannot parallelize particle addition
- Can parallelize candidate evaluation

**CCA with cluster merging**:
- Clusters merge dynamically
- Requires synchronization for collision detection
- Can parallelize intra-cluster motion

### Lock-Free Spatial Hashing

For parallel collision detection:
```
# Read-mostly pattern
spatial_hash = ConcurrentHashMap<CellKey, AtomicList<ParticleIdx>>

# Insert (rare operation)
spatial_hash[cell].atomic_append(particle_idx)

# Query (frequent operation)
for neighbor_cell in adjacent_cells(query_cell):
    for idx in spatial_hash[neighbor_cell].snapshot():
        check_collision(query_particle, particles[idx])
```

## 6.5 Memory Layout Optimization

### Structure of Arrays (SoA)

**Array of Structures (AoS)**:
```
struct Particle {
    x: f64, y: f64, z: f64,
    radius: f64
}
particles: Vec<Particle>
```

**Structure of Arrays (SoA)**:
```
struct Particles {
    x: Vec<f64>,
    y: Vec<f64>,
    z: Vec<f64>,
    radii: Vec<f64>
}
```

**Performance comparison**:

| Operation | AoS | SoA |
|-----------|-----|-----|
| Single particle access | ✓ Better | Worse |
| SIMD distance calculation | Limited | ✓ Vectorizable |
| Cache efficiency (position loop) | 50% utilization | ✓ 100% utilization |
| Add/remove particles | ✓ Simple | Complex |

### Memory Pool for Growth

Pre-allocate for expected final size:
```
# Estimate final particle count
target_N = estimate_from_Df_and_Rg(target_Rg, Df, kf, rp)

# Pre-allocate with margin
capacity = target_N × 1.2

particles = Vec::with_capacity(capacity)
```

## 6.6 Algorithmic Optimizations

### Early Termination

**DLA random walk**:
```
if distance_from_cluster > 3 × Rg:
    # Restart from launch sphere (faster convergence)
    restart_walk()
```

**Tunable candidate search**:
```
for candidate in candidates:
    if definitely_outside_shell(candidate):
        skip  # Quick reject
    if placement_valid(candidate):
        return candidate  # Early success
```

### Incremental Rg Update

Instead of O(N) recalculation after each particle:
```
# After adding particle at position r_new with mass m_new

old_mp = total_mass
old_cm = center_of_mass
old_Ip = moment_of_inertia

new_mp = old_mp + m_new
new_cm = (old_mp × old_cm + m_new × r_new) / new_mp

# Parallel axis theorem for moment update
Δcm = new_cm - old_cm
new_Ip = old_Ip + old_mp × |Δcm|² + m_new × |r_new - new_cm|² + I_self(m_new)

new_Rg = √(new_Ip / new_mp)
```

This reduces Rg calculation from O(N) to O(1) per particle.

### Spatial Hash Dynamic Sizing

```
# Initial estimate
expected_particles = 1000
cell_size = 4 × max_radius
expected_cells = (expected_extent / cell_size)³

# Rehash when load factor exceeds threshold
if particles.len() / cells.len() > 8:
    resize_hash(cells.len() × 2)
```

## 6.7 Error Propagation

### Linear Regression Error

For Df estimation via ln(Rg) vs ln(N):
```
σ_m² = σ² / Σᵢ(xᵢ - x̄)²

where σ² = Σᵢ(yᵢ - ŷᵢ)² / (M - 2)

σ_Df = σ_m / m² = Df² × σ_m
```

### Monte Carlo Error Estimation

For derived quantities:
```
for trial in 1..1000:
    Df_sample = Df + randn() × σ_Df
    kf_sample = kf + randn() × σ_kf

    derived_sample = f(Df_sample, kf_sample)
    samples.append(derived_sample)

σ_derived = std(samples)
```

## 6.8 Validation Strategies

### Analytical Test Cases

| Test Case | Expected Result | Validation |
|-----------|-----------------|------------|
| Linear chain | Df = 1.0, kf = 1.0 | Exact match |
| Solid sphere packing | Df → 3.0 | Limit behavior |
| 2D disk (planar) | Df = 2.0 | Exact match |
| Known fractal (Sierpinski) | Df = log(3)/log(2) ≈ 1.585 | Within tolerance |

### Statistical Validation

For stochastic algorithms:
```
# Run M independent simulations
for trial in 1..M:
    result[trial] = run_simulation(seed=trial)

# Verify statistics
mean_Df = mean(result.Df)
σ_Df = std(result.Df)

# 95% confidence interval for expected Df
CI = [mean_Df - 1.96×σ_Df/√M, mean_Df + 1.96×σ_Df/√M]

assert expected_Df in CI
```

### Cross-Method Validation

Compare Df estimates from:
1. Log-log regression (Rg vs N)
2. 3D box-counting
3. FRAKTAL image analysis (2D projection)

Agreement within 5% indicates reliable measurement.

## 6.9 Summary

Efficient implementation requires attention to:

1. **Complexity**: Spatial hashing reduces collision detection from O(N²) to O(N)
2. **Numerics**: Careful handling of floating-point operations
3. **Memory**: SoA layout enables SIMD, pre-allocation reduces fragmentation
4. **Parallelism**: Batch simulations are trivially parallel
5. **Validation**: Analytical test cases and statistical verification

The combination of algorithmic efficiency and numerical stability enables simulation of agglomerates with N > 10⁴ particles in reasonable time.
