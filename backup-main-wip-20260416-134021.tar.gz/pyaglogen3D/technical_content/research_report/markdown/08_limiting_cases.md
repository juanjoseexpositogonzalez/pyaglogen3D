# Chapter 8: Limiting Case Theory

## 8.1 Introduction

Limiting cases provide exact analytical results against which simulations can be validated. By deriving theoretical values for $D_f$, $k_f$, and other parameters for idealized structures (chains, disks, spheres), we establish benchmarks for algorithm correctness.

This chapter presents complete derivations for:
- Linear chains ($D_f = 1$)
- Planar structures ($D_f = 2$)
- Compact spheres ($D_f = 3$)
- Coordination number analysis
- Packing limits

## 8.2 Linear Chain: $D_f = 1$

### Geometry

A linear chain consists of $N$ identical spheres of radius $r_p$ arranged in a straight line with centers touching.

**Center Positions** (along x-axis):

$$
x_i = (2i - N - 1) \cdot r_p \quad \text{for } i = 1, 2, \ldots, N
$$

This places the center of mass at the origin.

**Chain Length**:

$$
L = 2(N-1) r_p
$$

### Radius of Gyration Derivation

**Without Internal Moment**:

$$
R_g^2 = \frac{1}{N} \sum_{i=1}^{N} x_i^2
$$

For symmetric positioning:

$$
R_g^2 = \frac{1}{N} \sum_{i=1}^{N} [(2i - N - 1) r_p]^2
$$

Let $j = i - (N+1)/2$, so $j$ ranges from $-(N-1)/2$ to $(N-1)/2$ (for odd $N$):

$$
R_g^2 = \frac{4r_p^2}{N} \sum_{j=-(N-1)/2}^{(N-1)/2} j^2
$$

Using $\sum_{j=-m}^{m} j^2 = \frac{m(m+1)(2m+1)}{3}$ with $m = (N-1)/2$:

$$
\sum j^2 = \frac{(N-1)(N+1)N}{12} = \frac{N(N^2-1)}{12}
$$

Therefore:

$$
R_g^2 = \frac{4r_p^2}{N} \cdot \frac{N(N^2-1)}{12} = \frac{(N^2-1)r_p^2}{3}
$$

For large $N$:

$$
R_g \approx \frac{N r_p}{\sqrt{3}}
$$

**With Internal Moment (3/5 Factor)**:

$$
R_g^2 = \frac{3}{5}r_p^2 + \frac{(N^2-1)r_p^2}{3N}
$$

For large $N$:

$$
R_g^2 \approx \frac{N^2 r_p^2}{3}
$$

### Fractal Parameters

**Fractal Dimension**:

From $N = k_f (R_g/r_p)^{D_f}$ and $R_g \approx N r_p / \sqrt{3}$:

$$
N = k_f \left(\frac{N}{\sqrt{3}}\right)^{D_f}
$$

This requires $D_f = 1$ and:

$$
k_f = \sqrt{3} \approx 1.732
$$

**Exact Prefactor Derivation**:

From $R_g^2 = (N^2-1)r_p^2/(3N)$ (without internal moment):

$$
\frac{R_g}{r_p} = \sqrt{\frac{N^2-1}{3N}}
$$

For the power law:

$$
N = k_f \left(\frac{R_g}{r_p}\right)^1 = k_f \sqrt{\frac{N^2-1}{3N}}
$$

Solving:

$$
k_f = N \sqrt{\frac{3N}{N^2-1}} = \sqrt{\frac{3N^3}{N^2-1}}
$$

For large $N$: $k_f \to \sqrt{3}$

**Coordination Number**:

- Interior particles: $\eta = 2$ (two neighbors)
- End particles: $\eta = 1$ (one neighbor)

$$
\langle \eta \rangle = \frac{2(N-2) + 2 \cdot 1}{N} = \frac{2N - 2}{N} = 2 - \frac{2}{N}
$$

For large $N$: $\langle \eta \rangle \to 2$

### Validation Criteria

For a generated chain structure:

| Parameter | Expected | Tolerance |
|-----------|----------|-----------|
| $D_f$ | 1.00 | $\pm 0.02$ |
| $k_f$ | 1.73 | $\pm 0.1$ |
| $\langle \eta \rangle$ | 2.0 | $\pm 0.1$ |
| Anisotropy $A$ | >> 1 | $> N/3$ |
| Asphericity $b$ | $\to 1$ | $> 0.8$ |

## 8.3 Planar Disk: $D_f = 2$

### Geometry

Consider $N$ spheres arranged in a planar disk with center at origin, uniform surface density $\sigma$.

**Approximate Radius of Disk**:

For close packing in 2D with packing fraction $\phi_{2D} \approx 0.9069$ (hexagonal):

$$
N \cdot \pi r_p^2 = \phi_{2D} \cdot \pi R_{disk}^2
$$

$$
R_{disk} = r_p \sqrt{\frac{N}{\phi_{2D}}}
$$

### Radius of Gyration for Uniform Disk

**Continuous Approximation**:

For a uniform disk of radius $R$ and total mass $M$:

$$
R_g^2 = \frac{\int_0^R r^2 \cdot 2\pi r \cdot \sigma \, dr}{\int_0^R 2\pi r \cdot \sigma \, dr}
$$

$$
= \frac{\int_0^R r^3 dr}{\int_0^R r dr} = \frac{R^4/4}{R^2/2} = \frac{R^2}{2}
$$

With $R_{disk} = r_p \sqrt{N/\phi_{2D}}$:

$$
R_g^2 = \frac{1}{2} \cdot \frac{N r_p^2}{\phi_{2D}} = \frac{N r_p^2}{2\phi_{2D}}
$$

$$
R_g = r_p \sqrt{\frac{N}{2\phi_{2D}}}
$$

### Fractal Parameters

**Fractal Dimension**:

From $N = k_f (R_g/r_p)^{D_f}$:

$$
N = k_f \left(\sqrt{\frac{N}{2\phi_{2D}}}\right)^{D_f}
$$

$$
N = k_f \left(\frac{N}{2\phi_{2D}}\right)^{D_f/2}
$$

Taking logarithms:

$$
\ln N = \ln k_f + \frac{D_f}{2} \ln\left(\frac{N}{2\phi_{2D}}\right)
$$

$$
\ln N = \ln k_f + \frac{D_f}{2} \ln N - \frac{D_f}{2} \ln(2\phi_{2D})
$$

$$
\left(1 - \frac{D_f}{2}\right) \ln N = \ln k_f - \frac{D_f}{2} \ln(2\phi_{2D})
$$

For this to hold for all $N$, we need:

$$
1 - \frac{D_f}{2} = 0 \implies D_f = 2
$$

And:

$$
k_f = (2\phi_{2D})^{D_f/2} = 2\phi_{2D} \approx 1.81
$$

**Coordination Number** (hexagonal packing):

- Interior particles: $\eta = 6$
- Edge particles: $\eta = 3-4$
- Average depends on $N$ and edge fraction

For large circular disk:

$$
\langle \eta \rangle \approx 6 - \frac{6}{\sqrt{N}}
$$

### Shape Descriptors

**Anisotropy**: For flat disk with thickness $t << R$:

$$
A = \frac{I_3}{I_1} \approx \frac{MR^2/2}{MR^2/4} = 2
$$

**Asphericity**:

$$
b = \frac{I_3 - (I_1+I_2)/2}{I_1+I_2+I_3} \approx \frac{0.5 - 0.25}{0.75 + 0.5} < 0.2
$$

Disk is more isotropic than chain but still non-spherical.

## 8.4 Compact Sphere: $D_f = 3$

### Geometry

Consider $N$ spheres uniformly distributed within a spherical region of radius $R$, with volume packing fraction $\phi$.

**Relationship**:

$$
N \cdot \frac{4}{3}\pi r_p^3 = \phi \cdot \frac{4}{3}\pi R^3
$$

$$
R = r_p \left(\frac{N}{\phi}\right)^{1/3}
$$

### Radius of Gyration for Uniform Sphere

**Continuous Approximation**:

For a uniform solid sphere of radius $R$:

$$
R_g^2 = \frac{\int_0^R r^2 \cdot 4\pi r^2 \rho \, dr}{\int_0^R 4\pi r^2 \rho \, dr}
$$

$$
= \frac{\int_0^R r^4 dr}{\int_0^R r^2 dr} = \frac{R^5/5}{R^3/3} = \frac{3R^2}{5}
$$

With $R = r_p (N/\phi)^{1/3}$:

$$
R_g^2 = \frac{3}{5} r_p^2 \left(\frac{N}{\phi}\right)^{2/3}
$$

$$
R_g = r_p \sqrt{\frac{3}{5}} \left(\frac{N}{\phi}\right)^{1/3}
$$

### Fractal Parameters

**Fractal Dimension**:

From $N = k_f (R_g/r_p)^{D_f}$:

$$
N = k_f \left(\sqrt{\frac{3}{5}} \left(\frac{N}{\phi}\right)^{1/3}\right)^{D_f}
$$

$$
N = k_f \left(\frac{3}{5}\right)^{D_f/2} \left(\frac{N}{\phi}\right)^{D_f/3}
$$

Taking logarithms:

$$
\ln N = \ln k_f + \frac{D_f}{2} \ln\left(\frac{3}{5}\right) + \frac{D_f}{3} \ln N - \frac{D_f}{3} \ln \phi
$$

$$
\left(1 - \frac{D_f}{3}\right) \ln N = \ln k_f + \frac{D_f}{2} \ln\left(\frac{3}{5}\right) - \frac{D_f}{3} \ln \phi
$$

For this to hold for all $N$:

$$
1 - \frac{D_f}{3} = 0 \implies D_f = 3
$$

**Prefactor**:

$$
k_f = \left(\frac{3}{5}\right)^{-3/2} \phi = \left(\frac{5}{3}\right)^{3/2} \phi
$$

For different packing:

| Packing | $\phi$ | $k_f$ |
|---------|--------|-------|
| Random loose | 0.60 | 1.29 |
| Random close | 0.64 | 1.38 |
| FCC/HCP | 0.74 | 1.60 |

### Coordination Number Analysis

**For Different Lattices**:

| Structure | $\eta$ | $\phi$ | Example |
|-----------|--------|--------|---------|
| Simple cubic (SC) | 6 | 0.524 | Grid arrangement |
| Body-centered cubic (BCC) | 8 | 0.680 | Fe crystal |
| Face-centered cubic (FCC) | 12 | 0.740 | Cu crystal |
| Hexagonal close-packed (HCP) | 12 | 0.740 | Zn crystal |
| Random close packing | ~6 | 0.64 | Bernal limit |

**Derivation of FCC Packing Fraction**:

In FCC, a unit cube of side $a$ contains 4 complete spheres.
Spheres touch along face diagonal: $4r_p = a\sqrt{2}$, so $a = 2\sqrt{2}r_p$.

$$
\phi_{FCC} = \frac{4 \cdot \frac{4}{3}\pi r_p^3}{a^3} = \frac{4 \cdot \frac{4}{3}\pi r_p^3}{(2\sqrt{2}r_p)^3}
$$

$$
= \frac{16\pi/3}{16\sqrt{2}} = \frac{\pi}{3\sqrt{2}} \approx 0.7405
$$

### Shape Descriptors

**For Ideal Sphere**:

$$
I_1 = I_2 = I_3 = \frac{2}{5}MR^2
$$

$$
A = \frac{I_3}{I_1} = 1
$$

$$
b = \frac{I_3 - (I_1+I_2)/2}{I_1+I_2+I_3} = 0
$$

$$
c = \frac{I_2 - I_1}{I_1+I_2+I_3} = 0
$$

## 8.5 Intermediate Cases: Ellipsoids

### Prolate Ellipsoid (Cigar-shaped)

Semi-axes: $a = a$, $b = c$ (with $a > b$)

**Moments of Inertia**:

$$
I_1 = \frac{M}{5}(b^2 + c^2) = \frac{2Mb^2}{5}
$$

$$
I_2 = I_3 = \frac{M}{5}(a^2 + b^2)
$$

**Radius of Gyration**:

$$
R_g^2 = \frac{I_1 + I_2 + I_3}{3M} = \frac{a^2 + 2b^2}{5}
$$

**Effective $D_f$**:

For extreme prolate ($a >> b$): Approaches linear chain behavior, $D_f \to 1$

For moderate elongation: $1 < D_f < 3$, depends on aspect ratio

### Oblate Ellipsoid (Disk-shaped)

Semi-axes: $a = b$, $c < a$ (flat along z)

**Moments of Inertia**:

$$
I_1 = I_2 = \frac{M}{5}(a^2 + c^2)
$$

$$
I_3 = \frac{2Ma^2}{5}
$$

**Effective $D_f$**:

For extreme oblate ($c << a$): Approaches disk behavior, $D_f \to 2$

## 8.6 Branched Structures

### Y-Junction (3 Arms)

Consider 3 chains of length $n$ emanating from a central particle at 120 angles.

**Total Particles**: $N = 3n + 1$

**Approximate $R_g$** (ignoring details):

Each arm contributes:

$$
R_g^2 \approx \frac{1}{3n+1} \cdot 3 \sum_{i=1}^{n} (2i r_p)^2 \approx \frac{4r_p^2 n^3}{n} = 4n^2 r_p^2
$$

So $R_g \sim 2n r_p \sim 2(N/3) r_p$.

**Effective $D_f$**: Still close to 1, but with different prefactor than linear chain.

The branched structure shows:

$$
N = k_f (R_g/r_p)^{D_f}
$$

With $D_f \approx 1.1 - 1.3$ depending on branching degree.

### General Branching

The fractal dimension increases with branching:

| Structure | Branches | $D_f$ |
|-----------|----------|-------|
| Linear | 1 | 1.0 |
| Y-junction | 3 | ~1.2 |
| X-junction | 4 | ~1.4 |
| Dense tree | many | ~1.8 (DLCA) |

## 8.7 Limiting Behaviors in Aggregation

### Early Growth (Small $N$)

For very small aggregates ($N < 10$), discrete effects dominate:

**Dimer ($N = 2$)**:

$$
R_g = r_p \sqrt{1 + \frac{3}{5}} = r_p \sqrt{1.6} \approx 1.26 r_p
$$

(including internal moment)

$$
k_f = 2 / (1.26)^{D_f}
$$

Undefined $D_f$ for single point!

**Trimer ($N = 3$)** - Linear:

$$
R_g \approx 1.63 r_p
$$

**Trimer ($N = 3$)** - Triangular:

$$
R_g \approx 1.22 r_p
$$

Different geometries give same $N$ but different $R_g$!

### Large $N$ Asymptotics

For $N \to \infty$, the fractal scaling becomes exact:

$$
\lim_{N \to \infty} \frac{\ln N}{\ln(R_g/r_p)} = D_f
$$

Finite-size corrections scale as:

$$
D_f^{eff}(N) = D_f + \frac{a}{N^{1/D_f}} + O(N^{-2/D_f})
$$

where $a$ is a structure-dependent constant.

## 8.8 Porosity Limits

### Minimum Porosity (Dense Packing)

For FCC/HCP at $\phi = 0.74$:

$$
\varepsilon_{min} = 1 - 0.74 = 0.26
$$

### Maximum Porosity (Open Fractals)

For DLCA structures with $D_f = 1.8$:

$$
\varepsilon = 1 - \frac{k_f}{8} \left(\frac{R_g}{r_p}\right)^{D_f - 3}
$$

For large aggregates ($R_g/r_p = 100$, $k_f = 1.5$):

$$
\varepsilon = 1 - \frac{1.5}{8} \cdot 100^{-1.2} = 1 - 0.0007 = 0.9993
$$

Porosity exceeds 99.9%!

### Porosity vs $D_f$ at Fixed Size

For $R_g/r_p = 50$:

| $D_f$ | $k_f$ | $\varepsilon$ |
|-------|-------|---------------|
| 1.5 | 1.5 | 0.9998 |
| 1.8 | 1.5 | 0.9992 |
| 2.0 | 1.5 | 0.9985 |
| 2.5 | 1.5 | 0.9910 |
| 3.0 | 1.5 | 0.9625 |

## 8.9 Validation Test Suite

### Test Case 1: Linear Chain

**Generate**: 100 particles in straight line

**Expected Results**:
- $D_f = 1.00 \pm 0.02$
- $k_f = 1.73 \pm 0.1$
- $\langle \eta \rangle = 1.98 \pm 0.02$
- $b > 0.9$ (highly aspherical)

### Test Case 2: Triangular Lattice

**Generate**: Particles in 2D triangular lattice

**Expected Results**:
- $D_f = 2.00 \pm 0.05$
- $k_f \approx 1.8$ (hexagonal packing)
- $\langle \eta \rangle \approx 6$ (interior)

### Test Case 3: FCC Packing

**Generate**: Particles in FCC arrangement

**Expected Results**:
- $D_f = 3.00 \pm 0.05$
- $k_f \approx 1.6$
- $\langle \eta \rangle = 12$ (exactly)
- $A \approx 1$ (isotropic)

### Test Case 4: Known Df (Tunable)

**Generate**: Tunable algorithm with target $D_f = 1.8$

**Expected Results**:
- Measured $D_f$ matches target within 0.05
- Consistent $k_f$ with input value

## 8.10 Summary

### Key Theoretical Results

| Structure | $D_f$ | $k_f$ | $\langle \eta \rangle$ | $\phi$ |
|-----------|-------|-------|------------------------|--------|
| Linear chain | 1.0 | $\sqrt{3} \approx 1.73$ | 2 | N/A |
| Planar disk | 2.0 | $\approx 1.8$ | $\leq 6$ | $\leq 0.91$ (2D) |
| Solid sphere (RCP) | 3.0 | $\approx 1.38$ | $\approx 6$ | 0.64 |
| Solid sphere (FCC) | 3.0 | $\approx 1.60$ | 12 | 0.74 |

### Derivation Summary

| Parameter | Formula | Validity |
|-----------|---------|----------|
| $R_g$ (chain) | $\frac{Nr_p}{\sqrt{3}}$ | Large $N$ |
| $R_g$ (disk) | $r_p\sqrt{N/(2\phi_{2D})}$ | Large $N$ |
| $R_g$ (sphere) | $r_p\sqrt{3/5}(N/\phi)^{1/3}$ | Large $N$ |
| $\varepsilon$ | $1 - \frac{k_f}{8}(R_g/r_p)^{D_f-3}$ | $D_f < 3$ |
| $\langle \eta \rangle$ (chain) | $2 - 2/N$ | All $N$ |

These analytical results provide essential validation benchmarks for simulation algorithms.
