# Chapter 2: Aggregation Physics

## 2.1 Overview of Aggregation Mechanisms

Particle aggregation is the process by which individual particles (monomers) combine to form larger structures (agglomerates). The morphology of the resulting agglomerate depends critically on the aggregation mechanism, which determines how particles approach, contact, and bond.

### Classification Framework

Aggregation mechanisms are classified along two axes:

**Transport Mechanism**:
- **Diffusive**: Brownian motion (random walk)
- **Ballistic**: Straight-line trajectories
- **Mixed**: Combination of both

**Collision Partners**:
- **Particle-Cluster (PC)**: Monomer attaches to growing cluster
- **Cluster-Cluster (CC)**: Two clusters merge

### Summary of Mechanisms

| Mechanism | Abbreviation | Transport | Partners | Typical $D_f$ |
|-----------|--------------|-----------|----------|---------------|
| Diffusion-Limited Aggregation | DLA | Diffusive | PC | 2.4 - 2.6 |
| Diffusion-Limited Cluster-Cluster Aggregation | DLCA/DLCCA | Diffusive | CC | 1.75 - 1.85 |
| Reaction-Limited Cluster-Cluster Aggregation | RLCA/RLCCA | Diffusive | CC | 2.0 - 2.2 |
| Ballistic Particle-Cluster Aggregation | BPCA | Ballistic | PC | 2.8 - 3.0 |
| Ballistic Cluster-Cluster Aggregation | BCCA | Ballistic | CC | 1.9 - 2.1 |
| Tunable (Filippov-Lapuerta) | - | Controlled | PC | 1.0 - 3.0 |

## 2.2 Diffusion-Limited Aggregation (DLA)

### Physical Model

In DLA, particles undergo random walks (Brownian motion) until they contact the growing cluster. The process is "diffusion-limited" because particle transport via diffusion is the rate-limiting step - once a particle reaches the cluster surface, it sticks immediately with probability 1.

DLA was introduced by Witten and Sander (1981) as a model for electrochemical deposition, and has since found applications in diverse fields including:
- Soot formation in flames
- Mineral dendrite growth
- Lightning pathways
- Viscous fingering in porous media

### Mathematical Description: The Diffusion Equation

The concentration field $c(\vec{r}, t)$ of diffusing particles obeys the diffusion equation:

$$
\frac{\partial c}{\partial t} = D \nabla^2 c
$$

where $D$ is the diffusion coefficient (units: $m^2/s$).

### Derivation of the Diffusion Equation

**Step 1: Random Walk Statistics**

Consider a particle undergoing a random walk with step size $\ell$ and time step $\tau$. After $n$ steps, the mean square displacement is:

$$
\langle |\vec{r}(n\tau)|^2 \rangle = n \ell^2 = \frac{\ell^2}{\tau} \cdot t
$$

The diffusion coefficient relates to microscopic parameters:

$$
D = \frac{\ell^2}{6\tau} \quad \text{(3D)}
$$

**Step 2: Continuity with Fick's Law**

The particle flux $\vec{J}$ follows Fick's law:

$$
\vec{J} = -D \nabla c
$$

Combined with the continuity equation $\partial c / \partial t = -\nabla \cdot \vec{J}$:

$$
\frac{\partial c}{\partial t} = -\nabla \cdot (-D \nabla c) = D \nabla^2 c
$$

### Steady-State Growth Analysis

For steady-state DLA growth, the cluster grows slowly enough that the concentration field reaches quasi-equilibrium:

$$
\nabla^2 c = 0 \quad \text{(Laplace equation)}
$$

**Boundary Conditions**:
1. $c = 0$ at cluster surface (immediate sticking)
2. $c = c_\infty$ at infinity (constant particle supply)

**Solution for Spherical Cluster of Radius $R$**:

In spherical coordinates:

$$
\frac{1}{r^2} \frac{d}{dr}\left(r^2 \frac{dc}{dr}\right) = 0
$$

Solution: $c(r) = A + B/r$

Applying boundary conditions $c(R) = 0$ and $c(\infty) = c_\infty$:

$$
c(r) = c_\infty \left(1 - \frac{R}{r}\right)
$$

**Growth Probability**:

The probability of attachment at position $\vec{r}$ on the surface is proportional to the inward flux:

$$
P(\vec{r}) \propto -D \left.\frac{\partial c}{\partial n}\right|_{\text{surface}} = \frac{D c_\infty}{R}
$$

For a spherical cluster, the flux is uniform - growth is isotropic. But for non-spherical clusters, protrusions receive higher flux (the "tip effect").

### The Screening Effect

DLA produces dendritic structures due to **screening**: outer branches shield the interior from incoming particles.

**Quantitative Analysis**:

The probability of a particle penetrating to depth $d$ inside a cluster scales as:

$$
P(d) \propto e^{-d/\xi}
$$

where the screening length $\xi$ relates to the local branch density. For dense regions, $\xi$ is small - particles cannot penetrate.

This leads to:
- **Preferential tip growth**: Exposed tips capture most particles
- **Branch competition**: Growing tips shadow slower-growing neighbors
- **Self-organized criticality**: Power-law branch length distribution

### Random Walk Implementation

The discrete random walk approximates Brownian motion:

**Position Update**:

$$
\vec{r}(t + \Delta t) = \vec{r}(t) + \Delta \vec{r}
$$

where:

$$
\Delta \vec{r} = s \cdot \hat{u}
$$

- $s$ = step size (typically $0.3 - 0.5 \times r_p$)
- $\hat{u}$ = uniformly distributed random unit vector

**Generation of Random Unit Vector**:

Using the Marsaglia method for uniform sphere sampling:

1. Generate $u_1, u_2 \sim U(-1, 1)$
2. Reject if $u_1^2 + u_2^2 \geq 1$
3. Compute:

$$
\hat{u} = \begin{pmatrix}
2u_1\sqrt{1 - u_1^2 - u_2^2} \\
2u_2\sqrt{1 - u_1^2 - u_2^2} \\
1 - 2(u_1^2 + u_2^2)
\end{pmatrix}
$$

### Growth Rate Scaling

For DLA clusters, the cluster radius $R$ grows with particle count $N$:

$$
\frac{dR}{dN} \propto R^{1-D_f}
$$

**Derivation**:

From $N \propto R^{D_f}$:

$$
dN = D_f \cdot R^{D_f - 1} dR
$$

Therefore:

$$
\frac{dR}{dN} = \frac{1}{D_f} R^{1-D_f}
$$

This shows that larger clusters grow more slowly in radius per particle added.

### DLA Fractal Dimension

The DLA fractal dimension in 3D is:

$$
D_f^{DLA} \approx 2.50 \pm 0.05
$$

This is close to but distinct from $D_f = 3 - 1/2 = 2.5$, a mean-field prediction.

**Physical Interpretation**: DLA structures fill space intermediate between a 2D surface and a 3D solid, reflecting the screening-limited growth.

## 2.3 Cluster-Cluster Aggregation (CCA)

### Physical Model

In CCA, all particles start as individual clusters (monomers). Clusters undergo Brownian motion and merge upon collision. The key difference from DLA: **both collision partners move**.

This fundamentally changes the resulting structure because:
1. Larger clusters diffuse more slowly (mobility scaling)
2. Clusters have time to explore before collision
3. Hierarchical merging creates self-similar structures at all scales

### Mobility Scaling Laws

Cluster mobility (diffusion coefficient) depends on cluster size. The physical regime determines the scaling:

**Free Molecular Regime** ($R \ll \lambda$, where $\lambda$ is mean free path):

Gas molecules collide with the cluster like projectiles. The drag force scales with projected area:

$$
F_d \propto R^2 v
$$

By Stokes-Einstein relation:

$$
D(R) = \frac{k_B T}{F_d / v} \propto \frac{1}{R^2}
$$

For fractal clusters with $N \propto R^{D_f}$:

$$
D(N) \propto N^{-2/D_f}
$$

**Continuum Regime** ($R \gg \lambda$):

The cluster experiences viscous drag (Stokes flow):

$$
F_d = 6\pi \mu R v
$$

Therefore:

$$
D(R) = \frac{k_B T}{6\pi \mu R} \propto \frac{1}{R}
$$

For fractal clusters:

$$
D(N) \propto N^{-1/D_f}
$$

**General Form**:

$$
D(R) = \frac{D_0}{R^\alpha}
$$

where:
- $\alpha = 2$ for free molecular regime
- $\alpha = 1$ for continuum regime
- $D_0$ = monomer diffusion coefficient

### Implementation of Mobility Scaling

In simulations, the step size is scaled by mobility:

$$
\text{step}_\text{cluster} = \text{step}_\text{base} \times \frac{1}{1 + f(R_g)}
$$

Common choices for $f(R_g)$:

1. **Linear**: $f(R_g) = R_g / r_p$
2. **Square root**: $f(R_g) = \sqrt{R_g / r_p}$ (typical implementation)
3. **Continuum-like**: $f(R_g) = R_g / r_p$
4. **Free molecular**: $f(R_g) = (R_g / r_p)^2$

### Hierarchical Structure Formation

CCA produces hierarchical structures through iterative merging:

**Stage 1**: Monomers combine to form dimers, trimers, small clusters

**Stage 2**: Small clusters merge into larger clusters

**Stage 3**: Process continues until single agglomerate remains

This hierarchical process creates **more open structures** than DLA because:
- Both clusters move, reducing screening
- Clusters collide at their peripheries
- Interior regions are "frozen in" after formation

### Mathematical Analysis of CCA Kinetics

The cluster size distribution $n_k(t)$ (number of clusters of size $k$ at time $t$) evolves according to the Smoluchowski equation:

$$
\frac{dn_k}{dt} = \frac{1}{2} \sum_{i+j=k} K_{ij} n_i n_j - n_k \sum_{i=1}^{\infty} K_{ik} n_i
$$

where $K_{ij}$ is the collision kernel between clusters of size $i$ and $j$.

**For diffusion-limited aggregation**:

$$
K_{ij} \propto (D_i + D_j)(R_i + R_j) \propto (i^{-1/D_f} + j^{-1/D_f})(i^{1/D_f} + j^{1/D_f})
$$

This simplifies to constant kernel for like-sized clusters, leading to:

$$
n_k(t) \propto t^{-2} \phi(k/t) \quad \text{(scaling solution)}
$$

### DLCA Fractal Dimension

The diffusion-limited cluster-cluster aggregation dimension is:

$$
D_f^{DLCA} = 1.80 \pm 0.05 \quad \text{(3D)}
$$

This is significantly lower than DLA because cluster-cluster collision creates more open structures.

**Key Relationships**:
- $D_f^{DLCA} \approx 1.44 \times D_f^{chain}$ (where $D_f^{chain} = 1.25$ for random chain)
- $D_f^{DLCA} < 2$ means projected area scaling is fractal

### Periodic Boundary Conditions

To avoid edge effects and simulate infinite systems, CCA uses periodic boundaries:

**Position Wrapping**:

$$
\vec{r}_{\text{wrapped}} = \vec{r} \mod L_{\text{box}}
$$

For each coordinate:

$$
x_{\text{wrapped}} = x - L_{\text{box}} \lfloor x / L_{\text{box}} \rfloor
$$

**Minimum Image Distance**:

The shortest distance between particles considering periodicity:

$$
\Delta r_i = \begin{cases}
\Delta r_i - L_{\text{box}} & \text{if } \Delta r_i > L_{\text{box}}/2 \\
\Delta r_i + L_{\text{box}} & \text{if } \Delta r_i < -L_{\text{box}}/2 \\
\Delta r_i & \text{otherwise}
\end{cases}
$$

### Collision Detection for Cluster-Cluster

Cluster collision occurs when any particle from cluster A contacts any particle from cluster B:

$$
\text{collision} = \exists (i \in A, j \in B): |\vec{r}_i - \vec{r}_j| \leq c_s (r_{p,i} + r_{p,j})
$$

**Algorithm Complexity**:
- Naive: $O(N_A \times N_B)$ per cluster pair
- With spatial hashing: $O(N_A)$ average case

## 2.4 Ballistic Aggregation

### Physical Model

Ballistic aggregation simulates high-velocity particle impacts where diffusion is negligible. This regime applies when:
- Particle kinetic energy >> thermal energy ($k_B T$)
- Mean free path >> particle size
- Directed flow (jets, sprays)

Particles travel in straight lines toward the cluster, creating more compact structures than diffusive mechanisms.

### Trajectory Calculation

**Launch Position**: Random point on sphere of radius $R_{\text{launch}} > R_g$

$$
\vec{r}_0 = R_{\text{launch}} \cdot \hat{u}
$$

where $\hat{u}$ is a random unit vector.

**Trajectory Direction**:

For targeting cluster center:

$$
\vec{d} = \text{normalize}(\vec{r}_{\text{cm}} - \vec{r}_0) + \vec{\epsilon}
$$

where $\vec{\epsilon}$ is a small random deviation ($|\vec{\epsilon}| \lesssim 0.1$).

**Parametric Trajectory**:

$$
\vec{r}(t) = \vec{r}_0 + v t \cdot \vec{d}
$$

### Ray-Sphere Intersection for Collision Detection

For a particle traveling from $\vec{r}_0$ in direction $\vec{d}$, find intersection with sphere at $\vec{c}$ with radius $r$:

**Derivation**:

Point on ray: $\vec{p}(t) = \vec{r}_0 + t\vec{d}$

On sphere surface: $|\vec{p}(t) - \vec{c}|^2 = r^2$

Expanding:

$$
|\vec{r}_0 - \vec{c}|^2 + 2t \vec{d} \cdot (\vec{r}_0 - \vec{c}) + t^2 |\vec{d}|^2 = r^2
$$

Let $\vec{f} = \vec{r}_0 - \vec{c}$ and $|\vec{d}| = 1$:

$$
t^2 + 2(\vec{d} \cdot \vec{f})t + (|\vec{f}|^2 - r^2) = 0
$$

Quadratic formula:

$$
t = -(\vec{d} \cdot \vec{f}) \pm \sqrt{(\vec{d} \cdot \vec{f})^2 - (|\vec{f}|^2 - r^2)}
$$

**Intersection Conditions**:
- Discriminant $< 0$: No intersection
- Smallest positive $t$: First intersection point

### Ballistic PC Structure

Ballistic particle-cluster (BPC) produces compact structures with:

$$
D_f^{BPC} \approx 2.8 - 3.0
$$

Physical reasons:
1. No random walk allows deeper penetration
2. Preferential filling of concave regions (straight-line access)
3. No screening effect from diffusive shadowing

### Ballistic CC Structure

Ballistic cluster-cluster (BCC) gives intermediate structure:

$$
D_f^{BCC} \approx 1.95 - 2.10
$$

The cluster-cluster geometry prevents penetration, but straight-line approach creates more compact structures than DLCA.

## 2.5 Tunable Algorithm: Filippov-Lapuerta Method

### Motivation

Real soot agglomerates span $D_f = 1.5$ to $3.0$ depending on formation conditions (temperature, residence time, fuel type). The tunable algorithm allows direct specification of target $D_f$, enabling:

1. **Reference structure generation** for validation
2. **Parametric studies** of $D_f$ effects on optical properties
3. **Matching experimental morphologies** for modeling

### Power Law Constraint

The algorithm maintains the constraint at every growth step:

$$
N = k_f \left(\frac{R_g}{r_p}\right)^{D_f}
$$

This requires calculating the exact placement position for each new particle.

### Complete $\gamma^2$ Formula Derivation

For adding particle $N+1$ to a cluster of $N$ particles, we need the distance $\gamma$ from the current center of mass that maintains the power law.

**Step 1: Radius of Gyration Definition**

With internal moment contribution:

$$
R_g^2 = \frac{\sum_{i=1}^{N} \left[\frac{3}{5}r_{p,i}^5 + r_{p,i}^3 d_i^2\right]}{\sum_{i=1}^{N} r_{p,i}^3}
$$

For monodisperse particles ($r_{p,i} = r_p$):

$$
R_g^2 = \frac{3}{5}r_p^2 + \frac{1}{N}\sum_{i=1}^{N} d_i^2
$$

**Step 2: Current Aggregate Properties**

Define:
- $M_N = N$ (number of particles, proxy for mass)
- $I_N = \sum_{i=1}^{N} d_i^2$ (sum of squared distances)

Current $R_g$:

$$
R_g^2(N) = \Lambda r_p^2 + \frac{I_N}{N}
$$

where $\Lambda = 3/5$ is the Lapuerta constant.

**Step 3: After Adding Particle at Distance $\gamma$**

New center of mass shifts by:

$$
\Delta_{\text{cm}} = \frac{\gamma}{N+1}
$$

toward the new particle.

New sum of squared distances (parallel axis theorem):

$$
I_{N+1} = I_N + N\Delta_{\text{cm}}^2 + (\gamma - \Delta_{\text{cm}})^2
$$

Simplifying:

$$
I_{N+1} = I_N + \frac{N\gamma^2}{(N+1)^2} + \frac{N^2\gamma^2}{(N+1)^2} = I_N + \frac{N\gamma^2}{N+1}
$$

New $R_g$:

$$
R_g^2(N+1) = \Lambda r_p^2 + \frac{I_{N+1}}{N+1} = \Lambda r_p^2 + \frac{I_N + N\gamma^2/(N+1)}{N+1}
$$

$$
R_g^2(N+1) = \Lambda r_p^2 + \frac{I_N}{N+1} + \frac{N\gamma^2}{(N+1)^2}
$$

**Step 4: Power Law Constraints**

For $N$ particles:

$$
N = k_f \left(\frac{R_g(N)}{r_p}\right)^{D_f} \implies R_g^2(N) = r_p^2 \left(\frac{N}{k_f}\right)^{2/D_f}
$$

For $N+1$ particles:

$$
R_g^2(N+1) = r_p^2 \left(\frac{N+1}{k_f}\right)^{2/D_f}
$$

**Step 5: Expressing $I_N$ in Terms of $N$**

From the power law:

$$
I_N = N \left[R_g^2(N) - \Lambda r_p^2\right] = N \left[r_p^2 \left(\frac{N}{k_f}\right)^{2/D_f} - \Lambda r_p^2\right]
$$

$$
I_N = N r_p^2 \left[\left(\frac{N}{k_f}\right)^{2/D_f} - \Lambda\right]
$$

**Step 6: Solving for $\gamma^2$**

From Step 3:

$$
r_p^2 \left(\frac{N+1}{k_f}\right)^{2/D_f} = \Lambda r_p^2 + \frac{I_N}{N+1} + \frac{N\gamma^2}{(N+1)^2}
$$

Rearranging:

$$
\frac{N\gamma^2}{(N+1)^2} = r_p^2 \left[\left(\frac{N+1}{k_f}\right)^{2/D_f} - \Lambda\right] - \frac{I_N}{N+1}
$$

Substituting $I_N$ from Step 5:

$$
\frac{N\gamma^2}{(N+1)^2} = r_p^2 \left[\left(\frac{N+1}{k_f}\right)^{2/D_f} - \Lambda - \frac{N}{N+1}\left(\left(\frac{N}{k_f}\right)^{2/D_f} - \Lambda\right)\right]
$$

Simplifying:

$$
\frac{N\gamma^2}{(N+1)^2} = r_p^2 \left[\left(\frac{N+1}{k_f}\right)^{2/D_f} - \frac{N}{N+1}\left(\frac{N}{k_f}\right)^{2/D_f} - \frac{\Lambda}{N+1}\right]
$$

**Final Filippov-Lapuerta Formula**:

$$
\boxed{\gamma^2 = r_p^2 \cdot \frac{(N+1)^2}{N} \left[\left(\frac{N+1}{k_f}\right)^{2/D_f} - \frac{N}{N+1}\left(\frac{N}{k_f}\right)^{2/D_f} - \frac{\Lambda}{N+1}\right]}
$$

Or equivalently (Filippov et al. form):

$$
\gamma^2 = r_p^2 \left[\frac{N^2}{N-1} \left(\left(\frac{N}{k_f}\right)^{2/D_f} - \Lambda\right) - N \left(\frac{N-1}{k_f}\right)^{2/D_f} - \frac{N}{N-1}\left(\left(\frac{1}{k_f}\right)^{2/D_f} - \Lambda\right)\right]
$$

### The Lapuerta Constant: Physical Origin

The constant $\Lambda = 3/5$ arises from the moment of inertia of a uniform sphere about its center.

**Derivation**:

For a uniform sphere of radius $r$, mass $m$, and density $\rho$:

$$
I_{\text{sphere}} = \int_V \rho \cdot r'^2 \, dV
$$

In spherical coordinates:

$$
I_{\text{sphere}} = \rho \int_0^r \int_0^\pi \int_0^{2\pi} r'^2 \cdot r'^2 \sin\theta \, d\phi \, d\theta \, dr'
$$

$$
= \rho \int_0^r r'^4 dr' \cdot \int_0^\pi \sin\theta d\theta \cdot \int_0^{2\pi} d\phi
$$

$$
= \rho \cdot \frac{r^5}{5} \cdot 2 \cdot 2\pi = \frac{4\pi\rho r^5}{5}
$$

Since $m = \frac{4}{3}\pi\rho r^3$:

$$
I_{\text{sphere}} = \frac{3m r^2}{5}
$$

For unit mass ($m = r^3$ in our normalization):

$$
I_{\text{self}} = \frac{3r^5}{5}
$$

This gives the self-moment contribution $\Lambda = 3/5$.

### Placement Algorithm

Given target distance $\gamma$:

**Step 1**: Identify candidate particles (the "LA-minus" set)

A particle $i$ at distance $d_i$ from center of mass is a candidate if placement near it can achieve distance $\gamma$:

$$
|d_i - 2r_p| \leq \gamma \leq d_i + 2r_p
$$

**Step 2**: Select reference particle

Choose from candidates (random selection or weighted by geometric factors).

**Step 3**: Calculate placement angle $\alpha$

Using the law of cosines for the triangle formed by center of mass, reference particle, and new particle:

$$
\gamma^2 = d_i^2 + (2r_p c_s)^2 - 2 d_i (2r_p c_s) \cos\alpha
$$

Solving for $\alpha$:

$$
\alpha = \arccos\left(\frac{d_i^2 + (2r_p c_s)^2 - \gamma^2}{2 d_i (2r_p c_s)}\right)
$$

**Step 4**: Random rotation $\beta$ around reference axis

The new particle position is:

$$
\vec{r}_{\text{new}} = \vec{r}_i + (2r_p c_s) \cdot \text{rotate}(\hat{d}_i, \alpha, \beta)
$$

where $\hat{d}_i = (\vec{r}_i - \vec{r}_{\text{cm}}) / d_i$ and $\beta \sim U(0, 2\pi)$.

**Step 5**: Overlap check

Verify no overlap with existing particles. If overlap, try different $\beta$ or different reference particle.

## 2.6 Sintering Model

### Physical Process

Sintering is thermally-activated solid-state diffusion of material between contacting particles, driven by surface energy minimization. The process creates a "neck" between particles that:

1. Reduces center-to-center distance
2. Increases contact area
3. Increases mechanical strength
4. Changes optical properties

### Sintering Kinetics

The neck radius $x$ grows with time according to:

$$
\left(\frac{x}{r_p}\right)^n = \frac{B(T)}{r_p^m} t
$$

where:
- $n, m$ = mechanism-dependent exponents
- $B(T)$ = temperature-dependent rate constant

| Mechanism | $n$ | $m$ |
|-----------|-----|-----|
| Viscous flow | 2 | 1 |
| Surface diffusion | 7 | 4 |
| Volume diffusion | 5 | 3 |
| Grain boundary diffusion | 6 | 4 |
| Evaporation-condensation | 3 | 2 |

### Contact Distance Model

For simulation, sintering is modeled through the **sintering coefficient** $c_s$:

$$
d_{\text{contact}} = c_s \cdot (r_{p,1} + r_{p,2})
$$

where:
- $c_s = 1.0$: touching (no sintering)
- $c_s = 0.9$: 10% overlap (mild sintering)
- $c_s = 0.7$: 30% overlap (moderate sintering)
- $c_s = 0.5$: 50% overlap (heavy sintering)

### Relationship to Neck Size

The sintering coefficient relates to neck-to-radius ratio:

$$
c_s = \sqrt{1 - \left(\frac{x}{r_p}\right)^2}
$$

Inversely:

$$
\frac{x}{r_p} = \sqrt{1 - c_s^2}
$$

### Effect on Morphology

Sintering affects aggregate properties:

| Property | Effect of Sintering |
|----------|---------------------|
| $R_g$ | Decreases (compaction) |
| $D_f$ | Increases (more space-filling) |
| $k_f$ | Increases (higher prefactor) |
| Porosity | Decreases |
| Coordination $\eta$ | Increases (more contacts per particle) |

### Distribution Models for Polydisperse Sintering

**Fixed**: Same $c_s$ for all contacts

$$
c_s = \text{constant}
$$

**Uniform**: Random $c_s$ in range

$$
c_s \sim U(c_{\min}, c_{\max})
$$

**Normal**: Gaussian distribution (clamped)

$$
c_s \sim N(\mu, \sigma), \quad c_s \in [0.5, 1.0]
$$

## 2.7 Sticking Probability and Reaction-Limited Aggregation

### Physical Interpretation

Not all particle collisions result in permanent adhesion. The sticking probability $p_s$ accounts for:

- **Surface chemistry**: Reactive vs. passivated surfaces
- **Impact velocity**: Higher velocity may cause bouncing
- **Temperature**: Affects surface energy and deformation
- **Surface coatings**: Organic layers, water films
- **Charge state**: Electrostatic repulsion/attraction

### Implementation

Upon collision detection:

$$
\text{outcome} = \begin{cases}
\text{stick} & \text{if } \xi < p_s \\
\text{bounce} & \text{if } \xi \geq p_s
\end{cases}
$$

where $\xi \sim U(0, 1)$.

### Effect on Structure

The sticking probability dramatically affects morphology:

| $p_s$ | Regime | Effect | $D_f$ |
|-------|--------|--------|-------|
| 1.0 | Diffusion-limited (DLCA) | Immediate sticking, screening dominates | ~1.8 |
| 0.1 - 0.5 | Intermediate | Partial penetration | ~1.9 - 2.1 |
| << 0.1 | Reaction-limited (RLCA) | Deep penetration, compact structures | ~2.0 - 2.2 |

### Reaction-Limited Cluster-Cluster Aggregation (RLCA)

When $p_s << 1$, particles undergo many collisions before sticking. This allows:

1. **Exploration** of cluster surface before attachment
2. **Penetration** into interior regions
3. **Optimal packing** positions

The resulting $D_f^{RLCA} \approx 2.1$ is higher than DLCA.

### Theoretical Framework

The characteristic time for cluster-cluster aggregation:

$$
\tau \propto \frac{1}{p_s \cdot n_c \cdot K_{ij}}
$$

where $n_c$ is cluster concentration and $K_{ij}$ is collision kernel.

For RLCA, the slow sticking allows equilibration, approaching a "restructured" limit.

## 2.8 Summary of Aggregation Mechanisms

| Property | DLA | DLCA | RLCA | BPCA | BCCA | Tunable |
|----------|-----|------|------|------|------|---------|
| Transport | Diffusive | Diffusive | Diffusive | Ballistic | Ballistic | Controlled |
| Partners | PC | CC | CC | PC | CC | PC |
| Typical $D_f$ | 2.4-2.6 | 1.75-1.85 | 2.0-2.2 | 2.8-3.0 | 1.9-2.1 | User-defined |
| Structure | Dendritic | Hierarchical | Dense hierarchical | Compact | Moderate | Controlled |
| Screening | High | Medium | Low | Low | Medium | Variable |
| Physical analog | Electrodeposition | Soot formation | Slow aggregation | High-velocity spray | Ballistic spray | Reference structures |
| $k_f$ range | 1.0-1.5 | 1.3-2.0 | 1.5-2.5 | 1.5-2.5 | 1.3-2.0 | User-defined |

### Selection Guidelines

Choose aggregation mechanism based on:

1. **Target $D_f$**: Use tunable for specific values, physical mechanisms for realistic structures
2. **Physical realism**: DLCA for flame soot, BPCA for spray coating
3. **Computational cost**: DLA/tunable fastest, CCA requires tracking multiple clusters
4. **Structure statistics**: CCA gives natural polydispersity, PC methods give more uniform structures
