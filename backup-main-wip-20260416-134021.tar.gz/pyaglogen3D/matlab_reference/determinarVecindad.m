function vecindario = determinarVecindad( clusters )

    numClusters = size( clusters, 1 );
    tol = 1e-5;                         % Para evitar errores a la hora de calcular vecinas

    if iscell( clusters )
        clusters = cell2mat( clusters );
    end

    if ( size( clusters, 2 ) > 4 )
        clusters = clusters( :, 3 : end );
    end

    % Variables de salida para guardar la vecindad y la suma de los radios de los mon�meros 
    vecindario = zeros( numClusters  );
    distancias = zeros( numClusters  );

    % Calculamos las distancias entre los centros geom�tricos de los mon�meros
    for m = 1 : numClusters
        intermedio = clusters( 1 : end, 1 : 3 ) - repmat( clusters( m, 1 : 3 ), numClusters , 1 );
        vecindario( m, : ) = arrayfun( @( x ) norm( intermedio( x, : ) ), 1 : size( intermedio, 1 ) );
        distancias( m, : ) = repmat( clusters( m, 4 ), numClusters , 1 ) + clusters( 1 : end, 4 );
    end

%     vecindario = sparse( vecindario  );
%     distancias = sparse( distancias  );

    % La condici�n para ser vecinas es la siguiente (nos quedamos con los elementos que est�n por encima de la
    % primera diagonal--la siguiente a la superior)
    vecindario = vecindario - distancias <= tol;

    vecindario = full( vecindario );
    % Ahora quitamos el auton�mero de coordinaci�n
    for m = 1 : numClusters
        for n = m : m
            vecindario( m, n ) = 0;
        end
    end

    vecindario = sparse( triu( vecindario ) );
end