function [ impactado, impactante ] = sorteoClusteres( clusters, metodo )
%-----------------------------------------------------------------------------------------------------------------------
%
% [ impactado, impactante ] = sorteoClusteres( clusters, metodo )
% Realiza el sorteo entre los elementos dados en el vector de celdas clusters para determinar cu�l es el
% cl�ster impactante y cu�l es el impactado. Se tiene en cuenta el m�todo de generaci�n de cl�steres ya que
% para el m�todo part�cula-cl�ster (PC) el impactado es siempre el elemento n�mero 1
%
% Argumentos de entrada:
% clusters:     Vector de celdas que contiene la informaci�n de los cl�sters
% metodo:       M�todo de creaci�n de aglomerados (PC o CC)
%
% Argumentos de salida:
% impactado:    N�mero del cl�ster impactado.
% impactante:   N�mero del cl�ster impactante.
%
%-----------------------------------------------------------------------------------------------------------------------

    switch metodo
        case 'PC'
            % Realizamos el sorteo entre los clusters
            [ ~, segundo ] = sortear( clusters );
            primero = 1;
            % Puede que el segundo sea el cl�ster uno por lo que hay que volver a sortear
            while ( segundo == 1 )
                [ ~, segundo ] = sortear( clusters );
            end
            % El impactado es el primero y el impactante el segundo
            impactado = primero;
            impactante = segundo;
        case 'CC'
            % Realizamos el sorteo entre los clusters
            [ primero, segundo ] = sortear( clusters );
            % Sorteamos qui�n es el impactante y quien el impactado
            orden = [ primero segundo ];
            % Sorteo para ver quien es impactante y quien impactado
            [ impactante, impactado ] = sortear( orden );
            impactado = orden( impactado );
            impactante = orden( impactante );
    end

end

function [ primero, segundo ] = sortear( clusters )

    % Generamos un vector de candidatos
    candidatos = 1 : numel( clusters );
    primero = randi( [ 1, numel( candidatos ) ] );
    primero = candidatos( primero );

    % Eliminamos el numero de la lista de candidatos
    candidatos( primero ) = [];

    segundo = randi( [ 1, numel( candidatos ) ] );
    segundo = candidatos( segundo );
end