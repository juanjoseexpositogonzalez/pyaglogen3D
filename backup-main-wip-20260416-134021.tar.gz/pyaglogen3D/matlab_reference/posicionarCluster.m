function cluster = posicionarCluster( cluster, punto )
%-----------------------------------------------------------------------------------------------------------------------
% cluster = posicionarCluster( cluster, punto )
% Coloca un cl�ster en el origen de coordenadas global
% 
% Argumentos de entrada:
% cluster:  Matriz con los desplazamientos X, Y, Z de los centros geom�tricos de los mon�meros que componen el
%           cl�ster con respecto a su centro geom�trico.
% punto:    Coordenadas del centro geom�trico con respecto al centro global de coordenadas
% 
% Argumentos de salida:
% cluster:  Matriz con los desplazamientos X, Y, Z de los centros geom�tricos de los mon�meros que componen el
%           cl�ster con respecto al origen de coordenadas
%
%-----------------------------------------------------------------------------------------------------------------------

punto = repmat( punto, size( cluster, 1 ), 1 );

if size( cluster, 2 ) == 4
    cluster( :, 1 : 3 ) = cluster( :, 1 : 3 ) - punto;
else
    cluster( :, 3 : 5 ) = cluster( :, 3 : 5 ) - punto;
end